<?php
header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/Showtime.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

if (empty($action)) {
    echo json_encode([]);
    exit;
}

$database = new Database();
$db = $database->getConnection();
$showtimeModel = new Showtime($db);

switch ($action) {
    case 'get_movies':
        $cinema_id = isset($_GET['cinema_id']) ? intval($_GET['cinema_id']) : 0;
        if ($cinema_id > 0) {
            $movies = $showtimeModel->getMoviesByCinema($cinema_id);
            echo json_encode($movies);
        } else {
            echo json_encode([]);
        }
        break;

    case 'get_dates':
        $cinema_id = isset($_GET['cinema_id']) ? intval($_GET['cinema_id']) : 0;
        $movie_id = isset($_GET['movie_id']) ? intval($_GET['movie_id']) : 0;
        if ($cinema_id > 0 && $movie_id > 0) {
            $dates = $showtimeModel->getDatesByCinemaAndMovie($cinema_id, $movie_id);
            echo json_encode($dates);
        } else {
            echo json_encode([]);
        }
        break;

    case 'get_times':
        $cinema_id = isset($_GET['cinema_id']) ? intval($_GET['cinema_id']) : 0;
        $movie_id = isset($_GET['movie_id']) ? intval($_GET['movie_id']) : 0;
        $show_date = isset($_GET['show_date']) ? $_GET['show_date'] : '';
        
        if ($cinema_id > 0 && $movie_id > 0 && !empty($show_date)) {
            $times = $showtimeModel->getTimesByCinemaMovieAndDate($cinema_id, $movie_id, $show_date);
            echo json_encode($times);
        } else {
            echo json_encode([]);
        }
        break;

    case 'get_filtered_options':
        $cinema_id = isset($_GET['cinema_id']) ? intval($_GET['cinema_id']) : 0;
        $movie_id = isset($_GET['movie_id']) ? intval($_GET['movie_id']) : 0;
        $show_date = isset($_GET['show_date']) ? $_GET['show_date'] : '';

        // 1. Filtered Cinemas
        $sql = "SELECT DISTINCT c.id, c.name FROM cinemas c JOIN showtimes s ON c.id = s.cinema_id WHERE s.show_date >= CURDATE()";
        $params = [];
        if ($movie_id > 0) {
            $sql .= " AND s.movie_id = :movie_id";
            $params[':movie_id'] = $movie_id;
        }
        if (!empty($show_date)) {
            $sql .= " AND s.show_date = :show_date";
            $params[':show_date'] = $show_date;
        }
        $sql .= " ORDER BY c.name ASC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $cinemas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 2. Filtered Movies
        $sql = "SELECT DISTINCT m.id, m.title FROM movies m JOIN showtimes s ON m.id = s.movie_id WHERE s.show_date >= CURDATE()";
        $params = [];
        if ($cinema_id > 0) {
            $sql .= " AND s.cinema_id = :cinema_id";
            $params[':cinema_id'] = $cinema_id;
        }
        if (!empty($show_date)) {
            $sql .= " AND s.show_date = :show_date";
            $params[':show_date'] = $show_date;
        }
        $sql .= " ORDER BY m.title ASC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $movies = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // 3. Filtered Dates
        $sql = "SELECT DISTINCT s.show_date FROM showtimes s WHERE s.show_date >= CURDATE()";
        $params = [];
        if ($cinema_id > 0) {
            $sql .= " AND s.cinema_id = :cinema_id";
            $params[':cinema_id'] = $cinema_id;
        }
        if ($movie_id > 0) {
            $sql .= " AND s.movie_id = :movie_id";
            $params[':movie_id'] = $movie_id;
        }
        $sql .= " ORDER BY s.show_date ASC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $dates = $stmt->fetchAll(PDO::FETCH_COLUMN);

        echo json_encode([
            'cinemas' => $cinemas,
            'movies' => $movies,
            'dates' => $dates
        ]);
        break;

    default:
        echo json_encode([]);
        break;
}
?>
