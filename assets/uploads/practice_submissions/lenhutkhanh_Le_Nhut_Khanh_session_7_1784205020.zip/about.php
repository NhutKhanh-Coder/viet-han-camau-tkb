<?php
require_once __DIR__ . '/views/header.php';

// Fetch all cinemas from our database using OOP model
$cinemas = $cinemaModel->getAll();
?>

<div class="container py-5 min-vh-100">
    <!-- Page Header -->
    <div class="text-center mb-5">
        <h1 class="display-4 fw-bold text-white text-uppercase">
            <span class="text-warning"><i class="fa-solid fa-star me-2"></i>Giới Thiệu</span> Về Cinestar
        </h1>
        <p class="text-white-50 fs-5">Hệ thống rạp chiếu phim chất lượng cao - Kết nối đam mê điện ảnh</p>
        <div class="mx-auto" style="width: 80px; height: 4px; background: linear-gradient(90deg, var(--accent-yellow), var(--accent-purple)); border-radius: 2px;"></div>
    </div>

    <!-- Core Intro -->
    <div class="row align-items-center mb-5 g-5">
        <div class="col-lg-6">
            <h2 class="text-white fw-bold mb-4">Về Chúng Tôi</h2>
            <p class="text-white-50 fs-6" style="line-height: 1.8;">
                Thành lập với sứ mệnh mang điện ảnh chất lượng cao đến gần hơn với mọi người, đặc biệt là các bạn học sinh, sinh viên, <strong>Cinestar Cinemas</strong> tự hào là một trong những chuỗi rạp chiếu phim nội địa được yêu thích nhất tại Việt Nam.
            </p>
            <p class="text-white-50 fs-6" style="line-height: 1.8;">
                Chúng tôi cam kết mang đến những trải nghiệm nghe nhìn xuất sắc nhất nhờ trang bị công nghệ phòng chiếu tối tân đạt chuẩn quốc tế, máy chiếu sắc nét, hệ thống âm thanh Dolby Atmos đỉnh cao cùng danh mục bắp nước phong phú với mức giá vô cùng hợp lý.
            </p>
        </div>
        <div class="col-lg-6">
            <div class="p-4 bg-secondary-cinestar border border-secondary-light rounded-4 shadow-lg">
                <h4 class="text-warning fw-bold mb-3"><i class="fa-solid fa-rocket me-2"></i>Tầm nhìn & Sứ mệnh</h4>
                <p class="text-white-50 mb-4" style="font-size: 14px; line-height: 1.6;">
                    Trở thành điểm đến giải trí hàng đầu cho giới trẻ Việt Nam, không chỉ cung cấp các suất chiếu bom tấn đỉnh cao mà còn là tổ hợp vui chơi giải trí lành mạnh, năng động và sáng tạo.
                </p>
                
                <h4 class="text-warning fw-bold mb-3"><i class="fa-solid fa-heart me-2"></i>Giá trị cốt lõi</h4>
                <div class="row g-2 text-white-50" style="font-size: 13px;">
                    <div class="col-6 mb-2">
                        <i class="fa-solid fa-check text-warning me-2"></i> Khách hàng là trọng tâm
                    </div>
                    <div class="col-6 mb-2">
                        <i class="fa-solid fa-check text-warning me-2"></i> Giá vé sinh viên, tiết kiệm
                    </div>
                    <div class="col-6 mb-2">
                        <i class="fa-solid fa-check text-warning me-2"></i> Công nghệ chiếu phim đi đầu
                    </div>
                    <div class="col-6 mb-2">
                        <i class="fa-solid fa-check text-warning me-2"></i> Dịch vụ chuyên nghiệp tận tâm
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Features Stat Bar -->
    <div class="row text-center py-4 bg-secondary-cinestar border border-secondary-light rounded-4 mx-0 mb-5 shadow-lg">
        <div class="col-md-3 col-6 mb-3 mb-md-0 border-end border-secondary-light">
            <h2 class="text-warning fw-bold mb-0">15+</h2>
            <p class="text-white-50 mb-0" style="font-size: 13px;">Cụm rạp toàn quốc</p>
        </div>
        <div class="col-md-3 col-6 mb-3 mb-md-0 border-end-md border-secondary-light">
            <h2 class="text-warning fw-bold mb-0">100+</h2>
            <p class="text-white-50 mb-0" style="font-size: 13px;">Phòng chiếu hiện đại</p>
        </div>
        <div class="col-md-3 col-6 border-end border-secondary-light">
            <h2 class="text-warning fw-bold mb-0">5M+</h2>
            <p class="text-white-50 mb-0" style="font-size: 13px;">Lượt khách hàng năm</p>
        </div>
        <div class="col-md-3 col-6">
            <h2 class="text-warning fw-bold mb-0">100%</h2>
            <p class="text-white-50 mb-0" style="font-size: 13px;">Độ hài lòng dịch vụ</p>
        </div>
    </div>

    <!-- Cinema Systems Dynamic Grid -->
    <h3 class="text-white fw-bold mb-4 border-bottom border-secondary-light pb-2 text-uppercase">
        <i class="fa-solid fa-location-dot text-warning me-2"></i>Hệ thống cụm rạp Cinestar
    </h3>
    <div class="row">
        <?php if (!empty($cinemas)): ?>
            <?php foreach ($cinemas as $cinema): ?>
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="card bg-secondary-cinestar border-0 h-100 shadow-lg branch-card transition-all">
                        <div class="card-body p-4 d-flex flex-column">
                            <h5 class="card-title text-warning fw-bold mb-3 d-flex align-items-center">
                                <i class="fa-solid fa-building-user me-2"></i>
                                <?php echo htmlspecialchars($cinema['name']); ?>
                            </h5>
                            <p class="card-text text-white-50 flex-grow-1 mb-4" style="font-size: 14px; line-height: 1.6;">
                                <i class="fa-solid fa-map-location-dot me-2 text-muted"></i>
                                <?php echo htmlspecialchars($cinema['address']); ?>
                            </p>
                            <div class="d-flex gap-2">
                                <a href="index.php#dat-ve-nhanh" class="btn btn-yellow btn-sm flex-grow-1 text-uppercase fw-bold">
                                    <i class="fa-solid fa-ticket me-1"></i> Đặt vé ngay
                                </a>
                                <a href="https://maps.google.com/?q=<?php echo urlencode($cinema['name'] . ' ' . $cinema['address']); ?>" target="_blank" class="btn btn-outline-light btn-sm px-3" title="Xem bản đồ">
                                    <i class="fa-solid fa-map-pin"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-white-50 py-5">
                <i class="fa-solid fa-circle-question fs-2 mb-3"></i>
                <p>Chưa có thông tin chi nhánh rạp. Vui lòng quay lại sau.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<style>
.bg-secondary-cinestar {
    background-color: var(--bg-secondary);
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
}
.border-secondary-light {
    border-color: rgba(255, 255, 255, 0.08) !important;
}
.branch-card {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
}
.branch-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 10px 25px rgba(250, 204, 21, 0.15) !important;
    border-color: var(--accent-yellow) !important;
}
@media (min-width: 768px) {
    .border-end-md {
        border-end: 1px solid rgba(255, 255, 255, 0.08) !important;
    }
}
</style>

<?php
require_once __DIR__ . '/views/footer.php';
?>
