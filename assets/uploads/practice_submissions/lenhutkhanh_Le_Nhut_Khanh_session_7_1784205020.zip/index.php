<?php
require_once __DIR__ . '/views/header.php';

// Search keyword
$keyword = isset($_GET['search']) ? trim($_GET['search']) : '';
$is_search = !empty($keyword);

if ($is_search) {
    $searchResults = $movieModel->search($keyword);
} else {
    $showingMovies = $movieModel->getShowing();
    $comingMovies = $movieModel->getComing();
}

$cinemas = $cinemaModel->getAll();
$allMovies = $movieModel->getShowing();
$datesStmt = $db->query("SELECT DISTINCT show_date FROM showtimes WHERE show_date >= CURDATE() ORDER BY show_date ASC");
$allDates = $datesStmt->fetchAll(PDO::FETCH_COLUMN);
?>

<?php if (!$is_search): ?>
    <?php 
        $activeBanners = $bannerModel->getAll();
    ?>
    <?php if (!empty($activeBanners)): ?>
        <!-- Hero Banner Carousel -->
        <div class="hero-carousel">
            <?php foreach ($activeBanners as $index => $banner): ?>
                <?php 
                    $slide_class = ($index === 0) ? 'hero-slide active' : 'hero-slide';
                    
                    // Determine if the banner file is a video or image
                    $banner_file = $banner['image'];
                    $ext = strtolower(pathinfo($banner_file, PATHINFO_EXTENSION));
                    $is_video = in_array($ext, ['mp4', 'webm', 'ogg']);
                    
                    if ($is_video) {
                        $banner_video = $base_url . 'assets/videos/' . $banner_file;
                        $video_path_full = __DIR__ . '/assets/videos/' . $banner_file;
                        if (file_exists($video_path_full)) {
                            $banner_video .= '?v=' . filemtime($video_path_full);
                        }
                    } else {
                        $banner_img = $base_url . 'assets/images/' . $banner_file;
                    }
                    
                    // Get the associated movie to use its poster as a fallback / preloader
                    $movie_poster = '';
                    $selected_movie = $movieModel->getById($banner['movie_id']);
                    if ($selected_movie && !empty($selected_movie['image'])) {
                        $movie_poster = $base_url . 'assets/images/' . $selected_movie['image'];
                    }

                    // Determine badge color based on subtitle
                    $badge_class = 'bg-warning text-dark';
                    $sub_lower = mb_strtolower($banner['subtitle']);
                    if (str_contains($sub_lower, 'kinh dị') || str_contains($sub_lower, 'cấm') || str_contains($sub_lower, '18+')) {
                        $badge_class = 'bg-danger text-white';
                    } elseif (str_contains($sub_lower, 'bom tấn') || str_contains($sub_lower, 'vip')) {
                        $badge_class = 'bg-primary text-white';
                    }
                ?>
                <div class="<?php echo $slide_class; ?>" style="background-color: #0a0e17; overflow: hidden;">
                    <?php if ($is_video): ?>
                        <div class="hero-video-container">
                            <video id="hero-video-<?php echo $index; ?>" src="<?php echo $banner_video; ?>" autoplay muted playsinline class="hero-bg-video" <?php if (!empty($movie_poster)): ?>poster="<?php echo $movie_poster; ?>"<?php endif; ?>>
                                Trình duyệt của bạn không hỗ trợ HTML5 video.
                            </video>
                            <div class="video-cover-overlay"></div>
                        </div>
                    <?php else: ?>
                        <div class="hero-slide-image" style="background-image: url('<?php echo $banner_img; ?>');"></div>
                    <?php endif; ?>

                    <div class="hero-slide-overlay" style="z-index: 2;"></div>
                    <div class="hero-caption" style="z-index: 3;">
                        <span class="badge <?php echo $badge_class; ?> mb-2 fw-bold text-uppercase px-3 py-2"><?php echo htmlspecialchars($banner['subtitle']); ?></span>
                        <h1 class="text-white"><?php echo htmlspecialchars($banner['title']); ?></h1>
                        <p class="text-white-50 fs-5 mb-4" style="max-width: 600px;"><?php echo htmlspecialchars($banner['description']); ?></p>
                        <a href="movie-detail.php?id=<?php echo $banner['movie_id']; ?>" class="btn btn-yellow btn-lg text-uppercase fw-bold"><i class="fa-solid fa-circle-play me-2"></i>Đặt vé ngay</a>
                    </div>
                </div>
            <?php endforeach; ?>

            <!-- Navigation Arrows -->
            <button class="hero-nav hero-prev"><i class="fa-solid fa-chevron-left"></i></button>
            <button class="hero-nav hero-next"><i class="fa-solid fa-chevron-right"></i></button>

            <!-- Sound Toggle Button -->
            <button class="video-sound-btn" id="video-sound-btn" title="Bật/Tắt âm thanh" style="z-index: 10;">
                <i class="fa-solid fa-volume-xmark" id="video-sound-icon"></i>
            </button>

            <!-- Slide Indicators (Dots) -->
            <div class="hero-dots">
                <?php foreach ($activeBanners as $index => $banner): ?>
                    <button class="hero-dot <?php echo ($index === 0) ? 'active' : ''; ?>" data-slide="<?php echo $index; ?>" aria-label="Slide <?php echo $index + 1; ?>"></button>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- Quick Booking Bar -->
    <div class="container" id="dat-ve-nhanh">
        <div class="quick-booking-bar">
            <div class="row align-items-center g-3">
                <div class="col-xl-3 col-lg-12">
                    <div class="quick-booking-title">
                        <i class="fa-solid fa-bolt text-warning fs-3 me-2"></i>
                        <span>Đặt vé<br class="d-none d-xl-block"> nhanh</span>
                    </div>
                </div>
                <div class="col-xl-2 col-md-3">
                    <select id="qb-cinema">
                        <option value="">1. Chọn Rạp</option>
                        <?php foreach ($cinemas as $cinema): ?>
                            <option value="<?php echo $cinema['id']; ?>"><?php echo htmlspecialchars($cinema['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-xl-2 col-md-3">
                    <select id="qb-movie">
                        <option value="">2. Chọn Phim</option>
                        <?php foreach ($allMovies as $movie): ?>
                            <option value="<?php echo $movie['id']; ?>"><?php echo htmlspecialchars($movie['title']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-xl-2 col-md-3">
                    <select id="qb-date">
                        <option value="">3. Chọn Ngày</option>
                        <?php foreach ($allDates as $date): ?>
                            <?php 
                                $parts = explode('-', $date);
                                $formattedDate = "{$parts[2]}/{$parts[1]}/{$parts[0]}";
                            ?>
                            <option value="<?php echo $date; ?>"><?php echo $formattedDate; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-xl-2 col-md-3">
                    <select id="qb-time" disabled>
                        <option value="">4. Chọn Suất</option>
                    </select>
                </div>
                <div class="col-xl-1 col-lg-12 text-center text-xl-end">
                    <button id="qb-submit" class="btn btn-purple w-100 py-2 text-uppercase opacity-50 fw-bold" disabled>Đặt ngay</button>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<!-- Main Content Grid -->
<div class="container my-5 py-4">
    
    <?php if ($is_search): ?>
        <!-- Search Results View -->
        <div class="mb-4">
            <a href="index.php" class="text-warning text-decoration-none fw-semibold"><i class="fa-solid fa-arrow-left me-1"></i> Quay lại trang chủ</a>
            <h3 class="mt-3 text-white">Kết quả tìm kiếm cho: "<span class="text-warning"><?php echo htmlspecialchars($keyword); ?></span>"</h3>
            <p class="text-white-50">Tìm thấy <?php echo count($searchResults); ?> phim phù hợp</p>
        </div>

        <?php if (count($searchResults) > 0): ?>
            <div class="row">
                <?php foreach ($searchResults as $movie): ?>
                    <div class="col-xl-3 col-lg-4 col-sm-6">
                        <div class="movie-card">
                            <div class="movie-image-container">
                                <?php 
                                    $ratingClass = strtolower(str_replace(' ', '', $movie['rating']));
                                    if (!in_array($ratingClass, ['p', 't16', 't18', 'k'])) $ratingClass = 'other';
                                ?>
                                <span class="rating-badge <?php echo $ratingClass; ?>">2D | <?php echo htmlspecialchars($movie['rating']); ?></span>
                                <img src="<?php echo getMoviePosterUrl($movie['image'], $movie['title']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                <div class="movie-overlay">
                                    <a href="movie-detail.php?id=<?php echo $movie['id']; ?>" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-ticket me-1"></i> Đặt vé</a>
                                    <?php if (!empty($movie['trailer_url'])): ?>
                                        <a href="<?php echo htmlspecialchars($movie['trailer_url']); ?>" target="_blank" class="btn btn-outline-light text-uppercase fw-bold"><i class="fa-solid fa-play me-1"></i> Trailer</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="movie-info">
                                <h3 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                <div class="movie-meta"><?php echo $movie['duration']; ?> phút | <?php echo date('d/m/Y', strtotime($movie['release_date'])); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="fa-solid fa-film text-white-50 fs-1 mb-3"></i>
                <p class="text-white-50 fs-5">Không tìm thấy phim nào khớp với từ khóa tìm kiếm của bạn.</p>
            </div>
        <?php endif; ?>

    <?php else: ?>
        <!-- Standard Landing Page: Showing and Coming Soon Movies -->
        
        <!-- SECTION 1: PHIM ĐANG CHIẾU -->
        <section id="phim-dang-chieu" class="mb-5 py-4">
            <div class="section-title-container">
                <h2 class="section-title">Phim Đang Chiếu</h2>
            </div>
            
            <div class="row">
                <?php foreach ($showingMovies as $movie): ?>
                    <div class="col-xl-3 col-lg-4 col-sm-6">
                        <div class="movie-card">
                            <div class="movie-image-container">
                                <?php 
                                    $ratingClass = strtolower(str_replace(' ', '', $movie['rating']));
                                    if (!in_array($ratingClass, ['p', 't16', 't18', 'k'])) $ratingClass = 'other';
                                ?>
                                <span class="rating-badge <?php echo $ratingClass; ?>">2D | <?php echo htmlspecialchars($movie['rating']); ?></span>
                                <img src="<?php echo getMoviePosterUrl($movie['image'], $movie['title']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                <div class="movie-overlay">
                                    <a href="movie-detail.php?id=<?php echo $movie['id']; ?>" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-ticket me-1"></i> Đặt vé</a>
                                    <?php if (!empty($movie['trailer_url'])): ?>
                                        <a href="<?php echo htmlspecialchars($movie['trailer_url']); ?>" target="_blank" class="btn btn-outline-light text-uppercase fw-bold"><i class="fa-solid fa-play me-1"></i> Trailer</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="movie-info">
                                <h3 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                <div class="movie-meta"><?php echo $movie['duration']; ?> phút | <?php echo date('d/m/Y', strtotime($movie['release_date'])); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- SECTION 2: PHIM SẮP CHIẾU -->
        <section id="phim-sap-chieu" class="py-4">
            <div class="section-title-container">
                <h2 class="section-title">Phim Sắp Chiếu</h2>
            </div>
            
            <div class="row">
                <?php foreach ($comingMovies as $movie): ?>
                    <div class="col-xl-3 col-lg-4 col-sm-6">
                        <div class="movie-card">
                            <div class="movie-image-container">
                                <?php 
                                    $ratingClass = strtolower(str_replace(' ', '', $movie['rating']));
                                    if (!in_array($ratingClass, ['p', 't16', 't18', 'k'])) $ratingClass = 'other';
                                ?>
                                <span class="rating-badge <?php echo $ratingClass; ?>">2D | <?php echo htmlspecialchars($movie['rating']); ?></span>
                                <img src="<?php echo getMoviePosterUrl($movie['image'], $movie['title']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>">
                                <div class="movie-overlay">
                                    <a href="movie-detail.php?id=<?php echo $movie['id']; ?>" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-ticket me-1"></i> Chi tiết</a>
                                    <?php if (!empty($movie['trailer_url'])): ?>
                                        <a href="<?php echo htmlspecialchars($movie['trailer_url']); ?>" target="_blank" class="btn btn-outline-light text-uppercase fw-bold"><i class="fa-solid fa-play me-1"></i> Trailer</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="movie-info">
                                <h3 class="movie-title"><?php echo htmlspecialchars($movie['title']); ?></h3>
                                <div class="movie-meta"><?php echo $movie['duration']; ?> phút | Dự kiến: <?php echo date('d/m/Y', strtotime($movie['release_date'])); ?></div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endif; ?>

</div>


<?php
require_once __DIR__ . '/views/footer.php';
?>
