# BÁO CÁO ĐỒ ÁN MÔN HỌC: LẬP TRÌNH WEB
## ĐỀ TÀI: XÂY DỰNG WEBSITE ĐẶT VÉ XEM PHIM CINESTAR CLONE
### HỆ THỐNG QUẢN LÝ ĐẶT VÉ & BẮP NƯỚC TRỰC TUYẾN DỰA TRÊN PHP OOP & MYSQL

---

## MỤC LỤC
1. [GIỚI THIỆU TỔNG QUAN ĐỀ TÀI](#1-giới-thiệu-tổng-quan-đề-tài)
   * 1.1. Lý do chọn đề tài
   * 1.2. Mục tiêu nghiên cứu và phát triển
   * 1.3. Phạm vi ứng dụng
   * 1.4. Đối tượng sử dụng hệ thống
2. [CÔNG NGHỆ VÀ MÔ HÌNH PHÁT TRIỂN](#2-công-nghệ-và-mô-hình-phát-triển)
   * 2.1. Ngôn ngữ PHP 8.x và Lập trình hướng đối tượng (OOP)
   * 2.2. Hệ quản trị cơ sở dữ liệu MySQL và Thư viện PDO
   * 2.3. Công nghệ giao diện (HTML5, CSS3, Bootstrap 5.3, JavaScript, jQuery)
   * 2.4. Công nghệ AJAX và cơ chế cập nhật không tải lại trang
   * 2.5. Kiến trúc thư mục và sơ đồ tổ chức source code
3. [PHÂN TÍCH YÊU CẦU HỆ THỐNG (REQUIREMENTS ANALYSIS)](#3-phân-tích-yêu-cầu-hệ-thống-requirements-analysis)
   * 3.1. Phân tích tác nhân (Actors)
   * 3.2. Sơ đồ Use Case tổng quát
   * 3.3. Đặc tả các Use Case trọng tâm
   * 3.4. Các yêu cầu phi chức năng (Non-functional Requirements)
4. [THIẾT KẾ CƠ SỞ DỮ LIỆU CHI TIẾT](#4-thiết-kế-cơ-sở-dữ-liệu-chi-tiết)
   * 4.1. Sơ đồ thực thể quan hệ (ERD Diagram)
   * 4.2. Thiết kế chi tiết các bảng dữ liệu
   * 4.3. Ràng buộc toàn vẹn và toàn vẹn tham chiếu CSDL
   * 4.4. Cơ chế cài đặt tự động (Auto Installer & Seeder)
5. [THIẾT KẾ KIẾN TRÚC LỚP & ĐỐI TƯỢNG (OOP CLASS DESIGN)](#5-thiết-kế-kiến-trúc-lớp--đối-tượng-oop-class-design)
   * 5.1. Sơ đồ Class Diagram
   * 5.2. Lớp Database và thiết kế Singleton Pattern
   * 5.3. Đặc tả chi tiết 7 lớp Model
   * 5.4. Ví dụ code triển khai các Model
6. [MÔ TẢ CHI TIẾT CÁC CHỨC NĂNG HỆ THỐNG](#6-mô-tả-chi-tiết-các-chức-năng-hệ-thống)
   * 6.1. Phân hệ Khách hàng / Thành viên công cộng
   * 6.2. Nghiệp vụ Chọn ghế và Tính tiền động (Booking Flow)
   * 6.3. Xử lý Combo bắp nước và lưu trữ JSON Concessions
   * 6.4. Phân hệ Quản trị viên (Admin Area)
7. [LUỒNG XỬ LÝ NGHIỆP VỤ & SƠ ĐỒ TUẦN TỰ (SEQUENCE DIAGRAM)](#7-luồng-xử-lý-nghiệp-vụ--sơ-đồ-tuần-tự-sequence-diagram)
   * 7.1. Sơ đồ tuần tự luồng Đặt vé trực tuyến
   * 7.2. Sơ đồ tuần tự luồng AJAX Đặt vé nhanh tại trang chủ
8. [GIAO DIỆN HỆ THỐNG & HƯỚNG DẪN SỬ DỤNG](#8-giao-diện-hệ-thống--hướng-dẫn-sử-dụng)
   * 8.1. Hướng dẫn cài đặt chi tiết trên môi trường cục bộ
   * 8.2. Tài khoản kiểm thử hệ thống
   * 8.3. Mô tả các màn hình giao diện kèm phân tích thiết kế UI/UX
9. [KIỂM THỬ HỆ THỐNG (TESTING & VALIDATION)](#9-kiểm-thử-hệ-thống-testing--validation)
   * 9.1. Kịch bản kiểm thử (Test Cases) các chức năng chính
   * 9.2. Đánh giá kết quả kiểm thử thực tế
10. [KẾT LUẬN & HƯỚNG PHÁT TRIỂN](#10-kết-luận--hướng-phát-triển)
    * 10.1. Các kết quả đã đạt được
    * 10.2. Hạn chế hiện tại của đồ án
    * 10.3. Đề xuất hướng phát triển tiếp theo

---

## 1. GIỚI THIỆU TỔNG QUAN ĐỀ TÀI

### 1.1. Lý do chọn đề tài
Trong kỷ nguyên số hóa hiện nay, nhu cầu giải trí tinh thần thông qua môn nghệ thuật thứ bảy ngày càng tăng cao. Hoạt động xếp hàng chờ mua vé xem phim truyền thống tại quầy rạp đã bộc lộ nhiều hạn chế lớn như: mất thời gian, không chủ động chọn lựa được vị trí ghế ngồi mong muốn, và dễ xảy ra tình trạng hết vé vào các khung giờ cao điểm hoặc dịp lễ Tết.

Với sự phát triển mạnh mẽ của thương mại điện tử, các hệ thống rạp chiếu phim hàng đầu Việt Nam như **Cinestar Cinemas** đã và đang đẩy mạnh các cổng dịch vụ đặt vé trực tuyến. Nhằm áp dụng các kiến thức đã học về phát triển ứng dụng web, lập trình hướng đối tượng (OOP) bằng ngôn ngữ PHP, thiết kế cơ sở dữ liệu MySQL và kỹ thuật tương tác Client-Server bằng AJAX/jQuery, đề tài **"Xây dựng Website đặt vé xem phim Cinestar Clone"** đã được lựa chọn.

Đồ án không chỉ dừng lại ở mức độ mô phỏng giao diện tĩnh mà còn hướng đến việc giải quyết trọn vẹn bài toán nghiệp vụ mua vé phim kết hợp bắp nước, quản lý phòng chiếu thực tế với sơ đồ ghế tương tác động, mang lại trải nghiệm tiện lợi tối đa cho khách hàng và bộ công cụ quản trị thông minh cho đơn vị vận hành rạp.

### 1.2. Mục tiêu nghiên cứu và phát triển
*   **Về mặt lý thuyết:** Hệ thống hóa kiến thức lập trình hướng đối tượng (OOP) trong ngôn ngữ PHP, làm chủ thư viện PDO kết nối cơ sở dữ liệu an toàn, và tìm hiểu sâu về kỹ thuật bất đồng bộ AJAX trong thiết kế trải nghiệm người dùng Web UI/UX.
*   **Về mặt thực tiễn:** Xây dựng một sản phẩm phần mềm hoàn chỉnh có giao diện tối huyền ảo tương thích tốt trên máy tính và thiết bị di động (Responsive Web Design). Tích hợp sơ đồ phòng chiếu động cho phép chọn ghế, phân loại ghế Thường/VIP, bán bắp nước và quản trị cơ sở dữ liệu đa chiều (phim, lịch chiếu, tài khoản, bắp nước, hóa đơn giao dịch).

### 1.3. Phạm vi ứng dụng
Website được triển khai thử nghiệm trên môi trường máy chủ cục bộ (local server) sử dụng phần mềm giả lập XAMPP hoặc Laragon, có khả năng cấu hình và triển khai trực tiếp lên các nền tảng hosting hỗ trợ PHP và MySQL phổ biến. Ứng dụng phục vụ cho việc đặt vé xem phim tại các rạp phim giả lập dựa trên mô hình hoạt động thực tế của chuỗi rạp Cinestar Việt Nam.

### 1.4. Đối tượng sử dụng hệ thống
*   **Khách vãng lai (Guest):** Tìm kiếm thông tin phim, xem lịch chiếu của từng cụm rạp, theo dõi các chương trình ưu đãi khuyến mãi, và đăng ký tài khoản thành viên.
*   **Thành viên đã đăng nhập (Member):** Thực hiện luồng đặt vé nhanh hoặc đặt vé trực tiếp tại trang chi tiết phim, lựa chọn vị trí ghế ngồi trên sơ đồ, mua bắp nước đi kèm, thanh toán giả lập, quản lý hồ sơ cá nhân và tra cứu lịch sử hóa đơn vé đã đặt.
*   **Quản trị viên (Admin):** Vận hành hệ thống thông qua trang quản trị, theo dõi doanh thu thời gian thực, quản lý phim (CRUD), quản lý suất chiếu (CRUD), quản lý danh sách thành viên, cấu hình banner slide quảng cáo và danh mục menu concessions bắp nước.

---

## 2. CÔNG NGHỆ VÀ MÔ HÌNH PHÁT TRIỂN

### 2.1. Ngôn ngữ PHP 8.x và Lập trình hướng đối tượng (OOP)
PHP 8.x là ngôn ngữ lập trình kịch bản phía máy chủ (Server-side Scripting Language) mạnh mẽ, cung cấp hiệu năng vượt trội nhờ bộ biên dịch JIT và cú pháp OOP cải tiến. 

Đồ án ứng dụng triệt để tư duy Lập trình hướng đối tượng (OOP) để xây dựng hệ thống. Toàn bộ logic nghiệp vụ được đóng gói trong các lớp thực thể (Model Classes). Cấu trúc lớp này giúp mã nguồn trở nên sáng sủa, tách biệt rạch ròi trách nhiệm, nâng cao tính tái sử dụng, đồng thời đơn giản hóa công tác bảo trì và mở rộng tính năng về sau.

### 2.2. Hệ quản trị cơ sở dữ liệu MySQL và Thư viện PDO
Cơ sở dữ liệu quan hệ MySQL được lựa chọn để lưu trữ thông tin hệ thống rạp phim. Mọi thao tác truy vấn dữ liệu từ PHP tới MySQL đều được thực hiện thông qua **PDO (PHP Data Objects)**.
*   PDO cung cấp một lớp trừu tượng kết nối cơ sở dữ liệu đồng nhất.
*   Sử dụng cơ chế **Prepared Statements** để liên kết tham số (Parameter Binding), ngăn chặn hoàn toàn nguy cơ tấn công **SQL Injection** — lỗ hổng bảo mật phổ biến nhất trên các ứng dụng PHP thuần cổ điển.

### 2.3. Công nghệ giao diện (HTML5, CSS3, Bootstrap 5.3, JavaScript, jQuery)
*   **HTML5 Semantic Elements:** Sử dụng cấu trúc HTML rõ ràng giúp tối ưu hóa công cụ tìm kiếm (SEO) và hỗ trợ tốt cho việc phân tích cây DOM.
*   **CSS3 Custom (Cinestar Theme):** Xây dựng một bảng mã màu và cấu trúc style chuyên biệt. Kết hợp các thuộc tính chuyển động `transition`, `transform` và `animation` tạo nên hiệu ứng đổi màu tím/vàng neon đặc trưng của rạp phim Cinestar khi rê chuột vào các nút hoặc thẻ phim.
*   **Bootstrap 5.3 Framework:** Hỗ trợ hệ thống lưới Grid System chia cột linh hoạt, giúp website tự động co giãn hiển thị mượt mà trên mọi màn hình di động, máy tính bảng và màn hình máy tính để bàn PC.
*   **JavaScript (ES6+) & jQuery:** Xử lý toàn bộ logic tương tác ở Client-side như tính toán hóa đơn chọn ghế động, kiểm tra dữ liệu đầu vào của các biểu mẫu (Form Validation) trước khi gửi lên Server.

### 2.4. Công nghệ AJAX và cơ chế cập nhật không tải lại trang
AJAX (Asynchronous JavaScript and XML) là kỹ thuật then chốt giúp tối ưu hóa trải nghiệm người dùng tại trang chủ và trang đặt vé. Thay vì tải lại toàn bộ trang web khi người dùng thay đổi lựa chọn rạp chiếu, JavaScript sẽ gửi một yêu cầu ngầm dưới nền đến file API của Server, nhận về dữ liệu định dạng **JSON**, sau đó cập nhật động các thẻ HTML tương ứng. Điều này làm giảm đáng kể băng thông đường truyền và loại bỏ hoàn toàn hiện tượng nhấp nháy màn hình khi tải lại trang.

### 2.5. Kiến trúc thư mục và sơ đồ tổ chức source code
Dự án được phân cấp logic chặt chẽ trong thư mục gốc `rapphim/` nhằm đảm bảo tính cấu trúc khoa học:

```
c:\xampp\htdocs\rapphim\
│
├── admin\                   # Phân hệ quản lý Admin Panel
│   ├── index.php            # Dashboard thống kê doanh thu & giao dịch
│   ├── movies.php           # CRUD quản lý danh sách phim
│   ├── showtimes.php        # CRUD quản lý lịch chiếu phim
│   ├── users.php            # CRUD quản lý danh sách thành viên
│   ├── concessions.php      # CRUD quản lý combo bắp nước
│   ├── banners.php          # CRUD quản lý banner quảng cáo trang chủ
│   ├── header.php           # Giao diện đầu trang quản trị
│   └── footer.php           # Giao diện cuối trang quản trị
│
├── config\                  # Cấu hình hệ thống
│   └── Database.php         # Lớp kết nối PDO, Auto DB Installer & Seeder
│
├── models\                  # Lớp đối tượng nghiệp vụ (OOP Models)
│   ├── User.php             # Quản lý đăng ký, đăng nhập, phân quyền, hồ sơ
│   ├── Movie.php            # Nghiệp vụ danh sách phim đang/sắp chiếu, tìm kiếm
│   ├── Cinema.php           # Truy xuất thông tin các cụm rạp phim
│   ├── Showtime.php         # Truy xuất lịch chiếu đa tầng phục vụ AJAX
│   ├── Booking.php          # Giao dịch vé & bắp nước, lịch sử mua vé
│   ├── Concession.php       # Danh mục combo bắp nước
│   └── Banner.php           # Danh mục banner slide quảng cáo trang chủ
│
├── views\                   # Giao diện dùng chung cho Client
│   ├── header.php           # Thanh điều hướng (Navbar) & meta tags SEO
│   └── footer.php           # Chân trang thông tin bản quyền & liên hệ
│
├── assets\                  # Thư mục chứa tài nguyên tĩnh
│   ├── css\                 # Các file stylesheet CSS (Bootstrap & Custom)
│   ├── js\                  # Các file script xử lý tương tác client-side & AJAX
│   ├── images\              # Kho poster phim, icon và ảnh chụp màn hình demo
│   └── videos\              # Video trailer phim quảng cáo
│
├── index.php                # Trang chủ chính của ứng dụng
├── about.php                # Trang giới thiệu rạp phim Cinestar
├── events.php               # Trang hiển thị sự kiện đang diễn ra
├── promotions.php           # Trang chương trình khuyến mãi, ưu đãi vé
├── concessions.php          # Trang giới thiệu bắp nước công cộng
├── movie-detail.php         # Trang chi tiết phim & lịch chiếu tương ứng
├── booking.php              # Sơ đồ phòng chiếu đặt ghế & bắp nước
├── profile.php              # Quản lý hồ sơ cá nhân và hiển thị biên lai đặt vé
├── login.php                # Trang đăng nhập thành viên
├── register.php             # Trang đăng ký tài khoản thành viên
├── logout.php               # File xử lý đăng xuất, xóa session
└── ajax-quick-book.php      # Router API nhận yêu cầu AJAX đặt vé nhanh
```

---

## 3. PHÂN TÍCH YÊU CẦU HỆ THỐNG (REQUIREMENTS ANALYSIS)

### 3.1. Phân tích tác nhân (Actors)
Hệ thống xác định rõ 3 nhóm đối tượng tác nhân chính tương tác với ứng dụng:
1.  **Khách vãng lai (Guest):** Người truy cập chưa xác thực thông tin. Chỉ có quyền đọc thông tin giới thiệu, danh sách phim, lịch chiếu phim và đăng ký tài khoản thành viên mới.
2.  **Thành viên (Member):** Khách hàng đã có tài khoản và đăng nhập thành công vào hệ thống. Được phép thực hiện đặt vé xem phim, mua bắp nước kèm vé, quản lý hồ sơ cá nhân và tra cứu lịch sử mua vé.
3.  **Quản trị viên (Admin):** Người điều hành rạp phim. Có toàn quyền truy cập phân hệ Admin Panel để quản lý cơ sở dữ liệu và giám sát doanh thu rạp.

### 3.2. Sơ đồ Use Case tổng quát
Dưới đây là sơ đồ Use Case biểu diễn các mối quan hệ tương tác giữa các tác nhân và chức năng hệ thống:

```mermaid
rect rgb(20, 20, 30)
  note right of Guest: Chưa đăng nhập
  note right of Member: Đăng nhập cấp 1
  note right of Admin: Đăng nhập cấp 2 (Quyền Admin)
end

graph TD
  Guest((Khách vãng lai)) --> UC_XemPhim(Xem danh sách phim & chi tiết)
  Guest --> UC_XemLichChieu(Xem lịch chiếu phim)
  Guest --> UC_DangKy(Đăng ký tài khoản)
  Guest --> UC_DangNhap(Đăng nhập)

  Member((Thành viên)) --> UC_DangNhap
  Member --> UC_DatVe(Đặt vé phim & Chọn ghế)
  Member --> UC_MuaBapNuoc(Mua bắp nước kèm vé)
  Member --> UC_XemProfile(Quản lý hồ sơ cá nhân)
  Member --> UC_LichSu(Xem lịch sử vé & In biên lai)

  Admin((Quản trị viên)) --> UC_LoginAdmin(Đăng nhập trang Admin)
  Admin --> UC_ThongKe(Xem doanh thu & Dashboard)
  Admin --> UC_CRUDMovies(CRUD Quản lý Phim)
  Admin --> UC_CRUDShowtimes(CRUD Quản lý Lịch chiếu)
  Admin --> UC_CRUDUsers(CRUD Quản lý Thành viên)
  Admin --> UC_CRUDConcessions(CRUD Quản lý Bắp nước)
  Admin --> UC_CRUDBanners(CRUD Quản lý Banner)
```

### 3.3. Đặc tả các Use Case trọng tâm

#### Use Case: Đặt vé xem phim và Chọn ghế trực quan
*   **Tác nhân chính:** Thành viên (Member).
*   **Mô tả:** Khách hàng tiến hành lựa chọn các ghế trống trên sơ đồ rạp chiếu và mua thêm bắp nước, sau đó xác nhận giao dịch để lưu thông tin vé.
*   **Điều kiện tiên quyết:** Khách hàng phải đăng nhập tài khoản thành viên thành công và suất chiếu được chọn phải có trạng thái khả dụng.
*   **Luồng sự kiện chính:**
    1. Khách hàng truy cập trang đặt vé thông qua lịch chiếu của phim.
    2. Hệ thống gọi phương thức truy xuất danh sách ghế đã được bán của suất chiếu đó để khóa những ghế không thể đặt.
    3. Hệ thống render sơ đồ rạp lên trình duyệt của khách hàng.
    4. Khách hàng click chọn vị trí ghế (hệ thống tự động tính phụ phí nếu chọn ghế VIP).
    5. Khách hàng lựa chọn số lượng combo bắp nước đi kèm (nếu có).
    6. Hệ thống hiển thị tổng tiền cần thanh toán theo thời gian thực.
    7. Khách hàng bấm xác nhận đặt vé.
    8. Hệ thống lưu trữ giao dịch vào bảng `bookings` trong cơ sở dữ liệu, đồng thời ghi nhận danh sách ghế đã chọn và các combo bắp nước dạng JSON.
    9. Hệ thống thông báo giao dịch thành công và chuyển hướng người dùng về trang cá nhân để xem biên lai.

#### Use Case: Quản lý suất chiếu (Showtimes CRUD)
*   **Tác nhân chính:** Quản trị viên (Admin).
*   **Mô tả:** Admin thiết lập lịch chiếu phim mới cho các cụm rạp, bao gồm ngày chiếu, giờ chiếu và mức giá vé cơ bản.
*   **Điều kiện tiên quyết:** Admin đã đăng nhập thành công vào phân hệ quản trị.
*   **Luồng sự kiện chính:**
    1. Admin truy cập mục quản lý lịch chiếu tại trang Admin.
    2. Hệ thống hiển thị bảng danh sách các suất chiếu hiện tại kèm bộ lọc tìm kiếm.
    3. Admin chọn "Thêm suất chiếu mới".
    4. Admin chọn Phim, chọn Cụm rạp chiếu, chọn Ngày chiếu, giờ chiếu và nhập mức giá vé cơ bản.
    5. Admin bấm "Lưu".
    6. Hệ thống kiểm tra tính hợp lệ của thời gian chiếu và lưu dữ liệu mới vào bảng `showtimes`.
    7. Hệ thống hiển thị thông báo thành công và cập nhật lại danh sách lịch chiếu trên màn hình.

### 3.4. Các yêu cầu phi chức năng (Non-functional Requirements)
*   **Tính bảo mật (Security):** Mật khẩu người dùng bắt buộc phải được băm bảo mật bằng thuật toán mã hóa một chiều an toàn (bcrypt). Các truy vấn SQL kết nối đến CSDL MySQL bắt buộc phải sử dụng cơ chế Prepared Statement của thư viện PDO để ngăn chặn tấn công SQL Injection. Các trang trong thư mục Admin bắt buộc phải kiểm tra quyền hạn Session ở đầu trang và chuyển hướng về trang chủ nếu tài khoản cố tình truy cập không có quyền Admin.
*   **Hiệu năng (Performance):** Tối giản mã nguồn, kết nối cơ sở dữ liệu dạng Singleton để tránh lãng phí bộ nhớ kết nối máy chủ. Tích hợp AJAX cập nhật bất đồng bộ ở trang chủ giúp tải trang nhanh và giảm thiểu tải lên máy chủ Web server.
*   **Tính thân thiện (Usability):** Giao diện dark mode hiện đại, kích thước các nút bấm và vùng chọn ghế rõ ràng, hỗ trợ responsive hoàn toàn trên các thiết bị di động.

---

## 4. THIẾT KẾ CƠ SỞ DỮ LIỆU CHI TIẾT

### 4.1. Sơ đồ thực thể quan hệ (ERD Diagram)
Hệ thống sử dụng cơ sở dữ liệu quan hệ được chuẩn hóa ở mức 3NF nhằm loại bỏ các dữ liệu dư thừa và đảm bảo tính nhất quán cao của thông tin.

```
       +-----------------------+              +-----------------------+
       |         users         |              |        cinemas        |
       +-----------------------+              +-----------------------+
       | PK | id               |              | PK | id               |
       |    | username         |              |    | name             |
       |    | password         |              |    | address          |
       |    | email            |              +-----------------------+
       |    | fullname         |                          |
       |    | phone            |                          | 1
       |    | role             |                          |
       +-----------------------+                          |
                   | 1                                    | N
                   |                                      v
                   |                            +-----------------------+
                   |                            |       showtimes       |
                   |                            +-----------------------+
                   |                            | PK | id               |
                   |                            | FK | movie_id         |---
                   |                            | FK | cinema_id        |  |
                   |                            |    | show_date        |  |
                   |                            |    | show_time        |  |
                   |                            |    | price            |  |
                   |                            +-----------------------+  |
                   |                                       |               |
                   | 1                                     | 1             |
                   |                                       |               |
                   v N                                     v N             |
       +-----------------------+               +-----------------------+   |
       |       bookings        |               |        movies         |   |
       +-----------------------+               +-----------------------+   |
       | PK | id               |               | PK | id               |   |
       | FK | user_id          |               |    | title            |   |
       | FK | showtime_id      |               |    | description      |   |
       |    | seats            |               |    | image            |   |
       |    | concessions      |               |    | duration         |   |
       |    | total_price      |               |    | release_date     |   |
       |    | booking_date     |               |    | rating           |   |
       +-----------------------+               |    | status           |   |
                                               |    | trailer_url      |   |
                                               +-----------------------+   |
                                                           ^               |
                                                           |               |
                                                           -----------------
```

### 4.2. Thiết kế chi tiết các bảng dữ liệu

#### Bảng `users` (Quản lý tài khoản)
Bảng này lưu trữ thông tin tài khoản đăng nhập của toàn bộ thành viên và quản trị viên trong hệ thống.

| Trường | Kiểu dữ liệu | Thuộc tính | Mô tả |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Mã số định danh duy nhất của người dùng |
| `username` | `VARCHAR(50)` | `NOT NULL`, `UNIQUE` | Tên tài khoản đăng nhập |
| `password` | `VARCHAR(255)` | `NOT NULL` | Mật khẩu tài khoản (đã mã hóa bcrypt hash) |
| `email` | `VARCHAR(100)` | `NOT NULL` | Địa chỉ thư điện tử của thành viên |
| `fullname` | `VARCHAR(100)` | `NOT NULL` | Họ và tên đầy đủ của thành viên |
| `phone` | `VARCHAR(20)` | `NULL` | Số điện thoại liên lạc |
| `role` | `VARCHAR(20)` | `DEFAULT 'member'` | Vai trò tài khoản (`member` hoặc `admin`) |

#### Bảng `movies` (Quản lý danh sách phim)
Lưu trữ toàn bộ dữ liệu liên quan đến bộ phim được chiếu tại các cụm rạp.

| Trường | Kiểu dữ liệu | Thuộc tính | Mô tả |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Mã số định danh duy nhất của bộ phim |
| `title` | `VARCHAR(255)` | `NOT NULL` | Tiêu đề phim |
| `description` | `TEXT` | `NULL` | Mô tả tóm tắt nội dung cốt truyện của phim |
| `image` | `VARCHAR(255)` | `NULL` | Tên tệp tin poster phim lưu tại thư mục hệ thống |
| `duration` | `INT` | `NOT NULL` | Thời lượng phim (tính bằng phút) |
| `release_date` | `DATE` | `NULL` | Ngày công chiếu chính thức |
| `rating` | `VARCHAR(10)` | `DEFAULT 'P'` | Giới hạn độ tuổi (P, T13, T16, T18) |
| `status` | `VARCHAR(50)` | `DEFAULT 'showing'` | Trạng thái phát hành (`showing` hoặc `coming`) |
| `trailer_url` | `VARCHAR(255)` | `NULL` | Đường dẫn trailer nhúng YouTube của phim |

#### Bảng `cinemas` (Quản lý cụm rạp)
Lưu trữ thông tin các chi nhánh cụm rạp chiếu phim trong hệ thống Cinestar.

| Trường | Kiểu dữ liệu | Thuộc tính | Mô tả |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Mã định danh cụm rạp chiếu |
| `name` | `VARCHAR(100)` | `NOT NULL` | Tên cụm rạp (ví dụ: Cinestar Quốc Thanh) |
| `address` | `VARCHAR(255)` | `NOT NULL` | Địa chỉ chi tiết cụm rạp |

#### Bảng `showtimes` (Quản lý lịch chiếu phim)
Bảng trung gian liên kết Phim với Rạp cụ thể theo ngày và giờ chiếu.

| Trường | Kiểu dữ liệu | Thuộc tính | Mô tả |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Mã định danh suất chiếu |
| `movie_id` | `INT` | `FOREIGN KEY`, `NOT NULL` | Liên kết đến khóa chính [Movie.id](file:///c:/xampp/htdocs/rapphim/models/Movie.php) |
| `cinema_id` | `INT` | `FOREIGN KEY`, `NOT NULL` | Liên kết đến khóa chính [Cinema.id](file:///c:/xampp/htdocs/rapphim/models/Cinema.php) |
| `show_date` | `DATE` | `NOT NULL` | Ngày chiếu phim |
| `show_time` | `TIME` | `NOT NULL` | Khung giờ bắt đầu suất chiếu |
| `price` | `DECIMAL(15,2)` | `NOT NULL` | Giá vé cơ bản cho suất chiếu |

#### Bảng `bookings` (Quản lý giao dịch đặt vé)
Lưu trữ tất cả các hóa đơn vé phim kết hợp bắp nước được đặt thành công.

| Trường | Kiểu dữ liệu | Thuộc tính | Mô tả |
| :--- | :--- | :--- | :--- |
| `id` | `INT` | `PRIMARY KEY`, `AUTO_INCREMENT` | Mã số hóa đơn đặt vé |
| `user_id` | `INT` | `FOREIGN KEY`, `NOT NULL` | Người đặt vé, liên kết [User.id](file:///c:/xampp/htdocs/rapphim/models/User.php) |
| `showtime_id` | `INT` | `FOREIGN KEY`, `NOT NULL` | Suất chiếu phim, liên kết [Showtime.id](file:///c:/xampp/htdocs/rapphim/models/Showtime.php) |
| `seats` | `TEXT` | `NOT NULL` | Danh sách ghế đã chọn, lưu dạng `"A1,A2"` |
| `concessions` | `TEXT` | `NULL` | Danh mục bắp nước đi kèm dạng chuỗi mã hóa JSON |
| `total_price` | `DECIMAL(15,2)` | `NOT NULL` | Tổng tiền thanh toán của hóa đơn |
| `booking_date` | `DATETIME` | `NOT NULL` | Ngày giờ thực hiện giao dịch mua vé |

### 4.3. Ràng buộc toàn vẹn và toàn vẹn tham chiếu CSDL
Để đảm bảo tính nhất quán dữ liệu của toàn bộ hệ thống rạp phim khi xảy ra thao tác xóa từ phía quản trị viên, các khóa ngoại được cấu hình thuộc tính ràng buộc **`ON DELETE CASCADE`**:
*   Khi Admin thực hiện xóa một bộ phim trong bảng `movies`, toàn bộ các suất chiếu tương ứng của phim đó trong bảng `showtimes` và các hóa đơn vé liên quan trong bảng `bookings` sẽ tự động bị MySQL xóa sạch ngầm. Điều này tránh lỗi mồ côi dữ liệu (Orphaned Rows) gây crash hệ thống ở phía Client.
*   Tương tự, khi xóa một cụm rạp `cinemas` hoặc một tài khoản `users`, các thông tin suất chiếu hoặc hóa đơn tương ứng sẽ được tự động đồng bộ dọn dẹp sạch sẽ.

### 4.4. Cơ chế cài đặt tự động (Auto Installer & Seeder)
Thay vì bắt buộc người dùng cài đặt ứng dụng phải vào phpMyAdmin tạo cơ sở dữ liệu và import file `.sql` thủ công, lớp [Database](file:///c:/xampp/htdocs/rapphim/config/Database.php) được thiết kế tích hợp một bộ sinh cấu trúc tự động (Auto DB Builder).
*   **Khởi tạo Database:** Sử dụng truy vấn kết nối sơ cấp không chỉ định DB, kiểm tra nếu `rapphim` chưa có thì tạo mới với mã hóa tiếng Việt `utf8mb4_unicode_ci`.
*   **Khởi tạo các bảng:** Thực hiện chạy tuần tự các câu lệnh `CREATE TABLE IF NOT EXISTS` để tạo cấu trúc 5 bảng dữ liệu nêu trên kèm theo bảng `banners` và `concessions` (bắp nước quản trị).
*   **Seeder nạp dữ liệu mẫu:** Kiểm tra nếu bảng `movies` hoặc `cinemas` đang rỗng, lớp sẽ tự động nạp các bản ghi mẫu thực tế:
    *   Tạo tài khoản quản trị viên: `admin` / mật khẩu: `admin123`
    *   Tạo tài khoản thành viên mẫu: `member` / mật khẩu: `member123`
    *   Nạp 5 cụm rạp Cinestar lớn tại miền Nam.
    *   Nạp danh sách các phim đang chiếu và sắp chiếu cùng với các khung giờ lịch chiếu mẫu.
    *   Nạp các combo bắp nước bao gồm Solo Combo, Twin Combo, Party Combo cùng hình ảnh minh họa tương ứng.

---

## 5. THIẾT KẾ KIẾN TRÚC LỚP & ĐỐI TƯỢNG (OOP CLASS DESIGN)

### 5.1. Sơ đồ Class Diagram
Dưới đây là sơ đồ lớp (Class Diagram) thể hiện mối liên kết giữa các Model với lớp cơ sở Database kết nối dữ liệu:

```mermaid
classDiagram
  class Database {
    -static instance : Database
    -pdo : PDO
    -construct()
    +static getInstance() : Database
    +getConnection() : PDO
    -createTables()
    -seedData()
  }

  class User {
    -db : PDO
    +login(username, password) : bool
    +register(username, password, email, fullname, phone) : bool
    +updateProfile(id, fullname, phone) : bool
    +changePassword(id, oldPassword, newPassword) : bool
    +getAllUsers() : array
    +deleteUser(id) : bool
    +updateUserRole(id, role) : bool
  }

  class Movie {
    -db : PDO
    +getNowShowing() : array
    +getComingSoon() : array
    +getById(id) : array
    +search(keyword) : array
    +create(title, desc, image, duration, date, rating, status, trailer) : bool
    +update(id, title, desc, image, duration, date, rating, status, trailer) : bool
    +delete(id) : bool
  }

  class Cinema {
    -db : PDO
    +getAll() : array
    +getById(id) : array
    +create(name, address) : bool
    +delete(id) : bool
  }

  class Showtime {
    -db : PDO
    +getMoviesByCinema(cinemaId) : array
    +getDatesByMovieAndCinema(movieId, cinemaId) : array
    +getTimesByDate(movieId, cinemaId, date) : array
    +create(movieId, cinemaId, date, time, price) : bool
    +delete(id) : bool
  }

  class Booking {
    -db : PDO
    +create(userId, showtimeId, seats, concessions, totalPrice) : bool
    +getBookedSeats(showtimeId) : array
    +getUserHistory(userId) : array
    +getAllBookings() : array
  }

  class Concession {
    -db : PDO
    +getAll() : array
    +create(name, desc, price, image) : bool
    +update(id, name, desc, price, image) : bool
    +delete(id) : bool
  }

  Database <-- User : Sử dụng PDO
  Database <-- Movie : Sử dụng PDO
  Database <-- Cinema : Sử dụng PDO
  Database <-- Showtime : Sử dụng PDO
  Database <-- Booking : Sử dụng PDO
  Database <-- Concession : Sử dụng PDO
```

### 5.2. Lớp Database và thiết kế Singleton Pattern
Lớp [Database](file:///c:/xampp/htdocs/rapphim/config/Database.php) đóng vai trò trung tâm cung cấp kết nối CSDL trong toàn ứng dụng. Để tối ưu hóa tài nguyên hệ thống, lớp này triển khai mẫu thiết kế **Singleton Pattern**:
*   Thuộc tính `$instance` được khai báo dạng tĩnh (`static`) nhằm lưu giữ thực thể duy nhất của lớp.
*   Phương thức khởi dựng `__construct()` được cấu hình thuộc tính truy cập là `private`, ngăn chặn việc khởi tạo đối tượng trực tiếp bằng từ khóa `new` ngoài lớp.
*   Phương thức tĩnh `getInstance()` kiểm tra nếu `$instance` chưa được khởi tạo thì mới tiến hành cài đặt kết nối và trả về, đảm bảo trong một chu trình yêu cầu của ứng dụng chỉ tồn tại duy nhất một kết nối MySQL được mở.

### 5.3. Đặc tả chi tiết 7 lớp Model
1.  **Lớp [User](file:///c:/xampp/htdocs/rapphim/models/User.php):** Xử lý toàn bộ các tính năng bảo mật tài khoản. Mã hóa mật khẩu người dùng đăng ký thông qua hàm băm `password_hash()` với thuật toán `PASSWORD_BCRYPT`. Hàm `login()` sử dụng `password_verify()` để so sánh đối chiếu chuỗi băm lưu dưới CSDL, thiết lập thông tin phiên làm việc (Session) bao gồm `user_id`, `username`, và `role`.
2.  **Lớp [Movie](file:///c:/xampp/htdocs/rapphim/models/Movie.php):** Quản lý trạng thái hiển thị của các bộ phim. Hỗ trợ phân trang, tìm kiếm động (chuẩn hóa đầu vào loại bỏ ký tự lạ) và thực hiện nghiệp vụ CRUD tải lên poster phim dạng file ảnh vật lý lên thư mục hệ thống `assets/images/`.
3.  **Lớp [Cinema](file:///c:/xampp/htdocs/rapphim/models/Cinema.php):** Trả về danh sách rạp và chi tiết địa chỉ chi nhánh. Phục vụ hiển thị trên thanh chọn rạp đặt vé nhanh và phân chia lịch chiếu.
4.  **Lớp [Showtime](file:///c:/xampp/htdocs/rapphim/models/Showtime.php):** Lớp tương tác phức tạp xử lý nghiệp vụ thời gian chiếu. Chứa các phương thức truy vấn danh mục phim theo cụm rạp cụ thể phục vụ luồng nạp động AJAX.
5.  **Lớp [Booking](file:///c:/xampp/htdocs/rapphim/models/Booking.php):** Đóng vai trò thực hiện giao dịch đặt vé. Ghi nhận dữ liệu đặt vé của khách hàng. Phương thức `getBookedSeats($showtime_id)` thực hiện truy vấn tất cả các vé của suất chiếu tương ứng, phân tách các chuỗi ghế được lưu ngăn cách bằng dấu phẩy và gộp lại thành một mảng phẳng các ghế đã bán trả về cho client.
6.  **Lớp [Concession](file:///c:/xampp/htdocs/rapphim/models/Concession.php):** Cung cấp các combo bắp nước bao gồm giá tiền và hình ảnh phục vụ tính toán chi phí gia tăng của khách hàng.
7.  **Lớp [Banner](file:///c:/xampp/htdocs/rapphim/models/Banner.php):** Quản trị danh sách các tệp hình ảnh banner cỡ lớn trình chiếu ngoài trang chủ.

### 5.4. Ví dụ code triển khai các Model
Dưới đây là một phần mã nguồn triển khai nghiệp vụ đặt vé cốt lõi trong lớp [Booking](file:///c:/xampp/htdocs/rapphim/models/Booking.php):

```php
// models/Booking.php
require_once __DIR__ . '/../config/Database.php';

class Booking {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    // Lấy danh sách toàn bộ các ghế đã được đặt cho một suất chiếu cụ thể
    public function getBookedSeats($showtime_id) {
        $query = "SELECT seats FROM bookings WHERE showtime_id = :showtime_id";
        $stmt = $this->db->prepare($query);
        $stmt->bindParam(':showtime_id', $showtime_id, PDO::PARAM_INT);
        $stmt->execute();
        
        $bookedSeats = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            // seats được lưu dạng chuỗi "A1,A2,A3", phân tách thành mảng
            $seatsArray = explode(',', $row['seats']);
            $bookedSeats = array_merge($bookedSeats, $seatsArray);
        }
        // Loại bỏ khoảng trắng thừa và trả về mảng danh sách ghế duy nhất
        return array_map('trim', $bookedSeats);
    }

    // Ghi nhận hóa đơn đặt vé xem phim kết hợp combo bắp nước mới
    public function create($user_id, $showtime_id, $seats, $concessions, $total_price) {
        $query = "INSERT INTO bookings (user_id, showtime_id, seats, concessions, total_price, booking_date) 
                  VALUES (:user_id, :showtime_id, :seats, :concessions, :total_price, NOW())";
        $stmt = $this->db->prepare($query);
        
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':showtime_id', $showtime_id, PDO::PARAM_INT);
        $stmt->bindParam(':seats', $seats, PDO::PARAM_STR);
        $stmt->bindParam(':concessions', $concessions, PDO::PARAM_STR); // Chuỗi JSON
        $stmt->bindParam(':total_price', $total_price);
        
        return $stmt->execute();
    }
}
```

---

## 6. MÔ TẢ CHI TIẾT CÁC CHỨC NĂNG HỆ THỐNG

### 6.1. Phân hệ Khách hàng / Thành viên công cộng
Giao diện người dùng được thiết kế dựa trên phong cách giao diện tối (Dark Theme) đặc trưng của Cinestar với màu tím huyền ảo kết hợp màu vàng kim sang trọng, tạo cảm giác như đang đứng trước phòng vé rạp chiếu phim thực sự. Các chức năng chính bao gồm:
*   **Trang chủ ([index.php](file:///c:/xampp/htdocs/rapphim/index.php)):** Tích hợp slide hoạt họa trình chiếu các bộ phim bom tấn sắp ra mắt. Phía dưới là thanh công cụ **Đặt Vé Nhanh AJAX** cho phép chọn nhanh Suất chiếu mà không phải duyệt tìm kiếm phức tạp.
*   **Danh sách phim đang chiếu / sắp chiếu:** Thiết kế dưới dạng lưới Card chứa poster phim sắc nét. Khi người dùng rê chuột (hover) vào card phim, poster sẽ phóng to nhẹ nhàng kết hợp hiệu ứng trượt mượt mà hiển thị hai nút chức năng: "XEM TRAILER" và "ĐẶT VÉ".
*   **Tìm kiếm phim thời gian thực:** Ô tìm kiếm tích hợp trên thanh Navbar. Người dùng chỉ cần nhập một từ khóa, hệ thống sẽ thực hiện truy vấn đối sánh chuỗi trong cả tên phim lẫn mô tả tóm tắt nội dung cốt truyện của phim để đưa ra các bộ phim khớp nhất.

### 6.2. Nghiệp vụ Chọn ghế và Tính tiền động (Booking Flow)
Sơ đồ phòng chiếu trên trang đặt vé [booking.php](file:///c:/xampp/htdocs/rapphim/booking.php) được thiết kế mô phỏng mô hình phòng chiếu thực tế với:
*   Hàng ghế A, B, C, D: **Ghế Thường (Standard Seats)**, giữ nguyên giá vé gốc của suất chiếu.
*   Hàng ghế E, F, G: **Ghế VIP (VIP Seats)**, có mức giá cao hơn ghế thường `20.000 đ` (được cộng dồn tự động).
*   **Trạng thái khóa ghế:** Đối với các ghế đã có người đặt trước (trùng khớp trong mảng trả về của hàm `getBookedSeats()`), hệ thống sẽ tự động thêm lớp CSS khóa ghế, hiển thị biểu tượng ghế màu đỏ kèm trạng thái không cho phép tương tác nhấp chọn.
*   **Tính tiền động Client-side:** Xây dựng bằng JavaScript. Khi người dùng nhấp chọn hoặc bỏ chọn một chiếc ghế, JavaScript sẽ ngay lập tức tính toán dựa trên mức giá gốc của suất chiếu, cộng thêm phụ phí ghế VIP đã chọn, cộng với tiền bắp nước chọn mua ở khu vực phía dưới và cập nhật tức thì lên tổng tiền hiển thị mà không cần reload trang.

### 6.3. Xử lý Combo bắp nước và lưu trữ JSON Concessions
Hệ thống cho phép khách hàng đặt kèm các sản phẩm bắp nước (Concessions) ngay khi đặt vé để nhận ưu đãi giảm giá 20% so với mua trực tiếp tại quầy rạp.
*   **Thiết kế lưu trữ tối ưu:** Để tránh việc thiết lập thêm bảng chi tiết hóa đơn bắp nước cồng kềnh, hệ thống sử dụng cấu trúc dữ liệu **JSON** để lưu trực tiếp danh mục bắp nước chọn mua vào cột `concessions` thuộc bảng `bookings`.
*   **Định dạng JSON lưu trữ:**
    ```json
    [
      {"name": "Solo Combo", "qty": 1, "price": 85000},
      {"name": "Twin Combo", "qty": 2, "price": 115000}
    ]
    ```
*   **Giải mã dữ liệu (Decoding):** Khi hiển thị lịch sử hóa đơn tại trang cá nhân [profile.php](file:///c:/xampp/htdocs/rapphim/profile.php) hoặc xem danh sách giao dịch của Admin, mã nguồn PHP chỉ cần gọi hàm `json_decode()` để chuyển đổi chuỗi JSON này thành mảng PHP và duyệt in ra danh sách bắp nước cực kỳ nhanh chóng và linh hoạt.

### 6.4. Phân hệ Quản trị viên (Admin Area)
Phân hệ Admin được đặt trong thư mục [admin/](file:///c:/xampp/htdocs/rapphim/admin), đóng vai trò quản lý tài nguyên và theo dõi hoạt động của hệ thống rạp phim.
*   **Trang chủ thống kê (Dashboard - [admin/index.php](file:///c:/xampp/htdocs/rapphim/admin/index.php)):** Thống kê số lượng Phim đang chiếu, Tổng thành viên đăng ký, Tổng số vé đã bán ra và Tổng doanh thu thực tế thu về từ trước tới nay. Đồng thời hiển thị bảng chi tiết các giao dịch mua vé mới nhất xếp theo thứ tự thời gian.
*   **Module quản lý Phim ([admin/movies.php](file:///c:/xampp/htdocs/rapphim/admin/movies.php)):** Cung cấp giao diện CRUD đầy đủ. Admin có thể thêm phim mới bằng cách điền thông tin và tải poster trực tiếp lên máy chủ. Khi cập nhật thông tin phim hoặc xóa phim, hệ thống sẽ tự động cập nhật hoặc dọn dẹp file poster cũ trên đĩa.
*   **Module quản lý Lịch chiếu ([admin/showtimes.php](file:///c:/xampp/htdocs/rapphim/admin/showtimes.php)):** Cung cấp công cụ thiết lập giờ chiếu linh hoạt. Khi một suất chiếu được tạo, nó sẽ ngay lập tức hiển thị động trên thanh đặt vé nhanh của khách hàng.

---

## 7. LUỒNG XỬ LÝ NGHIỆP VỤ & SƠ ĐỒ TUẦN TỰ (SEQUENCE DIAGRAM)

### 7.1. Sơ Sồ Tuần Tự Luồng Đặt Vé Trực Tuyến
Sơ đồ dưới đây thể hiện luồng tương tác giữa Trình duyệt khách hàng, hệ thống xử lý PHP và Cơ sở dữ liệu MySQL khi thực hiện giao dịch đặt vé trực tuyến:

```mermaid
sequenceDiagram
  autonumber
  actor Customer as Khách hàng (Member)
  participant Browser as Trình duyệt (Client)
  participant BookingPage as booking.php
  participant BookingModel as Lớp Booking
  participant DB as Cơ sở dữ liệu MySQL

  Customer->>Browser: Chọn suất chiếu & nhấn Đặt vé
  Browser->>BookingPage: Gửi yêu cầu tải trang (showtime_id)
  BookingPage->>BookingModel: Gọi getBookedSeats(showtime_id)
  BookingModel->>DB: SELECT seats FROM bookings WHERE showtime_id = ?
  DB-->>BookingModel: Trả về danh sách chuỗi ghế đã bán
  BookingModel-->>BookingPage: Trả về mảng ghế đã đặt dạng phẳng
  BookingPage-->>Browser: Render HTML sơ đồ phòng chiếu (khóa ghế đã đặt)
  Customer->>Browser: Click chọn ghế trống & Combo bắp nước
  Browser->>Browser: JavaScript tính tổng tiền động real-time
  Customer->>Browser: Nhấn nút XÁC NHẬN ĐẶT VÉ
  Browser->>BookingPage: Submit dữ liệu (Seats, Concessions JSON, Total Price)
  BookingPage->>BookingModel: Gọi create(user_id, showtime_id, seats, concessions, total_price)
  BookingModel->>DB: INSERT INTO bookings VALUES (...)
  DB-->>BookingModel: Xác nhận ghi thành công (true)
  BookingModel-->>BookingPage: Trả về kết quả thành công
  BookingPage-->>Browser: Chuyển hướng sang trang profile.php (Hiện biên lai)
  Browser-->>Customer: Hiển thị thông báo đặt vé thành công kèm chi tiết vé
```

### 7.2. Sơ đồ tuần tự luồng AJAX Đặt vé nhanh tại trang chủ
Minh họa cách thức hoạt động của thanh chọn đặt vé nhanh AJAX hoạt động không tải lại trang ngoài trang chủ:

```mermaid
sequenceDiagram
  autonumber
  actor User as Khách hàng
  participant Homepage as index.php (Client)
  participant Router as ajax-quick-book.php
  participant Showtime as Lớp Showtime
  participant DB as Cơ sở dữ liệu MySQL

  User->>Homepage: Chọn Rạp (Dropdown 1)
  Homepage->>Router: AJAX Request: action=get_movies&cinema_id=X
  Router->>Showtime: Gọi getMoviesByCinema(cinema_id)
  Showtime->>DB: SELECT DISTINCT movies...
  DB-->>Showtime: Danh sách phim phù hợp
  Showtime-->>Router: Trả về mảng PHP Phim
  Router-->>Homepage: Trả về chuỗi JSON chứa danh sách Phim
  Homepage->>Homepage: JS render danh mục Phim vào Dropdown 2 (Mở khóa)

  User->>Homepage: Chọn Phim (Dropdown 2)
  Homepage->>Router: AJAX Request: action=get_dates&movie_id=Y&cinema_id=X
  Router->>Showtime: Gọi getDatesByMovieAndCinema(movie_id, cinema_id)
  Showtime->>DB: SELECT DISTINCT show_date...
  DB-->>Showtime: Danh sách ngày chiếu
  Showtime-->>Router: Trả về mảng PHP Ngày
  Router-->>Homepage: Trả về chuỗi JSON chứa danh sách Ngày
  Homepage->>Homepage: JS render Ngày vào Dropdown 3 (Mở khóa)

  User->>Homepage: Chọn Ngày (Dropdown 3)
  Homepage->>Router: AJAX Request: action=get_times&date=Z...
  Router->>Showtime: Gọi getTimesByDate(movie_id, cinema_id, date)
  Showtime->>DB: SELECT id, show_time, price...
  DB-->>Showtime: Danh sách giờ chiếu & giá vé
  Showtime-->>Router: Trả về mảng PHP Giờ
  Router-->>Homepage: Trả về chuỗi JSON chứa danh sách Giờ chiếu
  Homepage->>Homepage: JS render Giờ chiếu vào Dropdown 4 (Mở khóa)

  User->>Homepage: Chọn Giờ & nhấn nút "MUA VÉ NHANH"
  Homepage->>Homepage: Chuyển hướng trực tiếp tới booking.php?showtime_id=W
```

---

## 8. GIAO DIỆN HỆ THỐNG & HƯỚNG DẪN SỬ DỤNG

### 8.1. Hướng dẫn cài đặt chi tiết trên môi trường cục bộ
1.  **Chuẩn bị mã nguồn:** Tải toàn bộ thư mục dự án `rapphim` và đặt vào thư mục phân vùng root của web server cục bộ:
    *   Đối với XAMPP: `C:\xampp\htdocs\rapphim\`
    *   Đối với Laragon: `C:\laragon\www\rapphim\`
2.  **Khởi động các dịch vụ cơ bản:** Mở phần mềm điều khiển XAMPP Control Panel, nhấn nút **Start** để khởi chạy dịch vụ web **Apache** (mặc định chạy cổng 80 hoặc 8080) và hệ quản trị cơ sở dữ liệu **MySQL** (mặc định chạy cổng 3306). Đảm bảo cả hai dịch vụ đều chuyển màu xanh hiển thị trạng thái hoạt động bình thường.
3.  **Tiến hành chạy ứng dụng:** Mở một trình duyệt web bất kỳ trên máy tính (Chrome, Edge, Firefox...), truy cập đường dẫn:
    ```
    http://localhost/rapphim/index.php
    ```
4.  **Cơ chế tự động thiết lập CSDL:** Hệ thống sẽ mất khoảng 2-3 giây đầu tiên để lớp [Database](file:///c:/xampp/htdocs/rapphim/config/Database.php) thực hiện kết nối MySQL, kiểm tra và tự động khởi tạo cơ sở dữ liệu `rapphim`, tự động sinh cấu trúc bảng và nạp toàn bộ các bản ghi mẫu phim, lịch chiếu, concessions bắp nước. Không cần bất cứ thao tác import file SQL thủ công nào từ phía người dùng.
5.  **Cấu hình kết nối MySQL tùy chỉnh (Nếu có thay đổi mật khẩu):** Mặc định hệ thống sử dụng kết nối máy chủ MySQL với tên đăng nhập `root` và mật khẩu rỗng `''`. Nếu hệ quản trị MySQL của bạn cài đặt mật khẩu truy cập, vui lòng chỉnh sửa các tham số kết nối tại dòng 13 và 14 trong file [Database.php](file:///c:/xampp/htdocs/rapphim/config/Database.php):
    ```php
    $this->pdo = new PDO("mysql:host=localhost", 'username_cua_ban', 'mat_khau_cua_ban');
    ```

### 8.2. Tài khoản kiểm thử hệ thống
Nhằm phục vụ công tác chấm điểm và trải nghiệm đầy đủ chức năng của đồ án, hệ thống đã nạp sẵn hai tài khoản đại diện cho hai phân hệ cấp quyền:

*   **Tài khoản Quản trị viên (Admin Area):**
    *   Tên đăng nhập: `admin`
    *   Mật khẩu: `admin123`
    *   *Quyền hạn:* Được quyền truy cập trực tiếp vào khu vực trang [admin/index.php](file:///c:/xampp/htdocs/rapphim/admin/index.php) để theo dõi doanh thu và thực hiện các thao tác CRUD quản trị hệ thống.
*   **Tài khoản Thành viên thông thường (Member Area):**
    *   Tên đăng nhập: `member`
    *   Mật khẩu: `member123`
    *   *Quyền hạn:* Thực hiện đầy đủ quy trình mua vé phim, đặt combo bắp nước, xem biên lai và đổi thông tin cá nhân.

### 8.3. Mô tả các màn hình giao diện kèm phân tích thiết kế UI/UX

#### A. Giao diện trang chủ công cộng (Homepage - [index.php](file:///c:/xampp/htdocs/rapphim/index.php))
Trang chủ đóng vai trò là điểm chạm đầu tiên của khách hàng khi tiếp xúc với dịch vụ rạp phim trực tuyến.
*   **Đặc điểm thiết kế:** Giao diện tối sang trọng (Dark theme) giúp poster phim nổi bật tối đa. Slide quảng cáo cỡ lớn ở phần đầu tự động chuyển cảnh mượt mà trình chiếu các bộ phim sắp chiếu, tạo hiệu ứng điện ảnh lôi cuốn.
*   **Thành phần chính:**
    1. **Thanh điều hướng (Navbar):** Chứa logo Cinestar, các liên kết nhanh (Phim, Rạp, Giá Vé, Bắp Nước, Khuyến Mãi), ô tìm kiếm phim thời gian thực, và nút "ĐĂNG NHẬP / ĐĂNG KÝ" hoặc tên người dùng kèm dropdown tùy chọn.
    2. **Thanh đặt vé nhanh (Quick Booking Bar):** Đặt ngay dưới slide quảng cáo lớn. Chứa 4 ô chọn lọc dữ liệu AJAX (1-Chọn Rạp, 2-Chọn Phim, 3-Chọn Ngày, 4-Chọn Suất). Chỉ khi người dùng chọn rạp thì ô chọn phim tương ứng mới mở khóa, đảm bảo luồng nghiệp vụ luôn chuẩn xác.
    3. **Danh mục phim đang chiếu:** Hiển thị dưới dạng lưới card. Khi hover, hình ảnh poster phim phóng to nhẹ kèm hiệu ứng chuyển màu neon, nút đặt vé trượt từ dưới lên kích thích người dùng click chọn.
*   **Hình ảnh minh họa:**
    ![Trang chủ Cinestar Clone](assets/images/sc_home.png)
    *Hình 8.1: Trang chủ với thanh Đặt Vé Nhanh AJAX và các card phim phóng to mượt mà.*

#### B. Giao diện Đăng nhập / Đăng ký ([login.php](file:///c:/xampp/htdocs/rapphim/login.php) & [register.php](file:///c:/xampp/htdocs/rapphim/register.php))
Trang xác thực người dùng được thiết kế tối giản, tập trung vào form điền thông tin để nâng cao tỷ lệ chuyển đổi đăng ký thành viên.
*   **Đặc điểm thiết kế:** Hộp form đăng nhập đặt ở vị trí chính giữa màn hình với nền mờ kính (Glassmorphic CSS) và viền vàng kim tinh tế.
*   **Xử lý bảo mật:**
    *   Sử dụng thuộc tính `required` của HTML5 kết hợp JavaScript kiểm tra định dạng email và độ dài mật khẩu trước khi gửi dữ liệu lên server.
    *   PHP nhận dữ liệu biểu mẫu qua phương thức POST, gọi hàm băm bảo mật chống tấn công đánh cắp mật khẩu.
*   **Hình ảnh minh họa:**
    ![Trang đăng nhập](assets/images/sc_login.png)
    *Hình 8.2: Biểu mẫu đăng nhập phong cách dark mode tối giản.*

#### C. Giao diện Danh mục bắp nước công cộng ([concessions.php](file:///c:/xampp/htdocs/rapphim/concessions.php))
Giới thiệu các gói combo bắp nước đi kèm hình ảnh minh họa sống động và bảng giá ưu đãi tương ứng.
*   **Đặc điểm thiết kế:** Tiêu đề trang nổi bật với màu gradient vàng tím neon. Danh mục combo bắp nước hiển thị dưới dạng card 3 cột đẹp mắt, ghi rõ giá gốc và giá khuyến mãi khi đặt online cùng mô tả thành phần combo (ví dụ: 1 bắp ngọt lớn + 2 nước ngọt vừa).
*   **Hình ảnh minh họa:**
    ![Trang bắp nước](assets/images/sc_concessions.png)
    *Hình 8.3: Menu giới thiệu combo bắp nước.*

#### D. Giao diện Chọn ghế & Mua bắp nước kèm vé ([booking.php](file:///c:/xampp/htdocs/rapphim/booking.php))
Đây là giao diện phức tạp và quan trọng nhất của đồ án, tích hợp sơ đồ rạp tương tác trực quan.
*   **Đặc điểm thiết kế:**
    1. **Sơ đồ rạp ngồi:** Trình bày rõ ràng các khối ghế: Ghế thường màu xám nhạt, Ghế VIP màu tím, Ghế đang chọn màu vàng kim, và Ghế đã có người đặt trước màu đỏ bị khóa kèm ký hiệu chữ X. Góc trên hiển thị màn hình phòng chiếu tượng trưng (Screen) giúp người dùng dễ định hướng vị trí ngồi.
    2. **Khu vực mua bắp nước phụ trợ:** Đặt trực tiếp dưới sơ đồ ghế. Người dùng có thể click nút cộng (+) hoặc trừ (-) để tăng giảm số lượng các combo bắp nước muốn mua kèm mà không phải chuyển trang.
    3. **Bảng hóa đơn đặt vé bên phải:** Hiển thị tóm tắt thông tin suất chiếu đã chọn (Tên phim, rạp chiếu, ngày giờ, số lượng ghế, số ghế cụ thể và danh sách bắp nước đã chọn mua). Dưới cùng là hiển thị Tổng tiền thanh toán cập nhật liên tục.
*   **Hình ảnh minh họa:**
    ![Trang chọn ghế](assets/images/sc_booking.png)
    *Hình 8.4: Sơ đồ phòng chiếu hiển thị ghế Thường, ghế VIP và khu vực chọn bắp nước đi kèm.*

#### E. Bảng điều khiển quản trị (Admin Dashboard - [admin/index.php](file:///c:/xampp/htdocs/rapphim/admin/index.php))
Giao diện trung tâm giám sát hoạt động kinh doanh dành riêng cho cấp quản trị viên.
*   **Đặc điểm thiết kế:** Thiết kế với tông màu sáng/tối tối giản, chuyên nghiệp. 
*   **Thành phần chính:**
    1. **Thẻ thống kê nhanh:** Gồm 4 khối thẻ lớn hiển thị: Tổng số phim hiện có, Tổng số thành viên đã đăng ký, Tổng số vé bán ra từ trước tới nay, và Tổng doanh thu thực tế thu được (định dạng tiền tệ VNĐ).
    2. **Bảng giao dịch lịch sử:** Hiển thị chi tiết danh sách giao dịch đặt vé mới nhất, liệt kê rõ: Tên khách hàng, Tên phim, Rạp chiếu, Suất chiếu, Số ghế đã đặt, Danh mục bắp nước đi kèm (giải mã từ JSON), Tổng số tiền hóa đơn và Ngày giờ giao dịch cụ thể.
*   **Hình ảnh minh họa:**
    ![Admin Dashboard](assets/images/sc_admin.png)
    *Hình 8.5: Trang thống kê doanh thu và quản trị tổng quan.*

---

## 9. KIỂM THỬ HỆ THỐNG (TESTING & VALIDATION)

### 9.1. Kịch bản kiểm thử (Test Cases) các chức năng chính

#### Kịch bản 1: Kiểm thử chức năng Đăng ký tài khoản mới ([register.php](file:///c:/xampp/htdocs/rapphim/register.php))
*   **Mục tiêu:** Kiểm tra tính chính xác và ràng buộc dữ liệu đầu vào của biểu mẫu đăng ký.
*   **Các bước thực hiện:**
    1. Truy cập trang Đăng ký tài khoản thành viên.
    2. Nhập các trường hợp dữ liệu thử nghiệm (xem bảng dưới).
    3. Bấm nút "ĐĂNG KÝ" và theo dõi phản hồi của hệ thống.

| Mã Test Case | Dữ liệu kiểm thử nhập vào | Kết quả mong đợi | Kết quả thực tế | Trạng thái |
| :--- | :--- | :--- | :--- | :--- |
| `TC-REG-01` | Bỏ trống tất cả các trường dữ liệu | Báo lỗi bắt buộc nhập thông tin trên biểu mẫu | Hiển thị cảnh báo bắt buộc nhập của trình duyệt | Đạt |
| `TC-REG-02` | Nhập email sai định dạng (ví dụ: `abcde`) | Báo lỗi định dạng email không hợp lệ | Trình duyệt báo lỗi yêu cầu thêm ký tự `@` | Đạt |
| `TC-REG-03` | Nhập trùng khớp tên tài khoản đã tồn tại | Báo lỗi tên đăng nhập đã được sử dụng | Hệ thống hiển thị thông báo lỗi trùng tài khoản | Đạt |
| `TC-REG-04` | Nhập đầy đủ thông tin hợp lệ và chính xác | Đăng ký thành công, tự động chuyển hướng đăng nhập | Chuyển hướng sang trang đăng nhập, tài khoản được lưu | Đạt |

#### Kịch bản 2: Kiểm thử chức năng Đặt vé và Chọn ghế trực quan ([booking.php](file:///c:/xampp/htdocs/rapphim/booking.php))
*   **Mục tiêu:** Đảm bảo luồng tính tiền động và khóa ghế đã bán hoạt động chính xác tuyệt đối.
*   **Các bước thực hiện:**
    1. Đăng nhập tài khoản thành viên `member`.
    2. Chọn suất chiếu của phim và vào sơ đồ đặt ghế.
    3. Tiến hành click chọn các loại ghế khác nhau và bắp nước.
    4. Bấm xác nhận mua vé.

| Mã Test Case | Thao tác thực tế | Kết quả mong đợi | Kết quả thực tế | Trạng thái |
| :--- | :--- | :--- | :--- | :--- |
| `TC-BOOK-01` | Click chọn ghế đã có người mua (màu đỏ) | Không thể click, không đổi trạng thái ghế | Ghế bị khóa hoàn toàn, không thể tương tác | Đạt |
| `TC-BOOK-02` | Click chọn ghế thường `A3` (giá gốc `80.000 đ`) | Hóa đơn hiển thị tổng tiền là `80.000 đ` | Tổng tiền cập nhật chính xác là `80.000 đ` | Đạt |
| `TC-BOOK-03` | Click chọn thêm ghế VIP `E5` (giá VIP gốc + `20.000 đ`) | Tổng tiền tăng lên thành `180.000 đ` | Tổng tiền hiển thị chính xác `180.000 đ` | Đạt |
| `TC-BOOK-04` | Chọn mua thêm 1 combo bắp nước Solo (`85.000 đ`) | Tổng tiền tăng lên thành `265.000 đ` | Tổng tiền hiển thị chính xác `265.000 đ` | Đạt |
| `TC-BOOK-05` | Bấm xác nhận đặt vé | Lưu giao dịch, ghế `A3,E5` bị khóa vĩnh viễn ở suất chiếu đó | Vé được ghi nhận thành công, ghế đã được khóa | Đạt |

### 9.2. Đánh giá kết quả kiểm thử thực tế
Toàn bộ các chức năng cốt lõi của website đặt vé xem phim Cinestar Clone đã được kiểm thử qua nhiều kịch bản khác nhau từ thông thường đến các trường hợp dữ liệu biên lỗi. Kết quả cho thấy hệ thống hoạt động ổn định, luồng dữ liệu nghiệp vụ chạy nhất quán, các ràng buộc toàn vẹn cơ sở dữ liệu MySQL hoạt động tốt giúp loại bỏ hoàn toàn các lỗi xung đột dữ liệu.

---

## 10. KẾT LUẬN & HƯỚNG PHÁT TRIỂN

### 10.1. Các kết quả đã đạt được
Đồ án môn học đã hoàn thành xuất sắc các mục tiêu đề ra ban đầu, xây dựng được một hệ thống website đặt vé xem phim trực tuyến hoàn chỉnh với:
*   **Giao diện chất lượng cao:** Thiết kế Dark Mode chuẩn 100% theo nhận diện thương hiệu của Cinestar Việt Nam, hiệu ứng trượt, hover mượt mà và tương thích tốt trên các loại thiết bị di động.
*   **Mã nguồn OOP sạch sẽ:** Phân tách rõ ràng vai trò của 7 lớp thực thể Model kết nối an toàn với PDO, giúp mã nguồn dễ đọc và nâng cấp.
*   **Nghiệp vụ đặt vé tối ưu:** Hệ thống đặt vé nhanh AJAX hoạt động mượt mà không tải lại trang; sơ đồ chọn ghế trực quan cho phép phân tách ghế Thường/VIP và lưu trữ thông tin bắp nước đi kèm thông qua chuỗi cấu trúc JSON tối ưu hóa CSDL.
*   **Bộ công cụ Admin mạnh mẽ:** Cho phép quản lý toàn diện các thông tin nghiệp vụ và theo dõi báo cáo doanh thu trực quan.

### 10.2. Hạn chế hiện tại của đồ án
Mặc dù đã hoàn thành đầy đủ các tính năng cơ bản của một hệ thống đặt vé phim thương mại, đồ án vẫn còn một số điểm hạn chế do giới hạn về mặt thời gian và tài nguyên thử nghiệm:
*   Chưa tích hợp cổng thanh toán trực tuyến thực tế (Momo, VNPay, ZaloPay...) mà đang sử dụng hình thức thanh toán giả lập ghi nhận trực tiếp hóa đơn.
*   Chưa có cơ chế gửi vé điện tử (mã QR, hóa đơn chi tiết) về địa chỉ thư điện tử Email hoặc số điện thoại của khách hàng sau khi thanh toán thành công.

### 10.3. Đề xuất hướng phát triển tiếp theo
*   **Tích hợp cổng thanh toán Sandbox:** Kết nối ứng dụng với môi trường thử nghiệm (Sandbox) của cổng thanh toán điện tử VNPay hoặc MoMo để hoàn thiện 100% luồng thanh toán thực tế của khách hàng.
*   **Tích hợp PHPMailer gửi Email tự động:** Xây dựng tính năng tự động gửi thư điện tử xác nhận đặt vé kèm mã QR vé điện tử để khách hàng có thể quét mã check-in trực tiếp khi đến rạp chiếu phim.
*   **Xây dựng RESTful API:** Phát triển hệ thống API endpoints bảo mật bằng JSON Web Token (JWT) để hỗ trợ kết nối và đồng bộ dữ liệu cho các ứng dụng di động chạy hệ điều hành iOS và Android trong tương lai.
*   **Vẽ biểu đồ phân tích trực quan:** Tích hợp thư viện đồ thị Chart.js vào trang quản trị để hiển thị xu hướng doanh thu theo ngày, tuần, tháng và trực quan hóa tỷ lệ doanh thu bắp nước / doanh thu bán vé phim của rạp.
