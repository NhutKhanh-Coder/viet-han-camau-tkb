<?php
require_once __DIR__ . '/views/header.php';
?>

<div class="container py-5 min-vh-100">
    <!-- Page Header -->
    <div class="text-center mb-5">
        <h1 class="display-4 fw-bold text-white text-uppercase">
            <span class="text-warning"><i class="fa-solid fa-tags me-2"></i>Khuyến Mãi</span> Cực Hot
        </h1>
        <p class="text-white-50 fs-5">Săn ngay ưu đãi khủng từ Cinestar - Trải nghiệm điện ảnh đỉnh cao, giá vé siêu tiết kiệm</p>
        <div class="mx-auto" style="width: 80px; height: 4px; background: linear-gradient(90deg, var(--accent-yellow), var(--accent-purple)); border-radius: 2px;"></div>
    </div>

    <!-- Promotions Grid -->
    <div class="row">
        <!-- Promotion 1: C'Student -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card bg-secondary-cinestar border-0 h-100 shadow-lg promo-card transition-all">
                <div class="position-relative overflow-hidden card-img-container" style="padding-top: 56.25%;">
                    <img src="assets/images/promo_student.png" class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover transition-zoom" alt="C'Student">
                    <span class="position-absolute top-0 end-0 bg-warning text-dark fw-bold px-3 py-1 m-3 rounded-pill text-uppercase shadow-sm" style="font-size: 12px; z-index: 2;">
                        Đồng Giá 45K
                    </span>
                </div>
                <div class="card-body d-flex flex-column p-4">
                    <h4 class="card-title text-white fw-bold mb-3">C'STUDENT - Vé Học Sinh Sinh Viên</h4>
                    <p class="card-text text-white-50 flex-grow-1" style="font-size: 14px; line-height: 1.6;">
                        Chương trình đồng giá vé 2D cực ưu đãi dành riêng cho học sinh, sinh viên và trẻ em trên toàn hệ thống rạp Cinestar.
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary-light">
                        <button class="btn btn-outline-light btn-sm text-uppercase fw-semibold" data-bs-toggle="modal" data-bs-target="#promoStudentModal">
                            <i class="fa-solid fa-circle-info me-1"></i> Chi tiết
                        </button>
                        <a href="index.php#dat-ve-nhanh" class="btn btn-yellow btn-sm text-uppercase fw-bold">
                            <i class="fa-solid fa-ticket me-1"></i> Đặt vé ngay
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Promotion 2: Happy Day -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card bg-secondary-cinestar border-0 h-100 shadow-lg promo-card transition-all">
                <div class="position-relative overflow-hidden card-img-container" style="padding-top: 56.25%;">
                    <img src="assets/images/promo_happyday.png" class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover transition-zoom" alt="Happy Day">
                    <span class="position-absolute top-0 end-0 bg-danger text-white fw-bold px-3 py-1 m-3 rounded-pill text-uppercase shadow-sm" style="font-size: 12px; z-index: 2;">
                        Thứ 3 Hàng Tuần
                    </span>
                </div>
                <div class="card-body d-flex flex-column p-4">
                    <h4 class="card-title text-white fw-bold mb-3">HAPPY DAY - Thứ Ba Vui Vẻ</h4>
                    <p class="card-text text-white-50 flex-grow-1" style="font-size: 14px; line-height: 1.6;">
                        Đồng giá vé 50,000 VNĐ cho mọi đối tượng khách hàng vào ngày Thứ Ba hàng tuần. Xem thả ga không lo về giá!
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary-light">
                        <button class="btn btn-outline-light btn-sm text-uppercase fw-semibold" data-bs-toggle="modal" data-bs-target="#promoHappyDayModal">
                            <i class="fa-solid fa-circle-info me-1"></i> Chi tiết
                        </button>
                        <a href="index.php#dat-ve-nhanh" class="btn btn-yellow btn-sm text-uppercase fw-bold">
                            <i class="fa-solid fa-ticket me-1"></i> Đặt vé ngay
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Promotion 3: C'Member -->
        <div class="col-lg-4 col-md-6 mb-4">
            <div class="card bg-secondary-cinestar border-0 h-100 shadow-lg promo-card transition-all">
                <div class="position-relative overflow-hidden card-img-container" style="padding-top: 56.25%;">
                    <img src="assets/images/promo_member.png" class="position-absolute top-0 start-0 w-100 h-100 object-fit-cover transition-zoom" alt="C'Member">
                    <span class="position-absolute top-0 end-0 bg-purple text-white fw-bold px-3 py-1 m-3 rounded-pill text-uppercase shadow-sm" style="font-size: 12px; z-index: 2; background-color: var(--accent-purple) !important;">
                        Thành Viên VIP
                    </span>
                </div>
                <div class="card-body d-flex flex-column p-4">
                    <h4 class="card-title text-white fw-bold mb-3">C'MEMBER - Tích Lũy Nhận Quà</h4>
                    <p class="card-text text-white-50 flex-grow-1" style="font-size: 14px; line-height: 1.6;">
                        Trở thành thành viên thân thiết của Cinestar để được tích điểm đổi quà và hưởng các đặc quyền VIP độc quyền.
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top border-secondary-light">
                        <button class="btn btn-outline-light btn-sm text-uppercase fw-semibold" data-bs-toggle="modal" data-bs-target="#promoMemberModal">
                            <i class="fa-solid fa-circle-info me-1"></i> Chi tiết
                        </button>
                        <a href="register.php" class="btn btn-purple btn-sm text-uppercase fw-bold">
                            <i class="fa-solid fa-user-plus me-1"></i> Đăng ký ngay
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal 1: C'Student Detail -->
<div class="modal fade" id="promoStudentModal" tabindex="-1" aria-labelledby="promoStudentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-secondary text-white border border-secondary-light">
            <div class="modal-header border-bottom border-secondary-light p-4">
                <h4 class="modal-title fw-bold text-warning" id="promoStudentModalLabel"><i class="fa-solid fa-graduation-cap me-2"></i>C'STUDENT - Đồng Giá 45K Cho HSSV</h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="text-center mb-4">
                    <img src="assets/images/promo_student.png" class="img-fluid rounded border border-secondary-light shadow-lg" alt="C'Student Detail" style="max-height: 300px;">
                </div>
                <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-circle-check text-warning me-2"></i>Thể lệ chương trình</h5>
                <ul class="text-white-50 ps-4 mb-4" style="line-height: 1.8;">
                    <li>Áp dụng mức giá <strong>45,000 VNĐ / vé 2D</strong> cho tất cả các suất chiếu từ Thứ Hai đến Thứ Sáu.</li>
                    <li>Đối tượng áp dụng: Học sinh, sinh viên (từ 22 tuổi trở xuống) và trẻ em dưới 1m3.</li>
                    <li>Mỗi thẻ HSSV hoặc CCCD được mua tối đa 02 vé/ngày với giá ưu đãi.</li>
                    <li>Khi mua vé online hoặc soát vé tại phòng chiếu, vui lòng xuất trình thẻ HSSV/CCCD hợp lệ tương ứng.</li>
                </ul>

                <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-circle-exclamation text-warning me-2"></i>Lưu ý quan trọng</h5>
                <ul class="text-white-50 ps-4" style="line-height: 1.8;">
                    <li>Không áp dụng đồng thời với các chương trình khuyến mãi khác.</li>
                    <li>Không áp dụng vào các ngày Lễ, Tết theo quy định của nhà nước.</li>
                    <li>Giá vé chưa bao gồm phụ thu phòng chiếu VIP, ghế đôi hoặc định dạng 3D (nếu có).</li>
                </ul>
            </div>
            <div class="modal-footer border-top border-secondary-light p-3">
                <button type="button" class="btn btn-outline-light text-uppercase fw-bold" data-bs-dismiss="modal">Đóng</button>
                <a href="index.php#dat-ve-nhanh" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-ticket me-1"></i>Đặt vé ngay</a>
            </div>
        </div>
    </div>
</div>

<!-- Modal 2: Happy Day Detail -->
<div class="modal fade" id="promoHappyDayModal" tabindex="-1" aria-labelledby="promoHappyDayModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-secondary text-white border border-secondary-light">
            <div class="modal-header border-bottom border-secondary-light p-4">
                <h4 class="modal-title fw-bold text-warning" id="promoHappyDayModalLabel"><i class="fa-solid fa-face-smile me-2"></i>HAPPY DAY - Thứ Ba Vui Vẻ</h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="text-center mb-4">
                    <img src="assets/images/promo_happyday.png" class="img-fluid rounded border border-secondary-light shadow-lg" alt="Happy Day Detail" style="max-height: 300px;">
                </div>
                <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-circle-check text-warning me-2"></i>Thể lệ chương trình</h5>
                <ul class="text-white-50 ps-4 mb-4" style="line-height: 1.8;">
                    <li>Đồng giá vé 2D chỉ <strong>50,000 VNĐ</strong> cho tất cả khách hàng đến xem phim vào Thứ Ba hàng tuần.</li>
                    <li>Áp dụng cho mọi suất chiếu trong ngày Thứ Ba (trừ các suất chiếu sớm đặc biệt trước ngày khởi chiếu chính thức).</li>
                    <li>Không giới hạn số lượng vé mua cho mỗi khách hàng trong ngày.</li>
                </ul>

                <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-circle-exclamation text-warning me-2"></i>Lưu ý quan trọng</h5>
                <ul class="text-white-50 ps-4" style="line-height: 1.8;">
                    <li>Không áp dụng vào các ngày Lễ, Tết trùng vào ngày Thứ Ba.</li>
                    <li>Không áp dụng chung với các chương trình giảm giá, khuyến mãi khác.</li>
                    <li>Có phụ thu đối với ghế đôi (Sweetbox) hoặc phòng chiếu 3D/VIP.</li>
                </ul>
            </div>
            <div class="modal-footer border-top border-secondary-light p-3">
                <button type="button" class="btn btn-outline-light text-uppercase fw-bold" data-bs-dismiss="modal">Đóng</button>
                <a href="index.php#dat-ve-nhanh" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-ticket me-1"></i>Đặt vé ngay</a>
            </div>
        </div>
    </div>
</div>

<!-- Modal 3: C'Member Detail -->
<div class="modal fade" id="promoMemberModal" tabindex="-1" aria-labelledby="promoMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content bg-secondary text-white border border-secondary-light">
            <div class="modal-header border-bottom border-secondary-light p-4">
                <h4 class="modal-title fw-bold text-warning" id="promoMemberModalLabel"><i class="fa-solid fa-crown me-2"></i>C'MEMBER - Đặc Quyền Thành Viên VIP</h4>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body p-4">
                <div class="text-center mb-4">
                    <img src="assets/images/promo_member.png" class="img-fluid rounded border border-secondary-light shadow-lg" alt="C'Member Detail" style="max-height: 300px;">
                </div>
                <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-circle-check text-warning me-2"></i>Quyền lợi thành viên</h5>
                <ul class="text-white-50 ps-4 mb-4" style="line-height: 1.8;">
                    <li>Tích lũy điểm thưởng tương đương <strong>5% đến 10% giá trị giao dịch</strong> khi mua vé và bắp nước tại rạp hoặc online.</li>
                    <li>Nhận quà tặng sinh nhật đặc biệt: 01 Combo Bắp Nước miễn phí hoặc 01 vé xem phim 2D miễn phí.</li>
                    <li>Đổi điểm lấy quà hấp dẫn: vé xem phim, bắp nước, gối ôm, bình giữ nhiệt Cinestar độc quyền.</li>
                    <li>Ưu tiên mua vé sớm cho các dự án bom tấn phòng vé.</li>
                </ul>

                <h5 class="fw-bold text-white mb-3"><i class="fa-solid fa-circle-exclamation text-warning me-2"></i>Cách thức đăng ký</h5>
                <ul class="text-white-50 ps-4" style="line-height: 1.8;">
                    <li>Đăng ký tài khoản miễn phí trực tiếp trên website hoặc ứng dụng Cinestar.</li>
                    <li>Hoặc liên hệ quầy Chăm sóc Khách hàng tại rạp gần nhất để được nhân viên hỗ trợ mở thẻ vật lý.</li>
                </ul>
            </div>
            <div class="modal-footer border-top border-secondary-light p-3">
                <button type="button" class="btn btn-outline-light text-uppercase fw-bold" data-bs-dismiss="modal">Đóng</button>
                <a href="register.php" class="btn btn-purple text-uppercase fw-bold"><i class="fa-solid fa-user-plus me-1"></i>Đăng ký ngay</a>
            </div>
        </div>
    </div>
</div>

<style>
/* Custom styled cards for promotions */
.bg-secondary-cinestar {
    background-color: var(--bg-secondary);
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
    border-radius: 12px;
}
.promo-card {
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
.promo-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 10px 30px rgba(124, 58, 237, 0.25) !important;
    border: 1px solid rgba(124, 58, 237, 0.3) !important;
}
.transition-zoom {
    transition: transform 0.6s ease;
}
.promo-card:hover .transition-zoom {
    transform: scale(1.08);
}
.border-secondary-light {
    border-color: rgba(255, 255, 255, 0.08) !important;
}
</style>

<?php
require_once __DIR__ . '/views/footer.php';
?>
