<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/Movie.php';
require_once __DIR__ . '/models/Showtime.php';

$database = new Database();
$db = $database->getConnection();
$movieModel = new Movie($db);
$showtimeModel = new Showtime($db);

$movieId = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($movieId <= 0) {
    header('Location: index.php');
    exit;
}

$movie = $movieModel->getById($movieId);
if (!$movie) {
    header('Location: index.php');
    exit;
}

$ratingClass = strtolower(str_replace(' ', '', $movie['rating']));
if (!in_array($ratingClass, ['p', 't16', 't18', 'k'])) $ratingClass = 'other';

// Get showtimes grouped by cinema and date
$showtimesGrouped = $showtimeModel->getShowtimesForMovie($movieId);

require_once __DIR__ . '/views/header.php';
?>

<div class="movie-detail-banner" style="background-image: url('<?php echo getMoviePosterUrl($movie['image'], $movie['title']); ?>');">
    <div class="container movie-detail-content text-white">
        <div class="row align-items-center">
            <div class="col-md-3 mb-4 mb-md-0 text-center">
                <div class="movie-detail-poster mx-auto" style="max-width: 260px;">
                    <img src="<?php echo getMoviePosterUrl($movie['image'], $movie['title']); ?>" alt="<?php echo htmlspecialchars($movie['title']); ?>" class="img-fluid w-100">
                </div>
            </div>
            
            <div class="col-md-9 movie-detail-info">
                <div class="d-flex align-items-center flex-wrap gap-2 mb-3">
                    <span class="rating-badge position-static <?php echo $ratingClass; ?>">2D | <?php echo htmlspecialchars($movie['rating']); ?></span>
                    <span class="badge bg-secondary py-2 px-3 fw-semibold">
                        <?php echo $movie['status'] === 'showing' ? 'Đang chiếu' : 'Sắp chiếu'; ?>
                    </span>
                </div>
                
                <h1><?php echo htmlspecialchars($movie['title']); ?></h1>
                
                <div class="detail-meta-item">
                    <span class="detail-meta-label"><i class="fa-regular fa-clock me-1"></i> Thời lượng:</span>
                    <span><?php echo $movie['duration']; ?> phút</span>
                </div>
                
                <div class="detail-meta-item">
                    <span class="detail-meta-label"><i class="fa-regular fa-calendar-check me-1"></i> Khởi chiếu:</span>
                    <span><?php echo date('d/m/Y', strtotime($movie['release_date'])); ?></span>
                </div>
                
                <div class="detail-meta-item">
                    <span class="detail-meta-label"><i class="fa-solid fa-earth-asia me-1"></i> Quốc gia:</span>
                    <span>Việt Nam / Quốc tế</span>
                </div>
                
                <p class="text-white-50 mt-4" style="line-height: 1.7; font-size: 15px; max-width: 800px;">
                    <?php echo nl2br(htmlspecialchars($movie['description'])); ?>
                </p>
                
                <?php if (!empty($movie['trailer_url'])): ?>
                    <a href="#trailer" class="btn btn-outline-warning mt-3 text-uppercase fw-bold"><i class="fa-solid fa-circle-play me-2"></i>Xem Trailer</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Quick Booking Bar -->
<div class="container" id="dat-ve-nhanh">
    <div class="quick-booking-bar">
        <div class="row align-items-center g-3">
            <div class="col-xl-3 col-lg-12">
                <div class="quick-booking-title">
                    <i class="fa-solid fa-bolt text-warning fs-3 me-2"></i>
                    <span>Đặt vé<br class="d-none d-xl-block"> nhanh</span>
                </div>
            </div>
            <div class="col-xl-2 col-md-3">
                <select id="qb-cinema">
                    <option value="">1. Chọn Rạp</option>
                </select>
            </div>
            <div class="col-xl-2 col-md-3">
                <select id="qb-movie" disabled>
                    <option value="<?php echo $movie['id']; ?>"><?php echo htmlspecialchars($movie['title']); ?></option>
                </select>
            </div>
            <div class="col-xl-2 col-md-3">
                <select id="qb-date">
                    <option value="">3. Chọn Ngày</option>
                </select>
            </div>
            <div class="col-xl-2 col-md-3">
                <select id="qb-time" disabled>
                    <option value="">4. Chọn Suất</option>
                </select>
            </div>
            <div class="col-xl-1 col-lg-12 text-center text-xl-end">
                <button id="qb-submit" class="btn btn-purple w-100 py-2 text-uppercase opacity-50 fw-bold" disabled>Đặt ngay</button>
            </div>
        </div>
    </div>
</div>

<div class="container my-5">
    <div class="row">
        <!-- Showtime lists -->
        <div class="col-lg-8 mb-5">
            <h3 class="fw-bold mb-4 text-uppercase"><i class="fa-solid fa-ticket text-warning me-2"></i> Lịch Chiếu</h3>
            
            <?php if ($movie['status'] === 'coming'): ?>
                <div class="alert alert-info bg-dark text-info border-info py-4">
                    <i class="fa-solid fa-circle-info me-2 fs-5"></i> Phim sắp chiếu tại Cinestar. Lịch chiếu chính thức sẽ có trước ngày khởi chiếu 1-2 ngày. Quý khách vui lòng theo dõi website để đặt vé sớm nhất!
                </div>
            <?php elseif (empty($showtimesGrouped)): ?>
                <div class="alert alert-warning bg-dark text-warning border-warning py-4">
                    <i class="fa-solid fa-triangle-exclamation me-2 fs-5"></i> Rất tiếc, phim hiện chưa có suất chiếu nào được lên lịch tại các rạp. Vui lòng quay lại sau!
                </div>
            <?php else: ?>
                <div class="showtime-section">
                    <?php foreach ($showtimesGrouped as $cinemaId => $cinemaData): ?>
                        <div class="cinema-group">
                            <div class="cinema-name">
                                <i class="fa-solid fa-film me-2"></i><?php echo htmlspecialchars($cinemaData['name']); ?>
                            </div>
                            
                            <?php foreach ($cinemaData['dates'] as $date => $slots): ?>
                                <div class="date-row">
                                    <div class="date-label">
                                        <?php 
                                            // Format day of week in Vietnamese
                                            $dayOfWeek = date('N', strtotime($date));
                                            $days = [1=>'Thứ Hai', 2=>'Thứ Ba', 3=>'Thứ Tư', 4=>'Thứ Năm', 5=>'Thứ Sáu', 6=>'Thứ Bảy', 7=>'Chủ Nhật'];
                                            $dayText = $days[$dayOfWeek];
                                            echo $dayText . ', ' . date('d/m/Y', strtotime($date));
                                        ?>
                                    </div>
                                    <div class="d-flex flex-wrap gap-2">
                                        <?php foreach ($slots as $slot): ?>
                                            <a href="booking.php?showtime_id=<?php echo $slot['id']; ?>" class="time-slot text-decoration-none">
                                                <?php echo $slot['time']; ?>
                                                <small class="d-block text-white-50" style="font-size: 9px; margin-top: 2px;">
                                                    <?php echo number_format($slot['price'], 0, ',', '.'); ?> đ
                                                </small>
                                            </a>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <!-- Sidebar / Video Trailer -->
        <div class="col-lg-4">
            <?php if (!empty($movie['trailer_url'])): ?>
                <h3 class="fw-bold mb-4 text-uppercase" id="trailer"><i class="fa-solid fa-video text-warning me-2"></i> Trailer</h3>
                <div class="ratio ratio-16x9 rounded-3 overflow-hidden border border-secondary shadow">
                    <!-- Standard youtube embed with required allow permissions -->
                    <iframe 
                        src="<?php echo htmlspecialchars($movie['trailer_url']); ?>"
                        title="<?php echo htmlspecialchars($movie['title']); ?> - Trailer"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                        allowfullscreen
                        frameborder="0"
                        loading="lazy"
                    ></iframe>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/views/footer.php';
?>
