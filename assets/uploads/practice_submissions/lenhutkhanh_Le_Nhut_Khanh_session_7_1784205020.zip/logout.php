<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
session_destroy();

session_start();
$_SESSION['success'] = "Đăng xuất tài khoản thành công!";
header('Location: index.php');
exit;
?>
