<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id']) || !isset($_SESSION['pending_booking'])) {
    header('Location: index.php');
    exit;
}

$config = require __DIR__ . '/config/vnpay.php';
$pending = $_SESSION['pending_booking'];

// Construct VNPAY payment parameters
$vnp_Url        = $config['vnp_Url'];
$vnp_Returnurl  = $config['vnp_Returnurl'];
$vnp_TmnCode    = $config['vnp_TmnCode'];
$vnp_HashSecret = $config['vnp_HashSecret'];

// Đặt múi giờ Việt Nam để tránh lỗi code=15
date_default_timezone_set('Asia/Ho_Chi_Minh');

$vnp_TxnRef    = time() . '_' . $pending['user_id'] . '_' . $pending['showtime_id'];
$vnp_OrderInfo = 'Thanh toan ve xem phim Cinestar - Ghe ' . $pending['seats'];
$vnp_OrderType = 'billpayment';
$vnp_Amount    = intval($pending['total_price']) * 100; // Đơn vị: VNĐ × 100
$vnp_Locale    = 'vn';
$vnp_IpAddr    = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
$vnp_CreateDate = date('YmdHis');
$vnp_ExpireDate = date('YmdHis', strtotime('+15 minutes'));

$inputData = [
    'vnp_Version'    => '2.1.0',
    'vnp_TmnCode'    => $vnp_TmnCode,
    'vnp_Amount'     => $vnp_Amount,
    'vnp_Command'    => 'pay',
    'vnp_CreateDate' => $vnp_CreateDate,
    'vnp_CurrCode'   => 'VND',
    'vnp_ExpireDate' => $vnp_ExpireDate,
    'vnp_IpAddr'     => $vnp_IpAddr,
    'vnp_Locale'     => $vnp_Locale,
    'vnp_OrderInfo'  => $vnp_OrderInfo,
    'vnp_OrderType'  => $vnp_OrderType,
    'vnp_ReturnUrl'  => $vnp_Returnurl,
    'vnp_TxnRef'     => $vnp_TxnRef,
];

// Sắp xếp tham số theo thứ tự alphabet (yêu cầu của VNPAY)
ksort($inputData);

$hashdata = '';
$query    = '';
foreach ($inputData as $key => $value) {
    $hashdata .= ($hashdata ? '&' : '') . urlencode($key) . '=' . urlencode($value);
    $query    .= urlencode($key) . '=' . urlencode($value) . '&';
}

$vnp_Url = $vnp_Url . '?' . $query;
if (isset($vnp_HashSecret)) {
    $vnpSecureHash = hash_hmac('sha512', $hashdata, $vnp_HashSecret);
    $vnp_Url .= 'vnp_SecureHash=' . $vnpSecureHash;
}

// Redirect sang cổng thanh toán VNPAY Sandbox
header('Location: ' . $vnp_Url);
exit;

