// ==========================================
// HERO CAROUSEL - Pure Vanilla JS (no jQuery)
// ==========================================
(function () {
    function initCarousel() {
        var slides = document.querySelectorAll('.hero-slide');
        if (!slides || slides.length < 2) return;

        var currentSlide = 0;
        var timer = null;
        var carouselIsMuted = true; // start muted per browser policy

        // Update dots indicator
        var dots = document.querySelectorAll('.hero-dot');
        function updateDots(idx) {
            dots.forEach(function (d, i) {
                d.classList.toggle('active', i === idx);
            });
        }

        // Sound Elements
        var soundBtn = document.getElementById('video-sound-btn');
        var soundIcon = document.getElementById('video-sound-icon');

        function updateSoundButtonState() {
            if (!soundBtn || !soundIcon) return;

            var activeSlide = slides[currentSlide];
            var video = activeSlide.querySelector('video');

            if (video) {
                soundBtn.style.display = 'flex';
                if (carouselIsMuted) {
                    soundIcon.className = 'fa-solid fa-volume-xmark';
                    soundBtn.style.borderColor = 'rgba(255, 255, 255, 0.25)';
                } else {
                    soundIcon.className = 'fa-solid fa-volume-high';
                    soundBtn.style.borderColor = 'var(--accent-yellow)';
                }
            } else {
                soundBtn.style.display = 'none';
            }
        }

        // Play video in active slide, pause others
        function updateVideos(activeIdx) {
            slides.forEach(function (slide, i) {
                slide.querySelectorAll('video').forEach(function (v) {
                    if (i === activeIdx) {
                        try {
                            v.muted = carouselIsMuted; // apply global mute state
                            v.currentTime = 0; // play from the beginning
                            var p = v.play();
                            if (p && typeof p.catch === 'function') {
                                p.catch(function (err) {
                                    console.log("Autoplay blocked or video failed: ", err);
                                });
                            }
                        } catch (e) {
                            console.warn("Synchronous video play error: ", e);
                        }
                    } else {
                        try {
                            v.pause();
                            v.currentTime = 0; // reset
                        } catch (e) {}
                    }
                });
            });
        }

        function scheduleNextSlide() {
            if (timer) {
                clearTimeout(timer);
                timer = null;
            }

            var activeSlide = slides[currentSlide];
            var video = activeSlide.querySelector('video');

            if (video) {
                var fallbackDuration = 30000; 

                function setVideoFallback() {
                    if (timer) clearTimeout(timer);
                    var durationMs = (video.duration * 1000) + 2000;
                    if (isNaN(durationMs) || durationMs <= 0) {
                        durationMs = 30000;
                    }
                    timer = setTimeout(function () {
                        console.log("Video fallback timer fired. Transitioning to next slide.");
                        goToSlide(currentSlide + 1);
                    }, durationMs);
                }

                if (!isNaN(video.duration) && video.duration > 0) {
                    setVideoFallback();
                } else {
                    timer = setTimeout(function () {
                        console.log("Video initial fallback timer fired. Transitioning to next slide.");
                        goToSlide(currentSlide + 1);
                    }, fallbackDuration);

                    video.addEventListener('loadedmetadata', function onMetadata() {
                        video.removeEventListener('loadedmetadata', onMetadata);
                        if (slides[currentSlide].contains(video)) {
                            setVideoFallback();
                        }
                    });
                }
            } else {
                timer = setTimeout(function () {
                    goToSlide(currentSlide + 1);
                }, 6000);
            }
        }

        function goToSlide(idx) {
            slides[currentSlide].classList.remove('active');
            slides[currentSlide].style.pointerEvents = 'none';
            currentSlide = ((idx % slides.length) + slides.length) % slides.length;
            slides[currentSlide].classList.add('active');
            slides[currentSlide].style.pointerEvents = '';
            
            updateVideos(currentSlide);
            updateDots(currentSlide);
            updateSoundButtonState();
            scheduleNextSlide();
        }

        // Initialize event listeners for videos
        slides.forEach(function (slide, slideIdx) {
            slide.querySelectorAll('video').forEach(function (v) {
                v.loop = false; // ensure looping is disabled

                v.addEventListener('ended', function () {
                    if (slideIdx === currentSlide) {
                        console.log("Active video " + slideIdx + " ended. Going to next slide.");
                        goToSlide(currentSlide + 1);
                    }
                });

                v.addEventListener('error', function () {
                    if (slideIdx === currentSlide) {
                        console.log("Active video " + slideIdx + " error. Going to next slide.");
                        goToSlide(currentSlide + 1);
                    }
                });
            });
        });

        // Ensure all inactive slides don't intercept clicks
        slides.forEach(function (s, i) {
            if (i !== 0) s.style.pointerEvents = 'none';
        });

        // Initialize the carousel
        updateVideos(0);
        updateDots(0);
        updateSoundButtonState();
        scheduleNextSlide();

        var nextBtn = document.querySelector('.hero-next');
        var prevBtn = document.querySelector('.hero-prev');
        if (nextBtn) nextBtn.addEventListener('click', function () {
            goToSlide(currentSlide + 1);
        });
        if (prevBtn) prevBtn.addEventListener('click', function () {
            goToSlide(currentSlide - 1);
        });

        // Dot click
        dots.forEach(function (d, i) {
            d.addEventListener('click', function () { 
                goToSlide(i); 
            });
        });

        // Sound Toggle
        if (soundBtn) {
            soundBtn.addEventListener('click', function () {
                carouselIsMuted = !carouselIsMuted;
                var activeSlide = slides[currentSlide];
                var video = activeSlide.querySelector('video');
                if (video) {
                    video.muted = carouselIsMuted;
                    video.volume = 0.6;
                }
                updateSoundButtonState();
            });
        }

        // Swipe / touch support
        var touchStartX = 0;
        var carousel = document.querySelector('.hero-carousel');
        if (carousel) {
            carousel.addEventListener('touchstart', function (e) {
                touchStartX = e.changedTouches[0].clientX;
            }, { passive: true });
            carousel.addEventListener('touchend', function (e) {
                var dx = e.changedTouches[0].clientX - touchStartX;
                if (Math.abs(dx) > 50) {
                    if (dx < 0) { 
                        goToSlide(currentSlide + 1); 
                    } else { 
                        goToSlide(currentSlide - 1); 
                    }
                }
            }, { passive: true });
    }
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCarousel);
} else {
    initCarousel();
}
})();

$(document).ready(function() {
    
    // NOTE: Hero carousel is handled by vanilla JS above (no jQuery needed)
    // ==========================================
    // 2. QUICK BOOKING AJAX PIPELINE
    // ==========================================
    const qCinema = $('#qb-cinema');
    const qMovie = $('#qb-movie');
    const qDate = $('#qb-date');
    const qTime = $('#qb-time');
    const qSubmit = $('#qb-submit');

    // Update select element text color based on active selection value
    function updateSelectColor(selectEl) {
        if (selectEl.val()) {
            selectEl.css('color', '#ffffff');
        } else {
            selectEl.css('color', 'var(--text-muted)');
        }
    }

    // Set initial text colors on page load
    $('.quick-booking-bar select').each(function() {
        updateSelectColor($(this));
    });

    // Enable/disable quick book submit
    function checkQuickBookSubmit() {
        if (qTime.val()) {
            qSubmit.prop('disabled', false).removeClass('opacity-50');
        } else {
            qSubmit.prop('disabled', true).addClass('opacity-50');
        }
    }

    function updateBookingBarOptions(changedField) {
        const cinemaId = qCinema.val() || '';
        const movieId = qMovie.val() || '';
        const dateVal = qDate.val() || '';

        console.log(`Quick Booking: Filter changed via [${changedField}] -> Cinema: ${cinemaId}, Movie: ${movieId}, Date: ${dateVal}`);

        // 1. If all three are selected, fetch showtimes (times)
        if (cinemaId && movieId && dateVal) {
            $.ajax({
                url: 'ajax-quick-book.php',
                type: 'GET',
                data: { action: 'get_times', cinema_id: cinemaId, movie_id: movieId, show_date: dateVal },
                dataType: 'json',
                success: function(response) {
                    console.log("Quick Booking: Showtimes fetched =", response);
                    qTime.html('<option value="">4. Chọn Suất</option>');
                    if (response && response.length > 0) {
                        qTime.prop('disabled', false);
                        response.forEach(function(slot) {
                            const timeShort = slot.show_time.substring(0, 5);
                            qTime.append(`<option value="${slot.id}">${timeShort}</option>`);
                        });
                    } else {
                        qTime.prop('disabled', true);
                    }
                    updateSelectColor(qTime);
                    checkQuickBookSubmit();
                },
                error: function(xhr, status, error) {
                    console.error("Quick Booking: Error fetching showtimes =", error);
                }
            });
        } else {
            qTime.html('<option value="">4. Chọn Suất</option>').prop('disabled', true);
            updateSelectColor(qTime);
            checkQuickBookSubmit();
        }

        // 2. Fetch dynamically cross-filtered cinemas, movies, and dates from database
        $.ajax({
            url: 'ajax-quick-book.php',
            type: 'GET',
            data: { 
                action: 'get_filtered_options', 
                cinema_id: cinemaId, 
                movie_id: movieId, 
                show_date: dateVal 
            },
            dataType: 'json',
            success: function(response) {
                console.log("Quick Booking: Filtered options received =", response);

                // Update Cinema options (only if the user hasn't locked one in)
                if (!cinemaId) {
                    const currentCinemaSel = qCinema.val();
                    qCinema.html('<option value="">1. Chọn Rạp</option>');
                    response.cinemas.forEach(function(c) {
                        qCinema.append(`<option value="${c.id}">${c.name}</option>`);
                    });
                    qCinema.val(currentCinemaSel);
                    updateSelectColor(qCinema);
                }

                // Update Movie options (only if the user hasn't locked one in)
                if (!movieId) {
                    const currentMovieSel = qMovie.val();
                    qMovie.html('<option value="">2. Chọn Phim</option>');
                    response.movies.forEach(function(m) {
                        qMovie.append(`<option value="${m.id}">${m.title}</option>`);
                    });
                    qMovie.val(currentMovieSel);
                    updateSelectColor(qMovie);
                }

                // Update Date options (only if the user hasn't locked one in)
                if (!dateVal) {
                    const currentDateSel = qDate.val();
                    qDate.html('<option value="">3. Chọn Ngày</option>');
                    response.dates.forEach(function(d) {
                        const parts = d.split('-');
                        if (parts.length === 3) {
                            const formattedDate = `${parts[2]}/${parts[1]}/${parts[0]}`;
                            qDate.append(`<option value="${d}">${formattedDate}</option>`);
                        } else {
                            qDate.append(`<option value="${d}">${d}</option>`);
                        }
                    });
                    qDate.val(currentDateSel);
                    updateSelectColor(qDate);
                }
            },
            error: function(xhr, status, error) {
                console.error("Quick Booking: Error filtering options =", error);
            }
        });
    }

    // Bind event listeners
    qCinema.on('change', function() {
        updateSelectColor($(this));
        updateBookingBarOptions('cinema');
    });

    qMovie.on('change', function() {
        updateSelectColor($(this));
        updateBookingBarOptions('movie');
    });

    qDate.on('change', function() {
        updateSelectColor($(this));
        updateBookingBarOptions('date');
    });

    qTime.on('change', function() {
        updateSelectColor($(this));
        console.log("Quick Booking: Showtime selected ID =", $(this).val());
        checkQuickBookSubmit();
    });

    qSubmit.on('click', function(e) {
        e.preventDefault();
        const showtimeId = qTime.val();
        console.log("Quick Booking: Submitting, Showtime ID =", showtimeId);
        if (showtimeId) {
            window.location.href = `booking.php?showtime_id=${showtimeId}`;
        }
    });

    // Auto-initialize if movie is preselected and disabled (e.g. on movie-detail.php)
    if (qMovie.val() && qMovie.prop('disabled')) {
        updateBookingBarOptions('movie');
    }

    // ==========================================
    // 3. INTERACTIVE SEAT SELECTION
    // ==========================================
    const selectedSeatsInput = $('#selected_seats');
    const seatNamesDisplay = $('#selected-seat-names');
    const totalPriceDisplay = $('#total-price-display');
    const seatCountDisplay = $('#seat-count');
    const bookingForm = $('#booking-form');

    let selectedSeats = [];

    $('.seat-map-container .seat:not(.booked)').on('click', function() {
        const seatCode = $(this).data('seat');
        const price = parseFloat($(this).data('price'));
        
        if ($(this).hasClass('selected')) {
            // Unselect
            $(this).removeClass('selected');
            selectedSeats = selectedSeats.filter(item => item.code !== seatCode);
        } else {
            // Select
            $(this).addClass('selected');
            selectedSeats.push({ code: seatCode, price: price });
        }

        updateTicketSummary();
    });

    // Concessions variables
    let concessionsQty = {};
    if (window.concessionPrices) {
        Object.keys(window.concessionPrices).forEach(key => {
            concessionsQty[key] = 0;
        });
    }

    let soloQty = 0;
    let twinQty = 0;
    let partyQty = 0;

    $('.concession-plus').on('click', function() {
        const target = $(this).data('target');
        const key = 'concession_' + target;
        
        if (window.concessionPrices && window.concessionPrices[key] !== undefined) {
            concessionsQty[key] = (concessionsQty[key] || 0) + 1;
            $(`#concession-${target}-qty-display`).text(concessionsQty[key]);
            $(`#form-concession-${target}-qty`).val(concessionsQty[key]);
        } else {
            if (target === 'solo') {
                soloQty++;
                $('#concession-solo-qty-display').text(soloQty);
                $('#form-solo-qty').val(soloQty);
            } else if (target === 'twin') {
                twinQty++;
                $('#concession-twin-qty-display').text(twinQty);
                $('#form-twin-qty').val(twinQty);
            } else if (target === 'party') {
                partyQty++;
                $('#concession-party-qty-display').text(partyQty);
                $('#form-party-qty').val(partyQty);
            }
        }
        updateTicketSummary();
    });

    $('.concession-minus').on('click', function() {
        const target = $(this).data('target');
        const key = 'concession_' + target;
        
        if (window.concessionPrices && window.concessionPrices[key] !== undefined) {
            if (concessionsQty[key] > 0) {
                concessionsQty[key]--;
                $(`#concession-${target}-qty-display`).text(concessionsQty[key]);
                $(`#form-concession-${target}-qty`).val(concessionsQty[key]);
            }
        } else {
            if (target === 'solo' && soloQty > 0) {
                soloQty--;
                $('#concession-solo-qty-display').text(soloQty);
                $('#form-solo-qty').val(soloQty);
            } else if (target === 'twin' && twinQty > 0) {
                twinQty--;
                $('#concession-twin-qty-display').text(twinQty);
                $('#form-twin-qty').val(twinQty);
            } else if (target === 'party' && partyQty > 0) {
                partyQty--;
                $('#concession-party-qty-display').text(partyQty);
                $('#form-party-qty').val(partyQty);
            }
        }
        updateTicketSummary();
    });

    function updateTicketSummary() {
        const seatCodes = selectedSeats.map(item => item.code);
        const seatsPrice = selectedSeats.reduce((sum, item) => sum + item.price, 0);
        
        let concessionsPrice = 0;
        if (window.concessionPrices) {
            Object.keys(window.concessionPrices).forEach(key => {
                concessionsPrice += (concessionsQty[key] || 0) * window.concessionPrices[key];
            });
        } else {
            concessionsPrice = (soloQty * 75000) + (twinQty * 110000) + (partyQty * 190000);
        }
        
        const totalPrice = seatsPrice + concessionsPrice;

        if (seatCodes.length > 0) {
            seatNamesDisplay.text(seatCodes.join(', '));
            seatCountDisplay.text(seatCodes.length);
            selectedSeatsInput.val(seatCodes.join(','));
        } else {
            seatNamesDisplay.text('Chưa chọn');
            seatCountDisplay.text('0');
            selectedSeatsInput.val('');
        }

        // Update concessions display line item
        $('#selected-concessions-display').text(new Intl.NumberFormat('vi-VN').format(concessionsPrice) + ' đ');
        
        // Update grand total price
        totalPriceDisplay.text(new Intl.NumberFormat('vi-VN').format(totalPrice) + ' đ');
    }

    // Booking form validation
    if (bookingForm.length > 0) {
        bookingForm.on('submit', function(e) {
            if (selectedSeats.length === 0) {
                e.preventDefault();
                alert('Vui lòng chọn ít nhất 1 ghế trước khi tiếp tục thanh toán!');
            }
        });
    }

    // Auto-dismiss alerts after 5 seconds
    setTimeout(function() {
        $('.alert-dismissible').fadeOut('slow');
    }, 5000);

});
