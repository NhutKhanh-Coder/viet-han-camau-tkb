<?php
// Quick debug page - DELETE AFTER USE
require_once __DIR__ . '/config/Database.php';
$database = new Database();
$db = $database->getConnection();

// Get banners
$stmt = $db->query("SELECT b.*, m.title as mtitle, m.trailer_url FROM banners b JOIN movies m ON b.movie_id = m.id ORDER BY b.sort_order ASC");
$banners = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get videos dir
$videoDir = __DIR__ . '/assets/videos/';
$videoFiles = glob($videoDir . '*.mp4');
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Debug</title>
    <style>
        body { background: #111; color: #eee; font-family: monospace; padding: 20px; }
        .ok { color: #0f0; } .err { color: #f00; } .warn { color: #ff0; }
        pre { background: #222; padding: 10px; border-radius: 4px; overflow-x: auto; }
    </style>
</head>
<body>
<h2>🔍 Debug Report</h2>

<h3>Banners in DB (<?= count($banners) ?>)</h3>
<?php foreach ($banners as $b): ?>
<?php
    $ext = strtolower(pathinfo($b['image'], PATHINFO_EXTENSION));
    $isVideo = in_array($ext, ['mp4','webm','ogg']);
    $filePath = $isVideo
        ? __DIR__ . '/assets/videos/' . $b['image']
        : __DIR__ . '/assets/images/' . $b['image'];
    $exists = file_exists($filePath);
    $size = $exists ? filesize($filePath) : 0;
?>
<pre>
ID: <?= $b['id'] ?> | Movie: <?= htmlspecialchars($b['mtitle']) ?>
Image: <?= $b['image'] ?> (<?= $isVideo ? 'VIDEO' : 'IMAGE' ?>)
File: <span class="<?= $exists ? 'ok' : 'err' ?>"><?= $exists ? "✅ EXISTS ($size bytes)" : "❌ NOT FOUND" ?></span>
Path: <?= $filePath ?>
trailer_url: <?= htmlspecialchars($b['trailer_url']) ?: '(empty)' ?>
</pre>
<?php endforeach; ?>

<h3>Video Files in assets/videos/</h3>
<pre>
<?php foreach ($videoFiles as $f): ?>
<?= basename($f) ?> (<?= number_format(filesize($f)) ?> bytes)
<?php endforeach; ?>
</pre>

<h3>PHP Version: <?= PHP_VERSION ?></h3>

<h3>JS/CSS Paths Check</h3>
<pre>
main.js path: <?= __DIR__ . '/assets/js/main.js' ?> 
main.js exists: <span class="<?= file_exists(__DIR__ . '/assets/js/main.js') ? 'ok' : 'err' ?>"><?= file_exists(__DIR__ . '/assets/js/main.js') ? '✅' : '❌' ?></span>
style.css exists: <span class="<?= file_exists(__DIR__ . '/assets/css/style.css') ? 'ok' : 'err' ?>"><?= file_exists(__DIR__ . '/assets/css/style.css') ? '✅' : '❌' ?></span>
</pre>

<h3>Live Banner HTML Preview</h3>
<?php
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$base_url = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/rapphim/';
?>
<pre>base_url: <?= $base_url ?></pre>

<h3>Test: Can browser load video?</h3>
<?php if (!empty($banners)): ?>
<?php foreach ($banners as $b): 
    $ext = strtolower(pathinfo($b['image'], PATHINFO_EXTENSION));
    $isVideo = in_array($ext, ['mp4','webm','ogg']);
    if ($isVideo):
?>
<p>Testing video: <strong><?= $b['image'] ?></strong></p>
<video src="<?= $base_url ?>assets/videos/<?= $b['image'] ?>" 
       controls muted style="max-width:400px; background:#000;" preload="metadata">
    Cannot play video
</video>
<?php endif; ?>
<?php endforeach; ?>
<?php endif; ?>

<h3>Movie Trailers</h3>
<?php
$stmt2 = $db->query("SELECT id, title, trailer_url FROM movies WHERE trailer_url != '' AND trailer_url IS NOT NULL");
$movies = $stmt2->fetchAll(PDO::FETCH_ASSOC);
foreach ($movies as $m):
    $url = $m['trailer_url'];
    $isEmbed = strpos($url, '/embed/') !== false;
?>
<pre>
ID: <?= $m['id'] ?> | <?= htmlspecialchars($m['title']) ?>
trailer_url: <?= htmlspecialchars($url) ?>
Is YouTube embed URL: <span class="<?= $isEmbed ? 'ok' : 'warn' ?>"><?= $isEmbed ? '✅ YES' : '⚠️ NO - not /embed/ format' ?></span>
</pre>
<?php if ($isEmbed): ?>
<p>Test iframe for movie <?= $m['id'] ?>:</p>
<div style="position:relative;width:560px;height:315px;">
    <iframe 
        src="<?= htmlspecialchars($url) ?>?autoplay=0"
        width="560" height="315"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowfullscreen frameborder="0">
    </iframe>
</div>
<?php endif; ?>
<?php endforeach; ?>

<script>
    console.log('Debug page loaded');
    console.log('jQuery available:', typeof jQuery !== 'undefined' ? 'YES' : 'NO');
</script>
</body>
</html>
