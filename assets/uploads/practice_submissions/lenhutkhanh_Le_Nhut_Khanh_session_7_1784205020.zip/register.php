<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/User.php';

$database = new Database();
$db = $database->getConnection();
$userModel = new User($db);

$is_logged_in = isset($_SESSION['user_id']);

// Redirect if already logged in
if ($is_logged_in) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $email = trim($_POST['email']);
    $fullname = trim($_POST['fullname']);
    $phone = trim($_POST['phone']);

    if (empty($username) || empty($password) || empty($email) || empty($fullname) || empty($phone)) {
        $_SESSION['error'] = "Vui lòng điền đầy đủ tất cả thông tin!";
    } else {
        $reg_result = $userModel->register($username, $password, $email, $fullname, $phone);
        if ($reg_result) {
            $_SESSION['success'] = "Đăng ký tài khoản thành viên thành công! Hãy đăng nhập.";
            header('Location: login.php');
            exit;
        } else {
            $_SESSION['error'] = "Tên đăng nhập hoặc email đã được sử dụng!";
        }
    }
    header('Location: register.php');
    exit;
}

require_once __DIR__ . '/views/header.php';
?>

<div class="container my-5">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-9">
            <div class="auth-card">
                <div class="text-center mb-4">
                    <h2 class="fw-extrabold text-uppercase text-white"><span class="text-warning">Đăng Ký</span> Thành Viên</h2>
                    <p class="text-white-50">Tạo tài khoản để nhận nhiều ưu đãi và đặt vé nhanh chóng</p>
                </div>
                
                <form action="register.php" method="POST">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="username" class="form-label text-white-50">Tên đăng nhập</label>
                            <input type="text" class="form-control form-control-dark" id="username" name="username" required placeholder="Tên tài khoản...">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="password" class="form-label text-white-50">Mật khẩu</label>
                            <input type="password" class="form-control form-control-dark" id="password" name="password" required placeholder="Tạo mật khẩu...">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="fullname" class="form-label text-white-50">Họ và tên</label>
                        <input type="text" class="form-control form-control-dark" id="fullname" name="fullname" required placeholder="Họ và tên đầy đủ...">
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label text-white-50">Địa chỉ Email</label>
                        <input type="email" class="form-control form-control-dark" id="email" name="email" required placeholder="Ví dụ: hotro@gmail.com">
                    </div>

                    <div class="mb-4">
                        <label for="phone" class="form-label text-white-50">Số điện thoại</label>
                        <input type="tel" class="form-control form-control-dark" id="phone" name="phone" required placeholder="Số điện thoại di động...">
                    </div>

                    <div class="form-check mb-4">
                        <input class="form-check-input" type="checkbox" value="" id="agreeCheck" required>
                        <label class="form-check-label text-white-50" for="agreeCheck" style="font-size: 14px;">
                            Tôi đồng ý với điều khoản sử dụng và quy định thành viên của Cinestar.
                        </label>
                    </div>
                    
                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-purple text-uppercase py-3 fw-bold">Đăng ký ngay</button>
                    </div>
                </form>
                
                <div class="text-center mt-4 text-white-50">
                    Đã có tài khoản? <a href="login.php" class="text-warning fw-semibold text-decoration-none">Đăng nhập tại đây</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/views/footer.php';
?>
