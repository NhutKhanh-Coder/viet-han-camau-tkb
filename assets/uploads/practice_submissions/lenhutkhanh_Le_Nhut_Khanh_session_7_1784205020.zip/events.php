<?php
require_once __DIR__ . '/views/header.php';

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = isset($_POST['fullname']) ? trim($_POST['fullname']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $phone = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $event_type = isset($_POST['event_type']) ? trim($_POST['event_type']) : '';
    $cinema_id = isset($_POST['cinema_id']) ? intval($_POST['cinema_id']) : 0;
    $event_date = isset($_POST['event_date']) ? trim($_POST['event_date']) : '';
    $guests = isset($_POST['guests']) ? intval($_POST['guests']) : 0;
    $notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

    if (empty($fullname) || empty($phone) || empty($event_type) || empty($cinema_id) || empty($event_date)) {
        $error_msg = 'Vui lòng điền đầy đủ các thông tin bắt buộc (*).';
    } else {
        // Mock successful submission (in real life this could write to a database or email)
        $success_msg = 'Gửi yêu cầu thành công! Đội ngũ sự kiện Cinestar sẽ liên hệ với bạn trong vòng 24 giờ qua số điện thoại ' . htmlspecialchars($phone) . '.';
    }
}

$cinemas = $cinemaModel->getAll();
?>

<div class="container py-5 min-vh-100">
    <!-- Page Header -->
    <div class="text-center mb-5">
        <h1 class="display-4 fw-bold text-white text-uppercase">
            <span class="text-warning"><i class="fa-solid fa-calendar-check me-2"></i>Tổ Chức</span> Sự Kiện
        </h1>
        <p class="text-white-50 fs-5">Hệ thống phòng chiếu sang trọng, âm thanh ánh sáng đỉnh cao cho mọi sự kiện của bạn</p>
        <div class="mx-auto" style="width: 80px; height: 4px; background: linear-gradient(90deg, var(--accent-yellow), var(--accent-purple)); border-radius: 2px;"></div>
    </div>

    <!-- Banner & Services -->
    <div class="row mb-5 align-items-center">
        <div class="col-lg-6 mb-4 mb-lg-0">
            <img src="assets/images/event_corporate_v2.png" class="img-fluid rounded shadow-lg border border-secondary-light" alt="Cinema Event Banner" style="width: 100%; max-height: 380px; object-fit: cover;">
        </div>
        <div class="col-lg-6 ps-lg-5">
            <h2 class="text-white fw-bold mb-4">Tại sao nên chọn Cinestar?</h2>
            <div class="d-flex mb-4">
                <div class="text-warning fs-3 me-3 mt-1"><i class="fa-solid fa-tv"></i></div>
                <div>
                    <h5 class="text-white fw-bold">Màn hình khổng lồ & Âm thanh Dolby Atmos</h5>
                    <p class="text-white-50" style="font-size: 14px;">Trang bị hệ thống trình chiếu 2D/3D hiện đại cùng dàn âm thanh vòm Dolby sống động, nâng tầm trải nghiệm hội thảo và hội nghị của bạn.</p>
                </div>
            </div>
            <div class="d-flex mb-4">
                <div class="text-warning fs-3 me-3 mt-1"><i class="fa-solid fa-chair"></i></div>
                <div>
                    <h5 class="text-white fw-bold">Không gian sang trọng & Sức chứa lớn</h5>
                    <p class="text-white-50" style="font-size: 14px;">Ghế ngồi bọc nhung cao cấp với sức chứa đa dạng từ 100 đến 400 chỗ, đáp ứng mọi quy mô họp mặt của cơ quan và hội nhóm.</p>
                </div>
            </div>
            <div class="d-flex">
                <div class="text-warning fs-3 me-3 mt-1"><i class="fa-solid fa-gifts"></i></div>
                <div>
                    <h5 class="text-white fw-bold">Dịch vụ ăn uống trọn gói & Chuyên nghiệp</h5>
                    <p class="text-white-50" style="font-size: 14px;">Hỗ trợ phục vụ Teabreak, Bắp nước theo Combo sự kiện cùng đội ngũ kỹ thuật và phục vụ tận tâm suốt thời gian diễn ra.</p>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-5">
        <!-- Event Packages Grid -->
        <div class="col-lg-6">
            <h3 class="text-white fw-bold mb-4 border-bottom border-secondary-light pb-2"><i class="fa-solid fa-cubes text-warning me-2"></i>Gói sự kiện phổ biến</h3>
            
            <div class="bg-secondary-cinestar p-4 mb-3 border border-secondary-light rounded-3 transition-hover">
                <h5 class="text-warning fw-bold"><i class="fa-solid fa-handshake me-2"></i>Hội thảo & Ra mắt sản phẩm</h5>
                <p class="text-white-50 mb-0" style="font-size: 14px;">Trình chiếu slide bài thuyết trình hoặc video giới thiệu sản phẩm trực tiếp lên màn hình lớn cinema. Đầy đủ micro không dây và bục phát biểu chuyên nghiệp.</p>
            </div>

            <div class="bg-secondary-cinestar p-4 mb-3 border border-secondary-light rounded-3 transition-hover">
                <h5 class="text-warning fw-bold"><i class="fa-solid fa-cake-candles me-2"></i>Sinh nhật & Cầu hôn lãng mạn</h5>
                <p class="text-white-50 mb-0" style="font-size: 14px;">Bất ngờ dành cho người thương yêu với phòng chiếu riêng tư, trình chiếu video kỷ niệm tự chọn, bóng bay trang trí và backdrop chụp hình ấn tượng.</p>
            </div>

            <div class="bg-secondary-cinestar p-4 border border-secondary-light rounded-3 transition-hover">
                <h5 class="text-warning fw-bold"><i class="fa-solid fa-people-group me-2"></i>Xem phim theo đoàn (Private Booking)</h5>
                <p class="text-white-50 mb-0" style="font-size: 14px;">Thuê trọn phòng chiếu suất riêng để xem các bộ phim đang hot cùng đồng nghiệp, đối tác hoặc fanclub. Nhận ưu đãi chiết khấu bắp nước cực lớn.</p>
            </div>
        </div>

        <!-- Inquiry Form -->
        <div class="col-lg-6">
            <h3 class="text-white fw-bold mb-4 border-bottom border-secondary-light pb-2"><i class="fa-solid fa-envelope-open-text text-warning me-2"></i>Đăng ký nhận báo giá</h3>

            <?php if (!empty($success_msg)): ?>
                <div class="alert alert-success bg-success text-white border-0 py-3 shadow-lg" role="alert">
                    <i class="fa-solid fa-circle-check fs-5 me-2"></i> <?php echo $success_msg; ?>
                </div>
            <?php endif; ?>

            <?php if (!empty($error_msg)): ?>
                <div class="alert alert-danger bg-danger text-white border-0 py-3 shadow-lg" role="alert">
                    <i class="fa-solid fa-triangle-exclamation fs-5 me-2"></i> <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <form action="events.php" method="POST" class="bg-secondary-cinestar p-4 border border-secondary-light rounded-3 shadow-lg">
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="fullname" class="form-label text-white fw-semibold" style="font-size: 14px;">Họ tên của bạn *</label>
                        <input type="text" class="form-control bg-dark border-secondary text-white" id="fullname" name="fullname" required placeholder="Nguyễn Văn A">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="phone" class="form-label text-white fw-semibold" style="font-size: 14px;">Số điện thoại *</label>
                        <input type="tel" class="form-control bg-dark border-secondary text-white" id="phone" name="phone" required placeholder="0901234567">
                    </div>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label text-white fw-semibold" style="font-size: 14px;">Địa chỉ email</label>
                    <input type="email" class="form-control bg-dark border-secondary text-white" id="email" name="email" placeholder="example@gmail.com">
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="event_type" class="form-label text-white fw-semibold" style="font-size: 14px;">Loại hình sự kiện *</label>
                        <select class="form-select bg-dark border-secondary text-white-50" id="event_type" name="event_type" required>
                            <option value="">-- Chọn dịch vụ --</option>
                            <option value="Hội nghị / Hội thảo">Hội nghị / Hội thảo</option>
                            <option value="Sinh nhật / Kỷ niệm">Sinh nhật / Kỷ niệm</option>
                            <option value="Thuê phòng xem phim">Thuê phòng xem phim riêng</option>
                            <option value="Khác">Khác</option>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="cinema_id" class="form-label text-white fw-semibold" style="font-size: 14px;">Rạp chiếu lựa chọn *</label>
                        <select class="form-select bg-dark border-secondary text-white-50" id="cinema_id" name="cinema_id" required>
                            <option value="">-- Chọn chi nhánh rạp --</option>
                            <?php foreach ($cinemas as $cinema): ?>
                                <option value="<?php echo $cinema['id']; ?>"><?php echo htmlspecialchars($cinema['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label for="event_date" class="form-label text-white fw-semibold" style="font-size: 14px;">Ngày tổ chức dự kiến *</label>
                        <input type="date" class="form-control bg-dark border-secondary text-white" id="event_date" name="event_date" required min="<?php echo date('Y-m-d'); ?>">
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="guests" class="form-label text-white fw-semibold" style="font-size: 14px;">Số lượng khách dự kiến</label>
                        <input type="number" class="form-control bg-dark border-secondary text-white" id="guests" name="guests" min="10" placeholder="Ví dụ: 50">
                    </div>
                </div>

                <div class="mb-4">
                    <label for="notes" class="form-label text-white fw-semibold" style="font-size: 14px;">Ghi chú chi tiết yêu cầu</label>
                    <textarea class="form-control bg-dark border-secondary text-white" id="notes" name="notes" rows="3" placeholder="Ghi chi tiết khung giờ mong muốn, dịch vụ ăn uống kèm theo..."></textarea>
                </div>

                <button type="submit" class="btn btn-yellow w-100 text-uppercase fw-bold py-2"><i class="fa-solid fa-paper-plane me-2"></i>Gửi yêu cầu báo giá</button>
            </form>
        </div>
    </div>
</div>

<style>
.bg-secondary-cinestar {
    background-color: var(--bg-secondary);
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
}
.transition-hover {
    transition: all 0.3s ease;
}
.transition-hover:hover {
    transform: translateX(5px);
    border-color: var(--accent-purple) !important;
    background-color: rgba(124, 58, 237, 0.05) !important;
}
.border-secondary-light {
    border-color: rgba(255, 255, 255, 0.08) !important;
}
.form-control:focus, .form-select:focus {
    background-color: var(--bg-tertiary) !important;
    border-color: var(--accent-purple) !important;
    color: #fff !important;
    box-shadow: 0 0 10px rgba(124, 58, 237, 0.25);
}
</style>

<?php
require_once __DIR__ . '/views/footer.php';
?>
