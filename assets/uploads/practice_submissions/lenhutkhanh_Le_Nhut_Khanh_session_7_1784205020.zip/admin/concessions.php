<?php
require_once __DIR__ . '/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. DELETE ACTION
if ($action === 'delete') {
    $itemId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($itemId > 0) {
        $item = $concessionModel->getById($itemId);
        if ($item) {
            // Delete product image if exists
            $uploadDir = __DIR__ . '/../assets/images/';
            if (!empty($item['image'])) {
                $image_path = $uploadDir . $item['image'];
                if (file_exists($image_path) && is_file($image_path)) {
                    // Make sure no other item is using this image before deleting
                    $db_check = $db->prepare("SELECT COUNT(*) FROM concession_items WHERE image = :img AND id != :id");
                    $db_check->execute([':img' => $item['image'], ':id' => $itemId]);
                    if ($db_check->fetchColumn() == 0) {
                        @unlink($image_path);
                    }
                }
            }
            if ($concessionModel->delete($itemId)) {
                $_SESSION['success'] = "Xóa combo bắp nước thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi xóa combo bắp nước!";
            }
        }
    }
    header('Location: concessions.php');
    exit;
}

// 2. CREATE / UPDATE POST SUBMISSIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = isset($_POST['action']) ? $_POST['action'] : '';
    
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $icon_type = $_POST['icon_type'];

    $uploadDir = __DIR__ . '/../assets/images/';
    $imageName = null;
    
    // File upload handling
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = 'concession_' . time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", $fileName);
            $dest_path = $uploadDir . $newFileName;
            
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $imageName = $newFileName;
            }
        }
    }

    if ($postAction === 'add') {
        if (empty($name) || $price <= 0) {
            $_SESSION['error'] = "Vui lòng nhập đầy đủ tên combo và giá bán hợp lệ!";
        } else {
            $success = $concessionModel->create($name, $description, $price, $icon_type, $imageName);
            if ($success) {
                $_SESSION['success'] = "Thêm combo bắp nước mới thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi thêm combo!";
            }
        }
    } elseif ($postAction === 'edit') {
        $id = intval($_POST['id']);
        if ($id > 0) {
            // Fetch old concession to check for image deletion
            if ($imageName !== null) {
                $old_item = $concessionModel->getById($id);
                if ($old_item && !empty($old_item['image'])) {
                    $old_image_path = $uploadDir . $old_item['image'];
                    if (file_exists($old_image_path) && is_file($old_image_path)) {
                        $db_check = $db->prepare("SELECT COUNT(*) FROM concession_items WHERE image = :img AND id != :id");
                        $db_check->execute([':img' => $old_item['image'], ':id' => $id]);
                        if ($db_check->fetchColumn() == 0) {
                            @unlink($old_image_path);
                        }
                    }
                }
            }
            
            $success = $concessionModel->update($id, $name, $description, $price, $icon_type, $imageName);
            if ($success) {
                $_SESSION['success'] = "Cập nhật combo bắp nước thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi cập nhật combo!";
            }
        }
    }
    
    header('Location: concessions.php');
    exit;
}

// Fetch all concessions
$items = $concessionModel->getAll();
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Bắp Nước</h2>
        <p class="text-white-50">Thêm, sửa, xóa các gói combo bắp và nước ngọt tại rạp</p>
    </div>
    <div class="col-md-6 text-md-end">
        <?php if (empty($action)): ?>
            <a href="concessions.php?action=add" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-circle-plus me-1"></i>Thêm Combo Mới</a>
        <?php else: ?>
            <a href="concessions.php" class="btn btn-outline-warning text-uppercase fw-bold"><i class="fa-solid fa-arrow-left-long me-1"></i>Quay lại danh sách</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($action === 'add'): ?>
    <!-- ADD CONCESSION FORM -->
    <div class="admin-card text-white">
        <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-ice-cream me-2"></i>Thêm Combo Mới</h4>
        <form action="concessions.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add">
            
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label for="name" class="form-label text-white-50">Tên Combo *</label>
                    <input type="text" class="form-control form-control-dark" id="name" name="name" required placeholder="Ví dụ: Solo Combo, Family Combo...">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="icon_type" class="form-label text-white-50">Biểu tượng vẽ (Icon Type)</label>
                    <select class="form-select form-control-dark" id="icon_type" name="icon_type">
                        <option value="solo">Solo (1 Bắp + 1 Nước)</option>
                        <option value="twin">Twin (1 Bắp + 2 Nước)</option>
                        <option value="party">Party / Family (2 Bắp + nhiều nước)</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label text-white-50">Mô tả chi tiết Combo (Thành phần bắp/nước)</label>
                <textarea class="form-control form-control-dark" id="description" name="description" rows="3" placeholder="Nhập mô tả sản phẩm..."></textarea>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="price" class="form-label text-white-50">Giá bán (VNĐ) *</label>
                    <input type="number" class="form-control form-control-dark" id="price" name="price" required min="1000" step="1000" placeholder="Ví dụ: 75000">
                </div>
                <div class="col-md-6 mb-4">
                    <label for="image" class="form-label text-white-50">Ảnh minh họa sản phẩm (Tùy chọn)</label>
                    <input type="file" class="form-control form-control-dark" id="image" name="image" accept="image/*">
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Nếu để trống, hệ thống sẽ sử dụng hình vẽ vector tương ứng làm đại diện.</small>
                </div>
            </div>

            <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Thêm Combo</button>
        </form>
    </div>

<?php elseif ($action === 'edit'): 
    $itemId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $item = $concessionModel->getById($itemId);
    if (!$item) {
        header('Location: concessions.php');
        exit;
    }
?>
    <!-- EDIT CONCESSION FORM -->
    <div class="admin-card text-white">
        <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-pen-to-square me-2"></i>Sửa Thông Tin Combo</h4>
        <form action="concessions.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" value="<?php echo $item['id']; ?>">
            
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label for="name" class="form-label text-white-50">Tên Combo *</label>
                    <input type="text" class="form-control form-control-dark" id="name" name="name" value="<?php echo htmlspecialchars($item['name']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="icon_type" class="form-label text-white-50">Biểu tượng vẽ (Icon Type)</label>
                    <select class="form-select form-control-dark" id="icon_type" name="icon_type">
                        <option value="solo" <?php echo $item['icon_type'] === 'solo' ? 'selected' : ''; ?>>Solo (1 Bắp + 1 Nước)</option>
                        <option value="twin" <?php echo $item['icon_type'] === 'twin' ? 'selected' : ''; ?>>Twin (1 Bắp + 2 Nước)</option>
                        <option value="party" <?php echo $item['icon_type'] === 'party' ? 'selected' : ''; ?>>Party / Family (2 Bắp + nhiều nước)</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label text-white-50">Mô tả chi tiết Combo</label>
                <textarea class="form-control form-control-dark" id="description" name="description" rows="3"><?php echo htmlspecialchars($item['description']); ?></textarea>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="price" class="form-label text-white-50">Giá bán (VNĐ) *</label>
                    <input type="number" class="form-control form-control-dark" id="price" name="price" value="<?php echo intval($item['price']); ?>" required min="1000" step="1000">
                </div>
                <div class="col-md-6 mb-4">
                    <label for="image" class="form-label text-white-50">Ảnh minh họa sản phẩm mới (Tùy chọn)</label>
                    <input type="file" class="form-control form-control-dark" id="image" name="image" accept="image/*">
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Để trống nếu giữ nguyên hình ảnh hiện tại.</small>
                </div>
            </div>

            <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Cập nhật Combo</button>
        </form>
    </div>

<?php else: ?>
    <!-- LIST VIEW -->
    <div class="admin-card">
        <?php if (empty($items)): ?>
            <p class="text-white-50 text-center py-4">Không tìm thấy sản phẩm combo bắp nước nào.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table admin-table m-0">
                    <thead>
                        <tr>
                            <th>Minh họa</th>
                            <th>Tên Combo</th>
                            <th>Mô tả chi tiết</th>
                            <th>Giá bán</th>
                            <th class="text-end">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <div class="bg-dark rounded p-2 d-flex align-items-center justify-content-center border border-secondary overflow-hidden" style="width: 60px; height: 60px;">
                                        <?php if (!empty($item['image']) && file_exists('../assets/images/' . $item['image'])): ?>
                                            <img src="../assets/images/<?php echo $item['image']; ?>" class="w-100 h-100 rounded" style="object-fit: cover;">
                                        <?php else: ?>
                                            <?php if ($item['icon_type'] === 'solo'): ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="40" height="40">
                                                    <path d="M30,30 L35,80 L65,80 L70,30 Z" fill="#b91c1c" />
                                                    <path d="M30,30 Q50,40 70,30 L67,40 Q50,30 33,40 Z" fill="#f59e0b" />
                                                    <circle cx="35" cy="20" r="10" fill="#fef08a" />
                                                    <circle cx="50" cy="15" r="12" fill="#fef08a" />
                                                    <circle cx="65" cy="20" r="10" fill="#fef08a" />
                                                    <polygon points="50,45 53,52 60,52 55,56 57,63 50,59 43,63 45,56 40,52 47,52" fill="#facc15" />
                                                </svg>
                                            <?php elseif ($item['icon_type'] === 'twin'): ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="40" height="40">
                                                    <path d="M25,30 L30,80 L55,80 L60,30 Z" fill="#1e3a8a" />
                                                    <circle cx="30" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="42" cy="15" r="10" fill="#fef08a" />
                                                    <circle cx="55" cy="20" r="8" fill="#fef08a" />
                                                    <path d="M62,40 L66,80 L82,80 L86,40 Z" fill="#b91c1c" />
                                                    <line x1="74" y1="40" x2="65" y2="15" stroke="#fff" stroke-width="4" stroke-linecap="round" />
                                                </svg>
                                            <?php else: ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="40" height="40">
                                                    <path d="M20,30 L25,80 L50,80 L55,30 Z" fill="#7c3aed" />
                                                    <circle cx="25" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="37" cy="15" r="10" fill="#fef08a" />
                                                    <circle cx="50" cy="20" r="8" fill="#fef08a" />
                                                    <path d="M50,30 L55,80 L75,80 L80,30 Z" fill="#047857" />
                                                    <circle cx="55" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="65" cy="15" r="10" fill="#fef08a" />
                                                    <circle cx="75" cy="20" r="8" fill="#fef08a" />
                                                    <line x1="72" y1="30" x2="85" y2="10" stroke="#fff" stroke-width="3" stroke-linecap="round" />
                                                </svg>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><strong class="text-white"><?php echo htmlspecialchars($item['name']); ?></strong></td>
                                <td class="text-white-50" style="font-size: 13px; max-width: 400px;"><?php echo htmlspecialchars($item['description']); ?></td>
                                <td class="text-warning fw-extrabold"><?php echo number_format($item['price'], 0, ',', '.'); ?> đ</td>
                                <td class="text-end">
                                    <a href="concessions.php?action=edit&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-info me-1" title="Sửa"><i class="fa-solid fa-pen-to-square"></i> Sửa</a>
                                    <a href="concessions.php?action=delete&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa combo bắp nước này?')" title="Xóa"><i class="fa-solid fa-trash"></i> Xóa</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php
require_once __DIR__ . '/footer.php';
?>
