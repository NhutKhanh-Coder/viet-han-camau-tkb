<?php
// ╔══════════════════════════════════════════════════════════════╗
// ║  ACTION HANDLING — TRƯỚC KHI CÓ BẤT KỲ HTML NÀO ĐƯỢC OUTPUT ║
// ╚══════════════════════════════════════════════════════════════╝
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/User.php';

// Kiểm tra auth (redirect ngay nếu chưa login hoặc không phải admin)
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}
$_db          = (new Database())->getConnection();
$_um          = new User($_db);
$_cu          = $_um->getById($_SESSION['user_id']);
if (!$_cu || $_cu['role'] !== 'admin') {
    header('Location: ../index.php');
    exit;
}
$_aid = intval($_SESSION['user_id']); // current admin id (int)

// ─── GET DELETE ACTION ────────────────────────────────────────
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    $id = intval($_GET['id'] ?? 0);
    file_put_contents(__DIR__ . '/users_debug.log', date('Y-m-d H:i:s') . " GET DELETE handler: id=$id aid=$_aid\n", FILE_APPEND);

    if ($id <= 0) {
        $_SESSION['error'] = "ID không hợp lệ!";
        file_put_contents(__DIR__ . '/users_debug.log', date('Y-m-d H:i:s') . " DELETE BLOCKED: id<=0\n", FILE_APPEND);
    } elseif ($id === $_aid) {
        $_SESSION['error'] = "Bạn không thể xóa tài khoản đang đăng nhập!";
        file_put_contents(__DIR__ . '/users_debug.log', date('Y-m-d H:i:s') . " DELETE BLOCKED: same as admin id=$_aid\n", FILE_APPEND);
    } else {
        try {
            $delResult = $_um->delete($id);
            file_put_contents(__DIR__ . '/users_debug.log', date('Y-m-d H:i:s') . " DELETE result: " . ($delResult ? 'SUCCESS' : 'FAIL') . "\n", FILE_APPEND);
            if ($delResult) {
                $_SESSION['success'] = "Xóa tài khoản thành công!";
            } else {
                $_SESSION['error'] = "Xóa thất bại — tài khoản không tồn tại!";
            }
        } catch (PDOException $e) {
            $errMsg = $e->getMessage();
            file_put_contents(__DIR__ . '/users_debug.log', date('Y-m-d H:i:s') . " DELETE EXCEPTION: $errMsg\n", FILE_APPEND);
            $_SESSION['error'] = "Lỗi DB khi xóa: " . htmlspecialchars($errMsg);
        }
    }
    header('Location: users.php');
    exit;
}

// Xử lý tất cả POST ngay tại đây — header() hoạt động chắc chắn vì chưa có HTML nào
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pa = trim($_POST['action'] ?? '');
    // DEBUG LOG
    file_put_contents(__DIR__ . '/users_debug.log', date('Y-m-d H:i:s') . " POST received: action=$pa id=" . ($_POST['id'] ?? 'N/A') . " session_user=" . ($_SESSION['user_id'] ?? 'N/A') . "\n", FILE_APPEND);

    // ─── CREATE ──────────────────────────────────────────────────
    if ($pa === 'create') {
        $u  = trim($_POST['username'] ?? '');
        $pw = trim($_POST['password'] ?? '');
        $em = trim($_POST['email']    ?? '');
        $fn = trim($_POST['fullname'] ?? '');
        $ph = trim($_POST['phone']    ?? '');
        $ro = in_array(($_POST['role'] ?? ''), ['admin','member']) ? $_POST['role'] : 'member';

        if (!$u || !$pw || !$em || !$fn || !$ph) {
            $_SESSION['error'] = "Vui lòng điền đầy đủ tất cả các trường bắt buộc!";
        } elseif (strlen($pw) < 6) {
            $_SESSION['error'] = "Mật khẩu phải có ít nhất 6 ký tự!";
        } elseif ($_um->createByAdmin($u, $pw, $em, $fn, $ph, $ro)) {
            $_SESSION['success'] = "Tạo tài khoản <strong>@{$u}</strong> thành công!";
        } else {
            $_SESSION['error'] = "Tên đăng nhập hoặc email đã tồn tại!";
        }
        header('Location: users.php');
        exit;
    }

    // ─── EDIT ─────────────────────────────────────────────────────
    if ($pa === 'edit') {
        $id = intval($_POST['id']     ?? 0);
        $em = trim($_POST['email']    ?? '');
        $fn = trim($_POST['fullname'] ?? '');
        $ph = trim($_POST['phone']    ?? '');
        $ro = in_array(($_POST['role'] ?? ''), ['admin','member']) ? $_POST['role'] : 'member';

        if ($id === $_aid) {
            $_SESSION['error'] = "Bạn không thể tự chỉnh sửa tài khoản của chính mình từ đây!";
        } elseif (!$em || !$fn || !$ph) {
            $_SESSION['error'] = "Vui lòng điền đầy đủ thông tin!";
        } elseif ($_um->adminUpdateProfile($id, $em, $fn, $ph, $ro)) {
            $_SESSION['success'] = "Cập nhật thông tin thành viên thành công!";
        } else {
            $_SESSION['error'] = "Email đã được sử dụng bởi tài khoản khác!";
        }
        header('Location: users.php');
        exit;
    }

    // ─── RESET PASSWORD ───────────────────────────────────────────
    if ($pa === 'resetpw') {
        $id = intval($_POST['id']          ?? 0);
        $pw = trim($_POST['new_password']  ?? '');

        if ($id === $_aid) {
            $_SESSION['error'] = "Hãy đổi mật khẩu qua trang Hồ sơ cá nhân!";
        } elseif (strlen($pw) < 6) {
            $_SESSION['error'] = "Mật khẩu mới phải có ít nhất 6 ký tự!";
        } elseif ($_um->adminResetPassword($id, $pw)) {
            $t = $_um->getById($id);
            $_SESSION['success'] = "Đã đặt lại mật khẩu cho <strong>@" . htmlspecialchars($t['username']) . "</strong>!";
        } else {
            $_SESSION['error'] = "Có lỗi khi đặt lại mật khẩu!";
        }
        header('Location: users.php');
        exit;
    }

    // ─── CHANGEROLE ───────────────────────────────────────────────
    if ($pa === 'changerole') {
        $id = intval($_POST['id']   ?? 0);
        $ro = (($_POST['role'] ?? '') === 'admin') ? 'admin' : 'member';

        if ($id > 0 && $id !== $_aid) {
            $_um->updateRole($id, $ro);
            $_SESSION['success'] = "Cập nhật vai trò thành công!";
        } else {
            $_SESSION['error'] = "Không thể thực hiện thao tác này!";
        }
        header('Location: users.php');
        exit;
    }
}

// ═══════════════════════════════════════════════════════════════
// SAU KHI XỬ LÝ ACTION → INCLUDE HEADER.PHP ĐỂ RENDER HTML
// ═══════════════════════════════════════════════════════════════
require_once __DIR__ . '/header.php';

// Lúc này $userModel, $current_admin_id đã được header.php tạo ra
// nhưng chúng ta vẫn giữ $_aid và $_um từ trên để dùng
$action           = isset($_GET['action']) ? $_GET['action'] : '';
$userId           = isset($_GET['id'])     ? intval($_GET['id']) : 0;
$current_admin_id = $_aid; // int, nhất quán

$editUser   = null;
$targetUser = null;
if ($action === 'edit' && $userId > 0) {
    $editUser = $_um->getById($userId);
    if (!$editUser) { header('Location: users.php'); exit; }
}
if ($action === 'resetpw' && $userId > 0) {
    $targetUser = $_um->getById($userId);
    if (!$targetUser) { header('Location: users.php'); exit; }
}

$users = $_um->getAll();
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Thành Viên</h2>
        <p class="text-white-50">Thêm mới, chỉnh sửa thông tin, đặt lại mật khẩu và phân quyền tài khoản</p>
    </div>
    <div class="col-md-6 text-md-end">
        <?php if (!in_array($action, ['create','edit','resetpw'])): ?>
            <a href="users.php?action=create" class="btn btn-yellow text-uppercase fw-bold">
                <i class="fa-solid fa-user-plus me-1"></i>Thêm Tài Khoản Mới
            </a>
        <?php else: ?>
            <a href="users.php" class="btn btn-outline-warning text-uppercase fw-bold">
                <i class="fa-solid fa-arrow-left-long me-1"></i>Quay lại danh sách
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if ($action === 'create'): ?>
<!-- ===== CREATE FORM ===== -->
<div class="admin-card text-white">
    <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-user-plus me-2"></i>Tạo Tài Khoản Mới</h4>
    <form action="users.php" method="POST">
        <input type="hidden" name="action" value="create">
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Tên đăng nhập *</label>
                <input type="text" name="username" class="form-control form-control-dark" required placeholder="username (không dấu, không cách)">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Mật khẩu *</label>
                <input type="password" name="password" class="form-control form-control-dark" required placeholder="Tối thiểu 6 ký tự">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Vai trò</label>
                <select name="role" class="form-select form-control-dark">
                    <option value="member">Thành Viên</option>
                    <option value="admin">Quản Trị Viên</option>
                </select>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Họ và tên *</label>
                <input type="text" name="fullname" class="form-control form-control-dark" required placeholder="Nguyễn Văn A">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Email *</label>
                <input type="email" name="email" class="form-control form-control-dark" required placeholder="email@domain.com">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Số điện thoại *</label>
                <input type="text" name="phone" class="form-control form-control-dark" required placeholder="09xxxxxxxx">
            </div>
        </div>
        <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">
            <i class="fa-solid fa-user-plus me-1"></i>Tạo tài khoản
        </button>
    </form>
</div>

<?php elseif ($action === 'edit' && $editUser): ?>
<!-- ===== EDIT FORM ===== -->
<div class="admin-card text-white">
    <h4 class="fw-bold mb-4 text-warning">
        <i class="fa-solid fa-user-pen me-2"></i>Chỉnh sửa tài khoản:
        <span class="text-white-50 fw-normal fs-6">@<?php echo htmlspecialchars($editUser['username']); ?></span>
    </h4>
    <form action="users.php" method="POST">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="id"     value="<?php echo $editUser['id']; ?>">
        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Họ và tên *</label>
                <input type="text" name="fullname" class="form-control form-control-dark" required
                       value="<?php echo htmlspecialchars($editUser['fullname']); ?>">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Email *</label>
                <input type="email" name="email" class="form-control form-control-dark" required
                       value="<?php echo htmlspecialchars($editUser['email']); ?>">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label text-white-50">Số điện thoại *</label>
                <input type="text" name="phone" class="form-control form-control-dark" required
                       value="<?php echo htmlspecialchars($editUser['phone']); ?>">
            </div>
        </div>
        <div class="row">
            <div class="col-md-4 mb-4">
                <label class="form-label text-white-50">Vai trò</label>
                <select name="role" class="form-select form-control-dark">
                    <option value="member" <?php echo $editUser['role']==='member' ? 'selected' : ''; ?>>Thành Viên</option>
                    <option value="admin"  <?php echo $editUser['role']==='admin'  ? 'selected' : ''; ?>>Quản Trị Viên</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">
            <i class="fa-solid fa-floppy-disk me-1"></i>Lưu thay đổi
        </button>
    </form>
</div>

<?php elseif ($action === 'resetpw' && $targetUser): ?>
<!-- ===== RESET PASSWORD FORM ===== -->
<div class="admin-card text-white" style="max-width:560px;">
    <h4 class="fw-bold mb-2 text-warning"><i class="fa-solid fa-key me-2"></i>Đặt lại mật khẩu</h4>
    <p class="text-white-50 mb-4">
        Tài khoản: <strong class="text-white">@<?php echo htmlspecialchars($targetUser['username']); ?></strong>
        — <?php echo htmlspecialchars($targetUser['fullname']); ?>
    </p>
    <form action="users.php" method="POST">
        <input type="hidden" name="action" value="resetpw">
        <input type="hidden" name="id"     value="<?php echo $targetUser['id']; ?>">
        <div class="mb-4">
            <label class="form-label text-white-50">Mật khẩu mới *</label>
            <input type="password" name="new_password" class="form-control form-control-dark"
                   required minlength="6" placeholder="Tối thiểu 6 ký tự">
            <small class="text-white-50 d-block mt-1">Người dùng sẽ cần dùng mật khẩu này để đăng nhập lần tới.</small>
        </div>
        <button type="submit" class="btn btn-warning text-dark text-uppercase fw-bold px-4 py-2"
                onclick="return confirm('Xác nhận đặt lại mật khẩu?')">
            <i class="fa-solid fa-key me-1"></i>Đặt lại mật khẩu
        </button>
    </form>
</div>

<?php else: ?>
<!-- ===== USER LIST ===== -->
<div class="admin-card">
    <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-users me-2"></i>Danh sách thành viên</h4>
    <?php if (empty($users)): ?>
        <p class="text-white-50 text-center py-5">Chưa có người dùng nào.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table admin-table m-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Tên đăng nhập</th>
                        <th>Họ và tên</th>
                        <th>Email</th>
                        <th>SĐT</th>
                        <th>Vai trò</th>
                        <th>Ngày đăng ký</th>
                        <th class="text-end">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user): ?>
                        <?php $uid = intval($user['id']); ?>
                        <tr>
                            <td class="text-white-50">#<?php echo $user['id']; ?></td>
                            <td><strong class="text-white">@<?php echo htmlspecialchars($user['username']); ?></strong></td>
                            <td><?php echo htmlspecialchars($user['fullname']); ?></td>
                            <td class="text-white-50" style="font-size:13px;"><?php echo htmlspecialchars($user['email']); ?></td>
                            <td class="text-white-50" style="font-size:13px;"><?php echo htmlspecialchars($user['phone']); ?></td>
                            <td>
                                <?php if ($user['role'] === 'admin'): ?>
                                    <span class="badge bg-warning text-dark"><i class="fa-solid fa-user-shield me-1"></i>Quản Trị</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Thành Viên</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-white-50" style="font-size:12px;">
                                <?php echo date('d/m/Y H:i', strtotime($user['created_at'])); ?>
                            </td>
                            <td class="text-end" style="white-space:nowrap;">
                                <?php if ($uid !== $current_admin_id): ?>
                                    <!-- Edit -->
                                    <a href="users.php?action=edit&id=<?php echo $uid; ?>"
                                       class="btn btn-sm btn-outline-info me-1" title="Chỉnh sửa">
                                        <i class="fa-solid fa-user-pen"></i>
                                    </a>
                                    <!-- Reset PW -->
                                    <a href="users.php?action=resetpw&id=<?php echo $uid; ?>"
                                       class="btn btn-sm btn-outline-warning me-1" title="Đặt lại mật khẩu">
                                        <i class="fa-solid fa-key"></i>
                                    </a>
                                    <!-- Toggle Role -->
                                    <form method="post" action="users.php" style="display:inline;">
                                        <input type="hidden" name="action" value="changerole">
                                        <input type="hidden" name="id"     value="<?php echo $uid; ?>">
                                        <?php if ($user['role'] === 'admin'): ?>
                                            <input type="hidden" name="role" value="member">
                                            <button type="submit" class="btn btn-sm btn-outline-secondary me-1" title="Hạ xuống Thành Viên">
                                                <i class="fa-solid fa-user-minus"></i>
                                            </button>
                                        <?php else: ?>
                                            <input type="hidden" name="role" value="admin">
                                            <button type="submit" class="btn btn-sm btn-outline-warning me-1" title="Cấp quyền Quản Trị">
                                                <i class="fa-solid fa-user-plus"></i>
                                            </button>
                                        <?php endif; ?>
                                    </form>
                                    <!-- Delete -->
                                    <a href="users.php?action=delete&id=<?php echo $uid; ?>"
                                       class="btn btn-sm btn-outline-danger" title="Xóa tài khoản"
                                       onclick="return confirm('Bạn có chắc chắn muốn xóa tài khoản @<?php echo htmlspecialchars($user['username']); ?>?\nHợp đồng đặt vé và lịch sử liên quan cũng sẽ bị xóa!')">
                                        <i class="fa-solid fa-user-xmark"></i>
                                    </a>
                                <?php else: ?>
                                    <span class="text-white-50" style="font-size:12px;font-style:italic;">Tài khoản hiện tại</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
