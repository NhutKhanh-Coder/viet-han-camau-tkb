<?php
require_once __DIR__ . '/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';
$bookingId = isset($_GET['id']) ? intval($_GET['id']) : 0;

// 1. PROCESS ACTION
if ($action === 'delete' && $bookingId > 0) {
    if ($bookingModel->delete($bookingId)) {
        $_SESSION['success'] = "Hủy và xóa lịch sử đặt vé thành công! Ghế ngồi đã được giải phóng.";
    } else {
        $_SESSION['error'] = "Có lỗi xảy ra khi hủy đặt vé!";
    }
    header('Location: bookings.php');
    exit;
}

// CSV EXPORT ACTION (runs before any HTML output)
if ($action === 'export_csv') {
    ob_end_clean(); // clear any output buffer from header.php
    $search       = trim($_GET['search']       ?? '');
    $cinema_id    = intval($_GET['cinema_id']   ?? 0);
    $booking_date = trim($_GET['booking_date']  ?? '');

    $csvSql = "SELECT b.id, u.fullname, u.username, u.phone, u.email,
                      m.title AS movie_title, c.name AS cinema_name,
                      s.show_date, s.show_time, b.seats, b.concessions,
                      b.total_price, b.booking_date
               FROM bookings b
               JOIN users u     ON b.user_id     = u.id
               JOIN showtimes s ON b.showtime_id = s.id
               JOIN movies m    ON s.movie_id    = m.id
               JOIN cinemas c   ON s.cinema_id   = c.id";
    $csvWhere  = [];
    $csvParams = [];
    if (!empty($search)) {
        $csvWhere[]          = '(u.fullname LIKE :search OR u.username LIKE :search OR m.title LIKE :search OR u.phone LIKE :search)';
        $csvParams[':search'] = '%' . $search . '%';
    }
    if ($cinema_id > 0) { $csvWhere[] = 'c.id = :cinema_id'; $csvParams[':cinema_id'] = $cinema_id; }
    if (!empty($booking_date)) { $csvWhere[] = 'DATE(b.booking_date) = :booking_date'; $csvParams[':booking_date'] = $booking_date; }
    if ($csvWhere) $csvSql .= ' WHERE ' . implode(' AND ', $csvWhere);
    $csvSql .= ' ORDER BY b.booking_date DESC';
    $csvStmt = $db->prepare($csvSql);
    $csvStmt->execute($csvParams);
    $rows = $csvStmt->fetchAll(PDO::FETCH_ASSOC);

    $filename = 'datve_cinestar_' . date('Ymd_His') . '.csv';
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Cache-Control: no-cache, no-store, must-revalidate');

    $out = fopen('php://output', 'w');
    // UTF-8 BOM so Excel reads Vietnamese correctly
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Mã vé','Họ và tên','Username','SĐT','Email','Phim','Rạp chiếu','Ngày chiếu','Suất chiếu','Ghế đặt','Bắp nước','Tổng tiền (đ)','Ngày đặt vé']);
    foreach ($rows as $r) {
        fputcsv($out, [
            '#' . $r['id'],
            $r['fullname'], $r['username'], $r['phone'], $r['email'],
            $r['movie_title'], $r['cinema_name'],
            date('d/m/Y', strtotime($r['show_date'])),
            date('H:i',   strtotime($r['show_time'])),
            $r['seats'],
            $r['concessions'] ?? '',
            number_format($r['total_price'], 0, '.', ''),
            date('d/m/Y H:i', strtotime($r['booking_date']))
        ]);
    }
    fclose($out);
    exit;
}

// 2. FETCH STATISTICS
$totalBookings = $db->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$totalRevenue = $db->query("SELECT SUM(total_price) FROM bookings")->fetchColumn();
$totalRevenue = $totalRevenue ? $totalRevenue : 0;

$todayBookings = $db->query("SELECT COUNT(*) FROM bookings WHERE DATE(booking_date) = CURDATE()")->fetchColumn();
$todayRevenue = $db->query("SELECT SUM(total_price) FROM bookings WHERE DATE(booking_date) = CURDATE()")->fetchColumn();
$todayRevenue = $todayRevenue ? $todayRevenue : 0;

// 3. FILTERING & SEARCHING
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$cinema_id = isset($_GET['cinema_id']) ? intval($_GET['cinema_id']) : 0;
$booking_date = isset($_GET['booking_date']) ? trim($_GET['booking_date']) : '';

$sql = "SELECT b.*, u.username, u.fullname, u.phone, u.email, s.show_date, s.show_time, m.title as movie_title, c.name as cinema_name 
        FROM bookings b
        JOIN users u ON b.user_id = u.id
        JOIN showtimes s ON b.showtime_id = s.id
        JOIN movies m ON s.movie_id = m.id
        JOIN cinemas c ON s.cinema_id = c.id";

$where_clauses = [];
$params = [];

if (!empty($search)) {
    $where_clauses[] = "(u.fullname LIKE :search OR u.username LIKE :search OR m.title LIKE :search OR u.phone LIKE :search)";
    $params[':search'] = '%' . $search . '%';
}

if ($cinema_id > 0) {
    $where_clauses[] = "c.id = :cinema_id";
    $params[':cinema_id'] = $cinema_id;
}

if (!empty($booking_date)) {
    $where_clauses[] = "DATE(b.booking_date) = :booking_date";
    $params[':booking_date'] = $booking_date;
}

if (!empty($where_clauses)) {
    $sql .= " WHERE " . implode(" AND ", $where_clauses);
}

$sql .= " ORDER BY b.booking_date DESC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch all cinemas for filter dropdown
$cinemas = $cinemaModel->getAll();
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Đặt Vé</h2>
        <p class="text-white-50">Xem chi tiết giao dịch, tìm kiếm/lọc vé của khách hàng và hủy vé khi cần thiết</p>
    </div>
</div>

<!-- Widgets Stats Dashboard -->
<div class="row mb-4">
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Tổng vé đã bán</div>
                <div class="fs-3 fw-extrabold text-warning mt-1"><?php echo $totalBookings; ?></div>
            </div>
            <i class="fa-solid fa-ticket text-warning-50 fs-2 opacity-25"></i>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Tổng doanh thu</div>
                <div class="fs-3 fw-extrabold text-success mt-1"><?php echo number_format($totalRevenue, 0, ',', '.'); ?> đ</div>
            </div>
            <i class="fa-solid fa-sack-dollar text-success-50 fs-2 opacity-25"></i>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Vé bán hôm nay</div>
                <div class="fs-3 fw-extrabold text-info mt-1"><?php echo $todayBookings; ?></div>
            </div>
            <i class="fa-solid fa-calendar-check text-info-50 fs-2 opacity-25"></i>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Doanh thu hôm nay</div>
                <div class="fs-3 fw-extrabold text-purple mt-1" style="color: var(--accent-purple);"><?php echo number_format($todayRevenue, 0, ',', '.'); ?> đ</div>
            </div>
            <i class="fa-solid fa-hand-holding-dollar text-purple-50 fs-2 opacity-25"></i>
        </div>
    </div>
</div>

<!-- Filter and Search Form Card -->
<div class="admin-card mb-4">
    <h5 class="text-white fw-bold mb-3"><i class="fa-solid fa-filter text-warning me-2"></i>Bộ lọc tìm kiếm</h5>
    <form action="bookings.php" method="GET" class="row g-3 m-0">
        <div class="col-lg-4">
            <label class="form-label text-white-50" style="font-size: 13px;">Từ khóa tìm kiếm</label>
            <input type="text" name="search" class="form-control form-control-dark" placeholder="Tên KH, username, phim, SĐT..." value="<?php echo htmlspecialchars($search); ?>">
        </div>
        <div class="col-lg-3">
            <label class="form-label text-white-50" style="font-size: 13px;">Rạp chiếu</label>
            <select name="cinema_id" class="form-select form-control-dark">
                <option value="0">-- Tất cả cụm rạp --</option>
                <?php foreach ($cinemas as $c): ?>
                    <option value="<?php echo $c['id']; ?>" <?php echo $cinema_id == $c['id'] ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($c['name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-lg-3">
            <label class="form-label text-white-50" style="font-size: 13px;">Ngày đặt vé</label>
            <input type="date" name="booking_date" class="form-control form-control-dark" value="<?php echo htmlspecialchars($booking_date); ?>">
        </div>
        <div class="col-lg-2 d-flex align-items-end">
            <button type="submit" class="btn btn-yellow w-100 py-2 text-uppercase fw-bold"><i class="fa-solid fa-magnifying-glass me-1"></i> Lọc</button>
        </div>
    </form>
</div>

<!-- Bookings Table View -->
<div class="admin-card">
    <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
        <h4 class="fw-bold mb-0 text-warning"><i class="fa-solid fa-list-check me-2"></i>Danh sách giao dịch đặt vé</h4>
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-secondary py-2 px-3">Tìm thấy: <?php echo count($bookings); ?> giao dịch</span>
            <?php
                $csvQuery = http_build_query([
                    'action'       => 'export_csv',
                    'search'       => $search,
                    'cinema_id'    => $cinema_id,
                    'booking_date' => $booking_date
                ]);
            ?>
            <a href="bookings.php?<?php echo $csvQuery; ?>" class="btn btn-sm btn-outline-success" title="Xuất danh sách ra file CSV">
                <i class="fa-solid fa-file-csv me-1"></i>Xuất CSV
            </a>
        </div>
    </div>
    
    <?php if (empty($bookings)): ?>
        <p class="text-white-50 text-center py-5 mb-0">Không tìm thấy giao dịch đặt vé nào phù hợp với bộ lọc.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table admin-table m-0">
                <thead>
                    <tr>
                        <th>Mã</th>
                        <th>Khách hàng</th>
                        <th>Phim</th>
                        <th>Rạp</th>
                        <th>Suất chiếu</th>
                        <th>Ghế đặt</th>
                        <th>Bắp nước</th>
                        <th>Tổng tiền</th>
                        <th>Ngày đặt</th>
                        <th class="text-end">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bookings as $b): ?>
                        <tr>
                            <td><strong>#<?php echo $b['id']; ?></strong></td>
                            <td>
                                <div class="fw-bold text-white"><?php echo htmlspecialchars($b['fullname']); ?></div>
                                <div class="text-white-50" style="font-size: 12px;">@<?php echo htmlspecialchars($b['username']); ?></div>
                                <div class="text-info" style="font-size: 12px;"><?php echo htmlspecialchars($b['phone']); ?></div>
                            </td>
                            <td>
                                <span class="fw-semibold text-white"><?php echo htmlspecialchars($b['movie_title']); ?></span>
                            </td>
                            <td>
                                <span style="font-size: 13px;"><?php echo htmlspecialchars($b['cinema_name']); ?></span>
                            </td>
                            <td>
                                <span class="text-warning fw-bold"><?php echo date('H:i', strtotime($b['show_time'])); ?></span>
                                <div class="text-white-50" style="font-size: 11px;"><?php echo date('d/m/Y', strtotime($b['show_date'])); ?></div>
                            </td>
                            <td>
                                <?php 
                                    $seats_arr = explode(',', $b['seats']);
                                    foreach ($seats_arr as $seat):
                                        $seat = trim($seat);
                                        $row = substr($seat, 0, 1);
                                        $is_vip = in_array($row, ['E', 'F', 'G']);
                                        $badge_class = $is_vip ? 'bg-purple text-white' : 'bg-secondary text-white';
                                        $style = $is_vip ? 'style="background-color: #a21caf;"' : '';
                                ?>
                                    <span class="badge <?php echo $badge_class; ?>" <?php echo $style; ?> style="font-size: 11px; margin: 1px;"><?php echo $seat; ?></span>
                                <?php endforeach; ?>
                            </td>
                            <td style="font-size: 13px; max-width: 180px;" class="text-white-50">
                                <?php echo !empty($b['concessions']) ? htmlspecialchars($b['concessions']) : '-'; ?>
                            </td>
                            <td>
                                <span class="text-success fw-extrabold"><?php echo number_format($b['total_price'], 0, ',', '.'); ?> đ</span>
                            </td>
                            <td style="font-size: 12px;" class="text-white-50">
                                <?php echo date('d/m/Y H:i', strtotime($b['booking_date'])); ?>
                            </td>
                            <td class="text-end">
                                <a href="bookings.php?action=delete&id=<?php echo $b['id']; ?>" 
                                   class="btn btn-sm btn-outline-danger" 
                                   onclick="return confirm('Bạn có chắc chắn muốn hủy giao dịch đặt vé này? Ghế đã đặt sẽ được giải phóng lập tức!')" 
                                   title="Hủy vé & giải phóng ghế">
                                    <i class="fa-solid fa-trash-can"></i> Hủy
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<?php
require_once __DIR__ . '/footer.php';
?>
