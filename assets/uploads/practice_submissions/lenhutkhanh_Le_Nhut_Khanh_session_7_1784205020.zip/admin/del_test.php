<?php
session_start();
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/User.php';

$db = (new Database())->getConnection();
$um = new User($db);

$msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = intval($_POST['id'] ?? 0);
    $msg = "POST received! id=$id, action=" . ($_POST['action'] ?? 'none') . "<br>";
    if ($id > 0) {
        try {
            $result = $um->delete($id);
            $msg .= "Delete result: " . ($result ? "<b style='color:green'>SUCCESS</b>" : "<b style='color:red'>FAIL</b>") . "<br>";
        } catch (Exception $e) {
            $msg .= "Exception: " . htmlspecialchars($e->getMessage()) . "<br>";
        }
    } else {
        $msg .= "<b style='color:red'>id <= 0, delete skipped</b><br>";
    }
}

$users = $db->query("SELECT id, username, role FROM users ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>Delete Test</title></head>
<body style="font-family:sans-serif;padding:20px;">
<h2>Delete Test Page</h2>
<?php if ($msg): ?><div style="background:#eee;padding:10px;margin-bottom:10px;"><?= $msg ?></div><?php endif; ?>
<h3>Users hiện tại:</h3>
<table border="1" cellpadding="5">
  <tr><th>ID</th><th>Username</th><th>Role</th><th>Xóa</th></tr>
  <?php foreach ($users as $u): ?>
  <tr>
    <td><?= $u['id'] ?></td>
    <td><?= htmlspecialchars($u['username']) ?></td>
    <td><?= $u['role'] ?></td>
    <td>
      <form method="post">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= $u['id'] ?>">
        <button type="submit">Xóa</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
<br>
<a href="del_test.php">Reload</a> | <a href="users.php">Back to users.php</a>
</body>
</html>
