<?php
require_once __DIR__ . '/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. DELETE ACTION
if ($action === 'delete') {
    $showtimeId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($showtimeId > 0) {
        if ($showtimeModel->delete($showtimeId)) {
            $_SESSION['success'] = "Xóa lịch chiếu thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra khi xóa lịch chiếu!";
        }
    }
    header('Location: showtimes.php');
    exit;
}

// 2. CREATE POST SUBMISSION
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $movie_id = isset($_POST['movie_id']) ? intval($_POST['movie_id']) : 0;
    $movie_title = isset($_POST['movie_title']) ? trim($_POST['movie_title']) : '';
    
    // Resolve movie ID by title if ID is not populated
    if ($movie_id <= 0 && !empty($movie_title)) {
        // Try exact match first
        $db_check = $db->prepare("SELECT id FROM movies WHERE title = :title LIMIT 1");
        $db_check->execute([':title' => $movie_title]);
        $row = $db_check->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $movie_id = intval($row['id']);
        } else {
            // Try fuzzy match: find any movie title that is contained within the typed title, or vice versa
            $all_movies_check = $db->query("SELECT id, title FROM movies")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($all_movies_check as $m) {
                $db_t = mb_strtolower($m['title'], 'UTF-8');
                $input_t = mb_strtolower($movie_title, 'UTF-8');
                if (strpos($input_t, $db_t) !== false || strpos($db_t, $input_t) !== false) {
                    $movie_id = intval($m['id']);
                    break;
                }
            }
        }
    }
    
    $cinema_id = intval($_POST['cinema_id']);
    $show_date = $_POST['show_date'];
    $show_time = $_POST['show_time'];
    $price = floatval($_POST['price']);

    if ($movie_id <= 0 || $cinema_id <= 0 || empty($show_date) || empty($show_time) || $price <= 0) {
        $_SESSION['error'] = "Vui lòng nhập và chọn phim hợp lệ, điền đầy đủ thông tin lịch chiếu!";
    } else {
        $success = $showtimeModel->create($movie_id, $cinema_id, $show_date, $show_time, $price);
        if ($success) {
            $_SESSION['success'] = "Lên lịch chiếu phim thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra khi tạo lịch chiếu!";
        }
    }
    
    header('Location: showtimes.php');
    exit;
}

// Fetch lists for forms and listing
$allMovies = $movieModel->getAll();
$allCinemas = $cinemaModel->getAll();
$allShowtimes = $showtimeModel->getAll();
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Lịch Chiếu</h2>
        <p class="text-white-50">Lên lịch phát sóng phim tại các cụm rạp</p>
    </div>
</div>

<div class="row">
    <!-- Form column -->
    <div class="col-lg-4 mb-4">
        <div class="admin-card text-white">
            <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-calendar-plus me-2"></i>Thêm Lịch Chiếu</h4>
            
            <form action="showtimes.php" method="POST">
                <div class="mb-3">
                    <label for="movie_title_input" class="form-label text-white-50">Chọn phim (Nhập tên phim) *</label>
                    <input type="text" class="form-control form-control-dark" id="movie_title_input" name="movie_title" list="movies_list" placeholder="Gõ tên phim để tìm kiếm..." required autocomplete="off">
                    <input type="hidden" name="movie_id" id="movie_id" value="">
                    <datalist id="movies_list">
                        <?php foreach ($allMovies as $m): ?>
                            <option data-value="<?php echo $m['id']; ?>" value="<?php echo htmlspecialchars($m['title']); ?>"></option>
                        <?php endforeach; ?>
                    </datalist>
                </div>

                <div class="mb-3">
                    <label for="cinema_id" class="form-label text-white-50">Chọn rạp chiếu</label>
                    <select class="form-select form-control-dark" id="cinema_id" name="cinema_id" required>
                        <option value="">-- Chọn rạp --</option>
                        <?php foreach ($allCinemas as $c): ?>
                            <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="mb-3">
                    <label for="show_date" class="form-label text-white-50">Ngày chiếu</label>
                    <input type="date" class="form-control form-control-dark" id="show_date" name="show_date" required min="<?php echo date('Y-m-d'); ?>">
                </div>

                <div class="mb-3">
                    <label for="show_time" class="form-label text-white-50">Giờ chiếu (Suất)</label>
                    <input type="time" class="form-control form-control-dark" id="show_time" name="show_time" required>
                </div>

                <div class="mb-4">
                    <label for="price" class="form-label text-white-50">Giá vé cơ bản (đ)</label>
                    <input type="number" class="form-control form-control-dark" id="price" name="price" required min="1000" step="5000" value="75000" placeholder="Ví dụ: 75000">
                </div>

                <button type="submit" class="btn btn-yellow text-uppercase fw-bold w-100 py-2">Thêm lịch chiếu</button>
            </form>
        </div>
    </div>

    <!-- Listing Table column -->
    <div class="col-lg-8 mb-4">
        <div class="admin-card">
            <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-list-check me-2"></i>Danh sách suất chiếu</h4>
            
            <?php if (empty($allShowtimes)): ?>
                <p class="text-white-50 text-center py-4">Chưa có lịch chiếu nào được cấu hình.</p>
            <?php else: ?>
                <div class="table-responsive" style="max-height: 520px; overflow-y: auto;">
                    <table class="table admin-table m-0">
                        <thead>
                            <tr>
                                <th>Phim</th>
                                <th>Rạp</th>
                                <th>Ngày chiếu</th>
                                <th>Suất chiếu</th>
                                <th>Giá vé</th>
                                <th class="text-end">Xóa</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($allShowtimes as $s): ?>
                                <tr>
                                    <td><strong class="text-white"><?php echo htmlspecialchars($s['movie_title']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($s['cinema_name']); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($s['show_date'])); ?></td>
                                    <td class="text-warning fw-bold"><?php echo date('H:i', strtotime($s['show_time'])); ?></td>
                                    <td><?php echo number_format($s['price'], 0, ',', '.'); ?> đ</td>
                                    <td class="text-end">
                                        <a href="showtimes.php?action=delete&id=<?php echo $s['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa lịch chiếu này?')" title="Xóa"><i class="fa-solid fa-trash-can"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var titleInput = document.getElementById('movie_title_input');
    var idInput = document.getElementById('movie_id');
    var datalist = document.getElementById('movies_list');
    
    if (titleInput && datalist) {
        titleInput.addEventListener('input', function() {
            var val = this.value;
            var matchedId = "";
            var options = datalist.querySelectorAll('option');
            for (var i = 0; i < options.length; i++) {
                if (options[i].value === val) {
                    matchedId = options[i].getAttribute('data-value');
                    break;
                }
            }
            idInput.value = matchedId;
            titleInput.setCustomValidity("");
        });
        
        titleInput.addEventListener('change', function() {
            var val = this.value.trim();
            var matched = false;
            var matchedTitle = "";
            var matchedId = "";
            var options = datalist.querySelectorAll('option');
            
            // First pass: exact match (case insensitive)
            for (var i = 0; i < options.length; i++) {
                if (options[i].value.toLowerCase() === val.toLowerCase()) {
                    matched = true;
                    matchedTitle = options[i].value;
                    matchedId = options[i].getAttribute('data-value');
                    break;
                }
            }
            
            // Second pass: if no exact match, try fuzzy match (containment)
            if (!matched && val !== '') {
                for (var i = 0; i < options.length; i++) {
                    var optionVal = options[i].value.toLowerCase();
                    var inputVal = val.toLowerCase();
                    if (inputVal.indexOf(optionVal) !== -1 || optionVal.indexOf(inputVal) !== -1) {
                        matched = true;
                        matchedTitle = options[i].value;
                        matchedId = options[i].getAttribute('data-value');
                        break;
                    }
                }
            }
            
            if (matched) {
                this.value = matchedTitle; // Auto-correct to registered title
                idInput.value = matchedId;
                titleInput.setCustomValidity("");
            } else if (val !== '') {
                titleInput.setCustomValidity("Tên phim không tồn tại trong danh sách. Vui lòng chọn một phim có sẵn!");
                titleInput.reportValidity();
            } else {
                titleInput.setCustomValidity("");
            }
        });
    }
});
</script>

<?php
require_once __DIR__ . '/footer.php';
?>
