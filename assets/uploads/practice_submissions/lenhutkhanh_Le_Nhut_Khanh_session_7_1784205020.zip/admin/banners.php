<?php
require_once __DIR__ . '/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. DELETE ACTION
if ($action === 'delete') {
    $bannerId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($bannerId > 0) {
        $banner = $bannerModel->getById($bannerId);
        if ($banner) {
            // Delete custom banner image if exists and is not shared with default movie images
            $ext = strtolower(pathinfo($banner['image'], PATHINFO_EXTENSION));
            $is_video = in_array($ext, ['mp4', 'webm', 'ogg']);
            $uploadDir = $is_video ? __DIR__ . '/../assets/videos/' : __DIR__ . '/../assets/images/';
            if (!empty($banner['image']) && $banner['image'] !== 'doraemon.png' && $banner['image'] !== 'ma_xo.png' && $banner['image'] !== 'ngoi_den_ky_quai_4.png') {
                $image_path = $uploadDir . $banner['image'];
                if (file_exists($image_path) && is_file($image_path)) {
                    // Make sure no other banner is using this image before deleting
                    $db_check = $db->prepare("SELECT COUNT(*) FROM banners WHERE image = :img AND id != :id");
                    $db_check->execute([':img' => $banner['image'], ':id' => $bannerId]);
                    if ($db_check->fetchColumn() == 0) {
                        @unlink($image_path);
                        
                        // Also delete original backup if it's a video
                        if ($is_video) {
                            $base_name = pathinfo($banner['image'], PATHINFO_FILENAME);
                            $original_path = $uploadDir . $base_name . '_original.' . $ext;
                            if (file_exists($original_path) && is_file($original_path)) {
                                @unlink($original_path);
                            }
                        }
                    }
                }
            }
            if ($bannerModel->delete($bannerId)) {
                $_SESSION['success'] = "Xóa banner thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi xóa banner!";
            }
        }
    }
    header('Location: banners.php');
    exit;
}

// 2. CREATE / UPDATE POST SUBMISSIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = isset($_POST['action']) ? $_POST['action'] : '';
    
    $movie_id = isset($_POST['movie_id']) ? intval($_POST['movie_id']) : 0;
    $movie_title = isset($_POST['movie_title']) ? trim($_POST['movie_title']) : '';
    
    // Fallback: Resolve movie_id by title if ID is not populated
    if ($movie_id <= 0 && !empty($movie_title)) {
        // Try exact match first
        $db_check = $db->prepare("SELECT id FROM movies WHERE title = :title LIMIT 1");
        $db_check->execute([':title' => $movie_title]);
        $row = $db_check->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $movie_id = intval($row['id']);
        } else {
            // Try fuzzy match: find any movie title that is contained within the typed title, or vice versa
            $all_movies_check = $db->query("SELECT id, title FROM movies")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($all_movies_check as $m) {
                $db_t = mb_strtolower($m['title'], 'UTF-8');
                $input_t = mb_strtolower($movie_title, 'UTF-8');
                if (strpos($input_t, $db_t) !== false || strpos($db_t, $input_t) !== false) {
                    $movie_id = intval($m['id']);
                    break;
                }
            }
        }
    }
    
    $subtitle = trim($_POST['subtitle']);
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $sort_order = intval($_POST['sort_order']);

    $imageName = '';
    
    // File upload handling
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'mp4', 'webm', 'ogg'];
        if (in_array($fileExtension, $allowedExtensions)) {
            $is_video = in_array($fileExtension, ['mp4', 'webm', 'ogg']);
            $prefix = $is_video ? 'video_' : 'banner_';
            $newFileName = $prefix . time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", $fileName);
            
            if ($is_video) {
                $uploadDir = __DIR__ . '/../assets/videos/';
                if (!file_exists($uploadDir)) {
                    @mkdir($uploadDir, 0777, true);
                }
            } else {
                $uploadDir = __DIR__ . '/../assets/images/';
            }
            
            $dest_path = $uploadDir . $newFileName;
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $imageName = $newFileName;

                // ── Auto-trim cuối video (bỏ logo TikTok) ──────────────────
                if ($is_video) {
                    $trim_seconds = isset($_POST['trim_seconds']) ? max(0, (int)$_POST['trim_seconds']) : 3;

                    // Backup original untrimmed video
                    $base_name = pathinfo($newFileName, PATHINFO_FILENAME);
                    $original_path = $uploadDir . $base_name . '_original.' . $fileExtension;
                    copy($dest_path, $original_path);

                    if ($trim_seconds > 0) {
                        // Tìm ffprobe / ffmpeg (thử PATH trước, fallback full path)
                        $ffprobe_bin = 'ffprobe';
                        $ffmpeg_bin  = 'ffmpeg';

                        // Lấy thời lượng video bằng ffprobe
                        $escaped = escapeshellarg($dest_path);
                        $dur_cmd  = "$ffprobe_bin -v error -show_entries format=duration "
                                  . "-of default=noprint_wrappers=1:nokey=1 $escaped 2>&1";
                        $duration = (float)shell_exec($dur_cmd);

                        if ($duration > ($trim_seconds + 1)) {
                            $new_duration = $duration - $trim_seconds;
                            $temp_path    = $uploadDir . 'tmp_' . $newFileName;
                            $escaped_out  = escapeshellarg($temp_path);

                            // Transcode to support high precision trimming
                            $ff_cmd = "$ffmpeg_bin -y -i $escaped -t $new_duration -c:v libx264 -preset fast -crf 22 -c:a aac $escaped_out 2>&1";
                            shell_exec($ff_cmd);

                            if (file_exists($temp_path) && filesize($temp_path) > 1024) {
                                unlink($dest_path);
                                rename($temp_path, $dest_path);
                            } elseif (file_exists($temp_path)) {
                                @unlink($temp_path); // dọn file lỗi
                            }
                        }
                    }
                }
                // ────────────────────────────────────────────────────────────
            }
        }
    }


    if ($postAction === 'add') {
        if ($movie_id <= 0 || empty($title) || empty($subtitle)) {
            $_SESSION['error'] = "Vui lòng nhập và chọn phim hợp lệ, điền tiêu đề phụ và tiêu đề chính!";
        } else {
            // If no custom image uploaded, fallback to the movie's main poster image
            if (empty($imageName)) {
                $selected_movie = $movieModel->getById($movie_id);
                $imageName = ($selected_movie && !empty($selected_movie['image'])) ? $selected_movie['image'] : 'default_banner.png';
            }
            
            $trim_seconds = isset($_POST['trim_seconds']) ? max(0, (int)$_POST['trim_seconds']) : 3;
            $success = $bannerModel->create($movie_id, $subtitle, $title, $description, $imageName, $trim_seconds, $sort_order);
            if ($success) {
                $_SESSION['success'] = "Thêm banner thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi thêm banner!";
            }
        }
    } elseif ($postAction === 'edit') {
        $id = intval($_POST['id']);
        if ($id > 0) {
            if ($movie_id <= 0 || empty($title) || empty($subtitle)) {
                $_SESSION['error'] = "Vui lòng nhập và chọn phim hợp lệ, điền tiêu đề phụ và tiêu đề chính!";
            } else {
                // Fetch old banner to check for file replacement
                $old_banner = $bannerModel->getById($id);
                $trim_seconds = isset($_POST['trim_seconds']) ? max(0, (int)$_POST['trim_seconds']) : 3;
                
                // If new image is uploaded and it's different from the old one, we can clean up the old file
                if (!empty($imageName) && $old_banner && !empty($old_banner['image'])) {
                    if ($old_banner['image'] !== 'doraemon.png' && $old_banner['image'] !== 'ma_xo.png' && $old_banner['image'] !== 'ngoi_den_ky_quai_4.png') {
                        $old_ext = strtolower(pathinfo($old_banner['image'], PATHINFO_EXTENSION));
                        $old_is_video = in_array($old_ext, ['mp4', 'webm', 'ogg']);
                        $old_dir = $old_is_video ? __DIR__ . '/../assets/videos/' : __DIR__ . '/../assets/images/';
                        $old_image_path = $old_dir . $old_banner['image'];
                        if (file_exists($old_image_path) && is_file($old_image_path)) {
                            $db_check = $db->prepare("SELECT COUNT(*) FROM banners WHERE image = :img AND id != :id");
                            $db_check->execute([':img' => $old_banner['image'], ':id' => $id]);
                            if ($db_check->fetchColumn() == 0) {
                                @unlink($old_image_path);
                                
                                // Clean up old original backup
                                if ($old_is_video) {
                                    $old_base = pathinfo($old_banner['image'], PATHINFO_FILENAME);
                                    $old_original_path = $old_dir . $old_base . '_original.' . $old_ext;
                                    if (file_exists($old_original_path) && is_file($old_original_path)) {
                                        @unlink($old_original_path);
                                    }
                                }
                            }
                        }
                    }
                }
                
                // If NO new image is uploaded, check if trim_seconds changed to re-trim the existing video
                if (empty($imageName) && $old_banner && !empty($old_banner['image'])) {
                    $old_image = $old_banner['image'];
                    $ext = strtolower(pathinfo($old_image, PATHINFO_EXTENSION));
                    $is_video = in_array($ext, ['mp4', 'webm', 'ogg']);
                    
                    if ($is_video && (int)$old_banner['trim_seconds'] !== $trim_seconds) {
                        $uploadDir = __DIR__ . '/../assets/videos/';
                        $dest_path = $uploadDir . $old_image;
                        $base_name = pathinfo($old_image, PATHINFO_FILENAME);
                        $original_path = $uploadDir . $base_name . '_original.' . $ext;
                        
                        // Fallback for special case video_1780670610_7904963651056.mp4
                        if ($old_image === 'video_1780670610_7904963651056.mp4' && !file_exists($original_path)) {
                            $backup_global = $uploadDir . 'video_original_backup.mp4';
                            if (file_exists($backup_global)) {
                                copy($backup_global, $original_path);
                            }
                        }
                        
                        // If original path does not exist, initialize it from dest_path
                        if (!file_exists($original_path) && file_exists($dest_path)) {
                            copy($dest_path, $original_path);
                        }
                        
                        if (file_exists($original_path)) {
                            // Copy original untrimmed video back to dest_path
                            copy($original_path, $dest_path);
                            
                            if ($trim_seconds > 0) {
                                $ffprobe_bin = 'ffprobe';
                                $ffmpeg_bin  = 'ffmpeg';

                                $escaped = escapeshellarg($dest_path);
                                $dur_cmd  = "$ffprobe_bin -v error -show_entries format=duration "
                                          . "-of default=noprint_wrappers=1:nokey=1 $escaped 2>&1";
                                $duration = (float)shell_exec($dur_cmd);

                                if ($duration > ($trim_seconds + 1)) {
                                    $new_duration = $duration - $trim_seconds;
                                    $temp_path    = $uploadDir . 'tmp_' . $old_image;
                                    $escaped_out  = escapeshellarg($temp_path);

                                    $ff_cmd = "$ffmpeg_bin -y -i $escaped -t $new_duration -c:v libx264 -preset fast -crf 22 -c:a aac $escaped_out 2>&1";
                                    shell_exec($ff_cmd);

                                    if (file_exists($temp_path) && filesize($temp_path) > 1024) {
                                        unlink($dest_path);
                                        rename($temp_path, $dest_path);
                                    } elseif (file_exists($temp_path)) {
                                        @unlink($temp_path);
                                    }
                                }
                            }
                        }
                    }
                }
                
                $success = $bannerModel->update($id, $movie_id, $subtitle, $title, $description, $imageName, $trim_seconds, $sort_order);
                if ($success) {
                    $_SESSION['success'] = "Cập nhật banner thành công!";
                } else {
                    $_SESSION['error'] = "Có lỗi xảy ra khi cập nhật banner!";
                }
            }
        }
    }
    
    header('Location: banners.php');
    exit;
}

// Fetch helper data
$movies = $movieModel->getAll();
$banners = $bannerModel->getAll();
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Banner</h2>
        <p class="text-white-50">Tùy chỉnh các slide quảng cáo phim nổi bật trên trang chủ</p>
    </div>
    <div class="col-md-6 text-md-end">
        <?php if (empty($action)): ?>
            <a href="banners.php?action=add" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-circle-plus me-1"></i>Thêm Banner Mới</a>
        <?php else: ?>
            <a href="banners.php" class="btn btn-outline-warning text-uppercase fw-bold"><i class="fa-solid fa-arrow-left-long me-1"></i>Quay lại danh sách</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($action === 'add'): ?>
    <!-- ADD BANNER FORM -->
    <div class="admin-card text-white">
        <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-images me-2"></i>Thêm Banner Mới</h4>
        <form action="banners.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add">
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="movie_title_input" class="form-label text-white-50">Liên kết tới phim (Nhập tên phim) *</label>
                    <input type="text" class="form-control form-control-dark" id="movie_title_input" name="movie_title" list="movies_list" placeholder="Gõ tên phim để tìm kiếm..." required autocomplete="off">
                    <input type="hidden" name="movie_id" id="movie_id" value="">
                    <datalist id="movies_list">
                        <?php foreach ($movies as $movie): ?>
                            <option data-value="<?php echo $movie['id']; ?>" value="<?php echo htmlspecialchars($movie['title']); ?>"></option>
                        <?php endforeach; ?>
                    </datalist>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="subtitle" class="form-label text-white-50">Nhãn phụ (Badge / Subtitle) *</label>
                    <input type="text" class="form-control form-control-dark" id="subtitle" name="subtitle" required placeholder="Ví dụ: Hot Ticket, Phim Bom Tấn, Kinh Dị Việt...">
                </div>
            </div>

            <div class="mb-3">
                <label for="title" class="form-label text-white-50">Tiêu đề chính trên Banner *</label>
                <input type="text" class="form-control form-control-dark" id="title" name="title" required placeholder="Nhập tiêu đề hiển thị trên slide...">
            </div>

            <div class="mb-3">
                <label for="description" class="form-label text-white-50">Mô tả chương trình quảng cáo</label>
                <textarea class="form-control form-control-dark" id="description" name="description" rows="3" placeholder="Nhập đoạn mô tả ngắn hiển thị trên banner..."></textarea>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <label for="image" class="form-label text-white-50">Video Trailer của Banner (Tùy chọn, MP4/WebM)</label>
                    <input type="file" class="form-control form-control-dark" id="image" name="image" accept="video/mp4,video/webm,video/ogg">
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Tải lên tệp video phát dưới nền banner trang chủ. Nếu để trống, sẽ hiển thị poster phim.</small>
                    <div class="input-group mt-2" style="max-width: 260px;">
                        <span class="input-group-text bg-dark border-secondary text-white-50" style="font-size:12px;"><i class="fa-solid fa-scissors me-1"></i> Cắt cuối video</span>
                        <input type="number" class="form-control form-control-dark" name="trim_seconds" value="3" min="0" max="30" style="max-width:70px;">
                        <span class="input-group-text bg-dark border-secondary text-white-50" style="font-size:12px;">giây</span>
                    </div>
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Tự động cắt bỏ N giây cuối (logo TikTok). Đặt 0 để không cắt.</small>
                </div>
                <div class="col-md-6 mb-4">
                    <label for="sort_order" class="form-label text-white-50">Thứ tự hiển thị (Sort Order)</label>
                    <input type="number" class="form-control form-control-dark" id="sort_order" name="sort_order" value="0">
                </div>
            </div>

            <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Thêm Banner</button>
        </form>
    </div>

<?php elseif ($action === 'edit'):
    $bannerId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $banner = $bannerModel->getById($bannerId);
    if (!$banner) {
        header('Location: banners.php');
        exit;
    }
?>
    <!-- EDIT BANNER FORM -->
    <div class="admin-card text-white">
        <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-pen-to-square me-2"></i>Sửa Thông Tin Banner</h4>
        <form action="banners.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" value="<?php echo $banner['id']; ?>">
            
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="movie_title_input" class="form-label text-white-50">Liên kết tới phim (Nhập tên phim) *</label>
                    <?php
                        $current_movie_title = '';
                        $current_trailer_url = '';
                        foreach ($movies as $movie) {
                            if ($banner['movie_id'] == $movie['id']) {
                                $current_movie_title = $movie['title'];
                                $current_trailer_url = $movie['trailer_url'];
                                break;
                            }
                        }
                    ?>
                    <input type="text" class="form-control form-control-dark" id="movie_title_input" name="movie_title" value="<?php echo htmlspecialchars($current_movie_title); ?>" list="movies_list" placeholder="Gõ tên phim để tìm kiếm..." required autocomplete="off">
                    <input type="hidden" name="movie_id" id="movie_id" value="<?php echo $banner['movie_id']; ?>">
                    <datalist id="movies_list">
                        <?php foreach ($movies as $movie): ?>
                            <option data-value="<?php echo $movie['id']; ?>" value="<?php echo htmlspecialchars($movie['title']); ?>"></option>
                        <?php endforeach; ?>
                    </datalist>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="subtitle" class="form-label text-white-50">Nhãn phụ (Badge / Subtitle) *</label>
                    <input type="text" class="form-control form-control-dark" id="subtitle" name="subtitle" value="<?php echo htmlspecialchars($banner['subtitle']); ?>" required>
                </div>
            </div>

            <div class="mb-3">
                <label for="title" class="form-label text-white-50">Tiêu đề chính trên Banner *</label>
                <input type="text" class="form-control form-control-dark" id="title" name="title" value="<?php echo htmlspecialchars($banner['title']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label text-white-50">Mô tả chương trình quảng cáo</label>
                <textarea class="form-control form-control-dark" id="description" name="description" rows="3"><?php echo htmlspecialchars($banner['description']); ?></textarea>
            </div>

            <div class="row">
                <div class="col-md-6 mb-4">
                    <label for="image" class="form-label text-white-50">Video Trailer mới (Tùy chọn, MP4/WebM)</label>
                    <input type="file" class="form-control form-control-dark" id="image" name="image" accept="video/mp4,video/webm,video/ogg">
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Để trống để giữ nguyên video/hình ảnh hiện tại.</small>
                    <div class="input-group mt-2" style="max-width: 260px;">
                        <span class="input-group-text bg-dark border-secondary text-white-50" style="font-size:12px;"><i class="fa-solid fa-scissors me-1"></i> Cắt cuối video</span>
                        <input type="number" class="form-control form-control-dark" name="trim_seconds" value="<?php echo isset($banner['trim_seconds']) ? htmlspecialchars($banner['trim_seconds']) : 3; ?>" min="0" max="30" style="max-width:70px;">
                        <span class="input-group-text bg-dark border-secondary text-white-50" style="font-size:12px;">giây</span>
                    </div>
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Tự động cắt bỏ N giây cuối (logo TikTok). Đặt 0 để không cắt.</small>
                </div>
                <div class="col-md-6 mb-4">
                    <label for="sort_order" class="form-label text-white-50">Thứ tự hiển thị (Sort Order)</label>
                    <input type="number" class="form-control form-control-dark" id="sort_order" name="sort_order" value="<?php echo $banner['sort_order']; ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Cập nhật Banner</button>
        </form>
    </div>

<?php else: ?>
    <!-- BANNERS TABLE VIEW -->
    <div class="admin-card">
        <?php if (empty($banners)): ?>
            <p class="text-white-50 text-center py-4">Không tìm thấy banner quảng cáo nào.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table admin-table m-0">
                    <thead>
                        <tr>
                            <th>Hình ảnh</th>
                            <th>Phim liên kết</th>
                            <th>Nhãn phụ</th>
                            <th>Tiêu đề banner</th>
                            <th>Thứ tự</th>
                            <th class="text-end">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($banners as $item): ?>
                            <tr>
                                <td>
                                    <div class="rounded overflow-hidden border border-secondary" style="width: 80px; aspect-ratio: 16/9; background: #000; display: flex; align-items: center; justify-content: center;">
                                        <?php 
                                            $ext = strtolower(pathinfo($item['image'], PATHINFO_EXTENSION));
                                            $is_video = in_array($ext, ['mp4', 'webm', 'ogg']);
                                            if ($is_video):
                                                $video_src = '../assets/videos/' . $item['image'];
                                                $video_full_path = __DIR__ . '/' . $video_src;
                                                if (file_exists($video_full_path)) {
                                                    $video_src .= '?v=' . filemtime($video_full_path);
                                                }
                                        ?>
                                            <video src="<?php echo $video_src; ?>" class="w-100 h-100" style="object-fit: cover;" muted autoplay loop playsinline></video>
                                        <?php else: 
                                                $banner_src = '../assets/images/' . $item['image'];
                                        ?>
                                            <img src="<?php echo $banner_src; ?>" alt="" class="w-100 h-100" style="object-fit: cover;">
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td><strong class="text-white"><?php echo htmlspecialchars($item['movie_title']); ?></strong></td>
                                <td><span class="badge bg-purple" style="background-color: var(--accent-purple) !important;"><?php echo htmlspecialchars($item['subtitle']); ?></span></td>
                                <td class="text-white-50"><?php echo htmlspecialchars($item['title']); ?></td>
                                <td class="text-warning fw-bold"><?php echo $item['sort_order']; ?></td>
                                <td class="text-end">
                                    <a href="banners.php?action=edit&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-info me-1" title="Sửa"><i class="fa-solid fa-pen-to-square"></i> Sửa</a>
                                    <a href="banners.php?action=delete&id=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa banner này?')" title="Xóa"><i class="fa-solid fa-trash"></i> Xóa</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    var titleInput = document.getElementById('movie_title_input');
    var idInput = document.getElementById('movie_id');
    var datalist = document.getElementById('movies_list');
    
    if (titleInput && datalist) {
        titleInput.addEventListener('input', function() {
            var val = this.value;
            var matchedId = "";
            var options = datalist.querySelectorAll('option');
            for (var i = 0; i < options.length; i++) {
                if (options[i].value === val) {
                    matchedId = options[i].getAttribute('data-value');
                    break;
                }
            }
            idInput.value = matchedId;
            
            // Clear validity warning if input changes
            titleInput.setCustomValidity("");
        });
        
        // Also validate on form submit or blur that it matches an option (with fuzzy/partial matching support)
        titleInput.addEventListener('change', function() {
            var val = this.value.trim();
            var matched = false;
            var matchedTitle = "";
            var matchedId = "";
            var options = datalist.querySelectorAll('option');
            
            // First pass: exact match (case insensitive)
            for (var i = 0; i < options.length; i++) {
                if (options[i].value.toLowerCase() === val.toLowerCase()) {
                    matched = true;
                    matchedTitle = options[i].value;
                    matchedId = options[i].getAttribute('data-value');
                    break;
                }
            }
            
            // Second pass: if no exact match, try fuzzy match (containment)
            if (!matched && val !== '') {
                for (var i = 0; i < options.length; i++) {
                    var optionVal = options[i].value.toLowerCase();
                    var inputVal = val.toLowerCase();
                    if (inputVal.indexOf(optionVal) !== -1 || optionVal.indexOf(inputVal) !== -1) {
                        matched = true;
                        matchedTitle = options[i].value;
                        matchedId = options[i].getAttribute('data-value');
                        break;
                    }
                }
            }
            
            if (matched) {
                this.value = matchedTitle; // Auto-correct to registered title
                idInput.value = matchedId;
                titleInput.setCustomValidity("");
            } else if (val !== '') {
                titleInput.setCustomValidity("Tên phim không tồn tại trong danh sách. Vui lòng chọn một phim có sẵn!");
                titleInput.reportValidity();
            } else {
                titleInput.setCustomValidity("");
            }
        });
    }
});
</script>

<?php
require_once __DIR__ . '/footer.php';
?>
