            </div> <!-- End Main Content Area Column -->
        </div> <!-- End Admin Content Layout Row -->
    </div> <!-- End Admin Content Layout Container -->

    <!-- jQuery & Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
