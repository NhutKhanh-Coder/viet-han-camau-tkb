<?php
require_once __DIR__ . '/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';
$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';

// 1. DELETE ACTION
if ($action === 'delete') {
    $movieId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($movieId > 0) {
        if ($movieModel->delete($movieId)) {
            $_SESSION['success'] = "Xóa phim thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra khi xóa phim!";
        }
    }
    header('Location: movies.php');
    exit;
}

// 2. CREATE / UPDATE POST SUBMISSIONS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = isset($_POST['action']) ? $_POST['action'] : '';
    
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $duration = intval($_POST['duration']);
    $release_date = $_POST['release_date'];
    $rating = $_POST['rating'];
    $status = $_POST['status'];
    $trailer_url = trim($_POST['trailer_url']);

    // Ensure upload dir exists
    $uploadDir = __DIR__ . '/../assets/images/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $imageName = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['image']['tmp_name'];
        $fileName = $_FILES['image']['name'];
        $fileExtension = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        
        $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        if (in_array($fileExtension, $allowedExtensions)) {
            $newFileName = time() . '_' . preg_replace("/[^a-zA-Z0-9.]/", "_", $fileName);
            $dest_path = $uploadDir . $newFileName;
            
            if (move_uploaded_file($fileTmpPath, $dest_path)) {
                $imageName = $newFileName;
            }
        }
    }

    if ($postAction === 'add') {
        if (empty($title) || empty($duration) || empty($release_date)) {
            $_SESSION['error'] = "Vui lòng điền đầy đủ tiêu đề, thời lượng và ngày khởi chiếu!";
        } else {
            // Fallback image handling
            $img = !empty($imageName) ? $imageName : '';
            $success = $movieModel->create($title, $description, $img, $duration, $release_date, $rating, $status, $trailer_url);
            if ($success) {
                $_SESSION['success'] = "Thêm phim mới thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi thêm phim!";
            }
        }
    } elseif ($postAction === 'edit') {
        $id = intval($_POST['id']);
        if ($id > 0) {
            // If new image uploaded, fetch old image to delete it
            if (!empty($imageName)) {
                $old_movie = $movieModel->getById($id);
                if ($old_movie && !empty($old_movie['image'])) {
                    $old_image_path = $uploadDir . $old_movie['image'];
                    if (file_exists($old_image_path) && is_file($old_image_path)) {
                        @unlink($old_image_path);
                    }
                }
            }
            
            $success = $movieModel->update($id, $title, $description, $imageName, $duration, $release_date, $rating, $status, $trailer_url);
            if ($success) {
                $_SESSION['success'] = "Cập nhật thông tin phim thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi cập nhật phim!";
            }
        }
    }
    
    header('Location: movies.php');
    exit;
}

// 3. RENDER VIEWS
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Phim</h2>
        <p class="text-white-50">Thêm, sửa, xóa thông tin phim chiếu rạp</p>
    </div>
    <div class="col-md-6 text-md-end">
        <?php if (empty($action)): ?>
            <a href="movies.php?action=add" class="btn btn-yellow text-uppercase fw-bold"><i class="fa-solid fa-circle-plus me-1"></i>Thêm Phim Mới</a>
        <?php else: ?>
            <a href="movies.php" class="btn btn-outline-warning text-uppercase fw-bold"><i class="fa-solid fa-arrow-left-long me-1"></i>Quay lại danh sách</a>
        <?php endif; ?>
    </div>
</div>

<?php if ($action === 'add'): ?>
    <!-- ADD MOVIE FORM -->
    <div class="admin-card text-white">
        <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-film me-2"></i>Thêm Phim Mới</h4>
        <form action="movies.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="add">
            
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label for="title" class="form-label text-white-50">Tên phim</label>
                    <input type="text" class="form-control form-control-dark" id="title" name="title" required placeholder="Nhập tên phim...">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="rating" class="form-label text-white-50">Phân loại độ tuổi (Rating)</label>
                    <select class="form-select form-control-dark" id="rating" name="rating">
                        <option value="P">P - Mọi độ tuổi</option>
                        <option value="T13">T13 - Cấm dưới 13 tuổi</option>
                        <option value="T16">T16 - Cấm dưới 16 tuổi</option>
                        <option value="T18">T18 - Cấm dưới 18 tuổi</option>
                        <option value="CHƯA PHÂN LOẠI">CHƯA PHÂN LOẠI</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label text-white-50">Tóm tắt nội dung</label>
                <textarea class="form-control form-control-dark" id="description" name="description" rows="5" placeholder="Tóm tắt phim..."></textarea>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="duration" class="form-label text-white-50">Thời lượng (phút)</label>
                    <input type="number" class="form-control form-control-dark" id="duration" name="duration" required min="1" placeholder="Ví dụ: 120">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="release_date" class="form-label text-white-50">Ngày khởi chiếu</label>
                    <input type="date" class="form-control form-control-dark" id="release_date" name="release_date" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="status" class="form-label text-white-50">Trạng thái phát hành</label>
                    <select class="form-select form-control-dark" id="status" name="status">
                        <option value="showing">Đang chiếu</option>
                        <option value="coming">Sắp chiếu</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="image" class="form-label text-white-50">Ảnh bìa Poster</label>
                    <input type="file" class="form-control form-control-dark" id="image" name="image" accept="image/*">
                    <small class="text-white-50" style="font-size: 11px;">Hỗ trợ định dạng: JPG, PNG, WEBP</small>
                </div>
                <div class="col-md-6 mb-4">
                    <label for="trailer_url" class="form-label text-white-50">Trailer Link (Youtube Embed URL)</label>
                    <input type="url" class="form-control form-control-dark" id="trailer_url" name="trailer_url" placeholder="Ví dụ: https://www.youtube.com/embed/dQw4w9WgXcQ">
                    <small class="text-white-50" style="font-size: 11px;">Đảm bảo link sử dụng đường dẫn nhúng /embed/</small>
                </div>
            </div>

            <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Thêm Phim</button>
        </form>
    </div>

<?php elseif ($action === 'edit'): 
    $movieId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    $movie = $movieModel->getById($movieId);
    if (!$movie) {
        header('Location: movies.php');
        exit;
    }
?>
    <!-- EDIT MOVIE FORM -->
    <div class="admin-card text-white">
        <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-pen-to-square me-2"></i>Sửa Thông Tin Phim</h4>
        <form action="movies.php" method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="edit">
            <input type="hidden" name="id" value="<?php echo $movie['id']; ?>">
            
            <div class="row">
                <div class="col-md-8 mb-3">
                    <label for="title" class="form-label text-white-50">Tên phim</label>
                    <input type="text" class="form-control form-control-dark" id="title" name="title" value="<?php echo htmlspecialchars($movie['title']); ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="rating" class="form-label text-white-50">Phân loại độ tuổi (Rating)</label>
                    <select class="form-select form-control-dark" id="rating" name="rating">
                        <option value="P" <?php echo $movie['rating'] === 'P' ? 'selected' : ''; ?>>P - Mọi độ tuổi</option>
                        <option value="T13" <?php echo $movie['rating'] === 'T13' ? 'selected' : ''; ?>>T13 - Cấm dưới 13 tuổi</option>
                        <option value="T16" <?php echo $movie['rating'] === 'T16' ? 'selected' : ''; ?>>T16 - Cấm dưới 16 tuổi</option>
                        <option value="T18" <?php echo $movie['rating'] === 'T18' ? 'selected' : ''; ?>>T18 - Cấm dưới 18 tuổi</option>
                        <option value="CHƯA PHÂN LOẠI" <?php echo $movie['rating'] === 'CHƯA PHÂN LOẠI' ? 'selected' : ''; ?>>CHƯA PHÂN LOẠI</option>
                    </select>
                </div>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label text-white-50">Tóm tắt nội dung</label>
                <textarea class="form-control form-control-dark" id="description" name="description" rows="5"><?php echo htmlspecialchars($movie['description']); ?></textarea>
            </div>

            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="duration" class="form-label text-white-50">Thời lượng (phút)</label>
                    <input type="number" class="form-control form-control-dark" id="duration" name="duration" value="<?php echo $movie['duration']; ?>" required min="1">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="release_date" class="form-label text-white-50">Ngày khởi chiếu</label>
                    <input type="date" class="form-control form-control-dark" id="release_date" name="release_date" value="<?php echo $movie['release_date']; ?>" required>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="status" class="form-label text-white-50">Trạng thái phát hành</label>
                    <select class="form-select form-control-dark" id="status" name="status">
                        <option value="showing" <?php echo $movie['status'] === 'showing' ? 'selected' : ''; ?>>Đang chiếu</option>
                        <option value="coming" <?php echo $movie['status'] === 'coming' ? 'selected' : ''; ?>>Sắp chiếu</option>
                    </select>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="image" class="form-label text-white-50">Ảnh bìa Poster mới</label>
                    <input type="file" class="form-control form-control-dark" id="image" name="image" accept="image/*">
                    <small class="text-white-50 d-block mt-1" style="font-size: 11px;">Để trống nếu giữ nguyên poster hiện tại</small>
                </div>
                <div class="col-md-6 mb-4">
                    <label for="trailer_url" class="form-label text-white-50">Trailer Link (Youtube Embed URL)</label>
                    <input type="url" class="form-control form-control-dark" id="trailer_url" name="trailer_url" value="<?php echo htmlspecialchars($movie['trailer_url']); ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Cập nhật phim</button>
        </form>
    </div>

<?php else: 
    // MOVIE LIST VIEW
    if (!empty($search_query)) {
        $movies = $movieModel->search($search_query);
    } else {
        $movies = $movieModel->getAll();
    }
?>
    <!-- SEARCH & TABLE VIEW -->
    <div class="admin-card">
        <div class="row mb-3">
            <div class="col-md-6">
                <form action="movies.php" method="GET" class="d-flex m-0">
                    <input type="text" name="search" class="form-control form-control-dark me-2" placeholder="Tìm kiếm tên phim..." value="<?php echo htmlspecialchars($search_query); ?>">
                    <button type="submit" class="btn btn-purple"><i class="fa-solid fa-magnifying-glass"></i></button>
                </form>
            </div>
        </div>

        <?php if (empty($movies)): ?>
            <p class="text-white-50 text-center py-4">Không tìm thấy thông tin phim nào.</p>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table admin-table m-0">
                    <thead>
                        <tr>
                            <th>Ảnh</th>
                            <th>Tên phim</th>
                            <th>Thời lượng</th>
                            <th>Khởi chiếu</th>
                            <th>Rating</th>
                            <th>Trạng thái</th>
                            <th class="text-end">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($movies as $movie): ?>
                            <tr>
                                <td>
                                    <div class="rounded overflow-hidden border border-secondary" style="width: 45px; aspect-ratio: 2/3;">
                                        <!-- Need a helper poster loader because we are inside /admin/ so assets paths relative to /admin/ need a fallback too! -->
                                        <?php 
                                            // Since we are inside the /admin/ folder, the assets folder is at ../assets/
                                            $poster_src = getMoviePosterUrl($movie['image'], $movie['title']);
                                            $poster_src = str_replace('assets/images/', '../assets/images/', $poster_src);
                                        ?>
                                        <img src="<?php echo $poster_src; ?>" alt="" class="w-100 h-100" style="object-fit: cover;">
                                    </div>
                                </td>
                                <td><strong class="text-white"><?php echo htmlspecialchars($movie['title']); ?></strong></td>
                                <td><?php echo $movie['duration']; ?> phút</td>
                                <td><?php echo date('d/m/Y', strtotime($movie['release_date'])); ?></td>
                                <td><span class="badge bg-secondary"><?php echo htmlspecialchars($movie['rating']); ?></span></td>
                                <td>
                                    <?php if ($movie['status'] === 'showing'): ?>
                                        <span class="badge bg-success">Đang Chiếu</span>
                                    <?php else: ?>
                                        <span class="badge bg-info">Sắp Chiếu</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-end">
                                    <a href="movies.php?action=edit&id=<?php echo $movie['id']; ?>" class="btn btn-sm btn-outline-info me-1" title="Sửa"><i class="fa-solid fa-pen-to-square"></i> Sửa</a>
                                    <a href="movies.php?action=delete&id=<?php echo $movie['id']; ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Bạn có chắc chắn muốn xóa phim này và tất cả các lịch chiếu đi kèm?')" title="Xóa"><i class="fa-solid fa-trash"></i> Xóa</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>

<?php
require_once __DIR__ . '/footer.php';
?>
