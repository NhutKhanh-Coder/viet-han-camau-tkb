<?php
require_once __DIR__ . '/header.php';

// ── Revenue last 7 days (line chart) ──────────────────────────────────────────
$revenueByDay = [];
for ($i = 6; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $label = date('d/m', strtotime("-$i days"));
    $stmt = $db->prepare("SELECT IFNULL(SUM(total_price),0) FROM bookings WHERE DATE(booking_date)=:d");
    $stmt->execute([':d' => $date]);
    $revenueByDay[$label] = (float) $stmt->fetchColumn();
}

// ── Top 5 phim doanh thu (bar chart) ──────────────────────────────────────────
$topMovies = $db->query("
    SELECT m.title, COUNT(b.id) AS ticket_count, IFNULL(SUM(b.total_price),0) AS revenue
    FROM bookings b
    JOIN showtimes s ON b.showtime_id = s.id
    JOIN movies m    ON s.movie_id = m.id
    GROUP BY m.id, m.title
    ORDER BY revenue DESC
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

// ── Doanh thu theo rạp (doughnut chart) ───────────────────────────────────────
$revenueByCinema = $db->query("
    SELECT c.name, IFNULL(SUM(b.total_price),0) AS revenue
    FROM bookings b
    JOIN showtimes s ON b.showtime_id = s.id
    JOIN cinemas c   ON s.cinema_id = c.id
    GROUP BY c.id, c.name
    ORDER BY revenue DESC
")->fetchAll(PDO::FETCH_ASSOC);

// ── Booking count by hour (activity heatmap – simple bar) ─────────────────────
$bookingByHour = [];
for ($h = 0; $h <= 23; $h++) {
    $stmt = $db->prepare("SELECT COUNT(*) FROM bookings WHERE HOUR(booking_date)=:h");
    $stmt->execute([':h' => $h]);
    $bookingByHour[$h] = (int) $stmt->fetchColumn();
}

// ── Summary stats ─────────────────────────────────────────────────────────────
$totalRevenue   = $db->query("SELECT IFNULL(SUM(total_price),0) FROM bookings")->fetchColumn();
$totalBookings  = $db->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$avgTicketValue = $totalBookings > 0 ? $totalRevenue / $totalBookings : 0;
$totalMovies    = $db->query("SELECT COUNT(*) FROM movies")->fetchColumn();

// JSON for Chart.js
$dayLabels      = json_encode(array_keys($revenueByDay));
$dayData        = json_encode(array_values($revenueByDay));
$movieLabels    = json_encode(array_column($topMovies, 'title'));
$movieRevData   = json_encode(array_column($topMovies, 'revenue'));
$movieTickData  = json_encode(array_column($topMovies, 'ticket_count'));
$cinemaLabels   = json_encode(array_column($revenueByCinema, 'name'));
$cinemaData     = json_encode(array_column($revenueByCinema, 'revenue'));
$hourLabels     = json_encode(array_keys($bookingByHour));
$hourData       = json_encode(array_values($bookingByHour));
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="text-white fw-extrabold text-uppercase">Báo cáo & Thống kê</h2>
        <p class="text-white-50">Phân tích doanh thu, tình hình bán vé và hiệu suất hệ thống rạp</p>
    </div>
</div>

<!-- Summary Stats -->
<div class="row mb-4">
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size:12px;">Tổng doanh thu</div>
                <div class="fs-4 fw-extrabold text-success mt-1"><?php echo number_format($totalRevenue,0,',','.'); ?> đ</div>
            </div>
            <i class="fa-solid fa-sack-dollar fs-2 text-success opacity-25"></i>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size:12px;">Tổng giao dịch</div>
                <div class="fs-4 fw-extrabold text-warning mt-1"><?php echo number_format($totalBookings); ?></div>
            </div>
            <i class="fa-solid fa-ticket fs-2 text-warning opacity-25"></i>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size:12px;">Giá trị trung bình / vé</div>
                <div class="fs-4 fw-extrabold text-info mt-1"><?php echo number_format($avgTicketValue,0,',','.'); ?> đ</div>
            </div>
            <i class="fa-solid fa-chart-line fs-2 text-info opacity-25"></i>
        </div>
    </div>
    <div class="col-md-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-3 px-4">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size:12px;">Số phim đang quản lý</div>
                <div class="fs-4 fw-extrabold mt-1" style="color:var(--accent-purple);"><?php echo $totalMovies; ?></div>
            </div>
            <i class="fa-solid fa-film fs-2 opacity-25" style="color:var(--accent-purple);"></i>
        </div>
    </div>
</div>

<!-- Charts Row 1 -->
<div class="row mb-4">
    <!-- Line Chart: Revenue 7 days -->
    <div class="col-lg-8 mb-4">
        <div class="admin-card" style="height:360px;">
            <h5 class="text-warning fw-bold mb-3"><i class="fa-solid fa-arrow-trend-up me-2"></i>Doanh thu 7 ngày gần đây</h5>
            <canvas id="lineChart" style="max-height:280px;"></canvas>
        </div>
    </div>
    <!-- Doughnut Chart: Revenue by Cinema -->
    <div class="col-lg-4 mb-4">
        <div class="admin-card" style="height:360px;">
            <h5 class="text-warning fw-bold mb-3"><i class="fa-solid fa-circle-half-stroke me-2"></i>Doanh thu theo rạp</h5>
            <?php if (empty($revenueBycinema) && count($revenueByCinema) === 0): ?>
                <p class="text-white-50 text-center pt-5">Chưa có dữ liệu.</p>
            <?php else: ?>
                <canvas id="doughnutChart" style="max-height:280px;"></canvas>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Charts Row 2 -->
<div class="row mb-4">
    <!-- Bar Chart: Top 5 Movies -->
    <div class="col-lg-7 mb-4">
        <div class="admin-card" style="height:360px;">
            <h5 class="text-warning fw-bold mb-3"><i class="fa-solid fa-trophy me-2"></i>Top 5 phim doanh thu cao nhất</h5>
            <?php if (empty($topMovies)): ?>
                <p class="text-white-50 text-center pt-5">Chưa có dữ liệu đặt vé.</p>
            <?php else: ?>
                <canvas id="barChart" style="max-height:280px;"></canvas>
            <?php endif; ?>
        </div>
    </div>
    <!-- Booking by Hour -->
    <div class="col-lg-5 mb-4">
        <div class="admin-card" style="height:360px;">
            <h5 class="text-warning fw-bold mb-3"><i class="fa-solid fa-clock me-2"></i>Giờ đặt vé cao điểm</h5>
            <canvas id="hourChart" style="max-height:280px;"></canvas>
        </div>
    </div>
</div>

<!-- Top Movies Table -->
<?php if (!empty($topMovies)): ?>
<div class="admin-card">
    <h5 class="text-warning fw-bold mb-3"><i class="fa-solid fa-ranking-star me-2"></i>Bảng xếp hạng phim bán chạy</h5>
    <div class="table-responsive">
        <table class="table admin-table m-0">
            <thead>
                <tr>
                    <th style="width:50px">Hạng</th>
                    <th>Tên phim</th>
                    <th class="text-center">Số vé bán</th>
                    <th class="text-end">Doanh thu</th>
                    <th>Tỷ lệ</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $medals = ['🥇','🥈','🥉','4️⃣','5️⃣'];
                foreach ($topMovies as $i => $m):
                    $pct = $totalRevenue > 0 ? round($m['revenue'] / $totalRevenue * 100, 1) : 0;
                ?>
                <tr>
                    <td class="text-center fs-5"><?php echo $medals[$i] ?? ($i+1); ?></td>
                    <td><strong class="text-white"><?php echo htmlspecialchars($m['title']); ?></strong></td>
                    <td class="text-center">
                        <span class="badge bg-info"><?php echo number_format($m['ticket_count']); ?> vé</span>
                    </td>
                    <td class="text-end text-success fw-extrabold">
                        <?php echo number_format($m['revenue'],0,',','.'); ?> đ
                    </td>
                    <td style="min-width:130px;">
                        <div class="d-flex align-items-center gap-2">
                            <div class="progress flex-grow-1" style="height:6px;background:rgba(255,255,255,0.1);">
                                <div class="progress-bar bg-warning" style="width:<?php echo $pct; ?>%"></div>
                            </div>
                            <small class="text-white-50"><?php echo $pct; ?>%</small>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
Chart.defaults.color = 'rgba(255,255,255,0.55)';
Chart.defaults.borderColor = 'rgba(255,255,255,0.06)';

const purple = '#7c3aed', yellow = '#facc15', cyan = '#22d3ee',
      green  = '#22c55e', pink   = '#f472b6', orange = '#fb923c',
      teal   = '#14b8a6', red    = '#f87171';

// 1. Line Chart – Revenue 7 days
new Chart(document.getElementById('lineChart'), {
    type: 'line',
    data: {
        labels: <?php echo $dayLabels; ?>,
        datasets: [{
            label: 'Doanh thu (đ)',
            data: <?php echo $dayData; ?>,
            borderColor: yellow,
            backgroundColor: 'rgba(250,204,21,0.12)',
            borderWidth: 3,
            pointBackgroundColor: yellow,
            pointRadius: 5,
            fill: true,
            tension: 0.4
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: {
                ticks: { callback: v => (v/1000).toFixed(0) + 'K đ' },
                grid: { color: 'rgba(255,255,255,0.05)' }
            },
            x: { grid: { display: false } }
        }
    }
});

// 2. Doughnut Chart – Revenue by Cinema
const cinemaColors = [purple, yellow, cyan, green, pink, orange];
new Chart(document.getElementById('doughnutChart'), {
    type: 'doughnut',
    data: {
        labels: <?php echo $cinemaLabels; ?>,
        datasets: [{
            data: <?php echo $cinemaData; ?>,
            backgroundColor: cinemaColors,
            borderColor: '#121824',
            borderWidth: 3,
            hoverOffset: 8
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
            legend: { position: 'bottom', labels: { boxWidth: 12, padding: 10 } },
            tooltip: {
                callbacks: {
                    label: ctx => ' ' + ctx.label + ': ' + Number(ctx.raw).toLocaleString('vi-VN') + ' đ'
                }
            }
        }
    }
});

// 3. Bar Chart – Top 5 movies
<?php if (!empty($topMovies)): ?>
new Chart(document.getElementById('barChart'), {
    type: 'bar',
    data: {
        labels: <?php echo $movieLabels; ?>,
        datasets: [{
            label: 'Doanh thu (đ)',
            data: <?php echo $movieRevData; ?>,
            backgroundColor: [purple, yellow, cyan, green, pink],
            borderRadius: 6,
            borderSkipped: false
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false },
            tooltip: {
                callbacks: {
                    label: ctx => ' ' + Number(ctx.raw).toLocaleString('vi-VN') + ' đ'
                }
            }
        },
        scales: {
            y: {
                ticks: { callback: v => (v/1000).toFixed(0) + 'K đ' },
                grid: { color: 'rgba(255,255,255,0.05)' }
            },
            x: { grid: { display: false }, ticks: {
                callback: function(val) {
                    const label = this.getLabelForValue(val);
                    return label.length > 15 ? label.substring(0,15) + '…' : label;
                }
            }}
        }
    }
});
<?php endif; ?>

// 4. Bar Chart – Booking by hour
new Chart(document.getElementById('hourChart'), {
    type: 'bar',
    data: {
        labels: <?php echo $hourLabels; ?>.map(h => h + 'h'),
        datasets: [{
            label: 'Số đặt vé',
            data: <?php echo $hourData; ?>,
            backgroundColor: 'rgba(34,211,238,0.7)',
            borderRadius: 4,
            borderSkipped: false
        }]
    },
    options: {
        responsive: true, maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
            y: { grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { stepSize: 1 } },
            x: { grid: { display: false } }
        }
    }
});
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
