<?php
require_once __DIR__ . '/header.php';

// Fetch stats
$moviesCount = $db->query("SELECT COUNT(*) FROM movies")->fetchColumn();
$usersCount = $db->query("SELECT COUNT(*) FROM users")->fetchColumn();
$bookingsCount = $db->query("SELECT COUNT(*) FROM bookings")->fetchColumn();
$totalRevenue = $db->query("SELECT SUM(total_price) FROM bookings")->fetchColumn();
$totalRevenue = $totalRevenue ? $totalRevenue : 0;

// Daily revenue for last 7 days
$dailyRevenueQuery = $db->query("
    SELECT DATE(booking_date) as date, SUM(total_price) as revenue 
    FROM bookings 
    WHERE booking_date >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
    GROUP BY DATE(booking_date) 
    ORDER BY DATE(booking_date) ASC
")->fetchAll(PDO::FETCH_ASSOC);

$dailyDates = [];
$dailyValues = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $dailyDates[] = date('d/m', strtotime($d));
    $val = 0;
    foreach ($dailyRevenueQuery as $row) {
        if ($row['date'] === $d) {
            $val = floatval($row['revenue']);
            break;
        }
    }
    $dailyValues[] = $val;
}

// Top movies by revenue
$movieRevenueQuery = $db->query("
    SELECT m.title, SUM(b.total_price) as revenue 
    FROM bookings b 
    JOIN showtimes s ON b.showtime_id = s.id 
    JOIN movies m ON s.movie_id = m.id 
    GROUP BY m.id 
    ORDER BY revenue DESC 
    LIMIT 5
")->fetchAll(PDO::FETCH_ASSOC);

$movieTitles = [];
$movieRevenues = [];
foreach ($movieRevenueQuery as $row) {
    $movieTitles[] = $row['title'];
    $movieRevenues[] = floatval($row['revenue']);
}

// Fetch last 5 bookings
$recentBookings = $db->query("SELECT b.*, u.fullname, s.show_date, s.show_time, m.title as movie_title, c.name as cinema_name 
                              FROM bookings b
                              JOIN users u ON b.user_id = u.id
                              JOIN showtimes s ON b.showtime_id = s.id
                              JOIN movies m ON s.movie_id = m.id
                              JOIN cinemas c ON s.cinema_id = c.id
                              ORDER BY b.booking_date DESC 
                              LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="row mb-4">
    <div class="col-12">
        <h2 class="text-white fw-extrabold text-uppercase">Bảng Điều Khiển</h2>
        <p class="text-white-50">Tổng quan tình hình kinh doanh và quản lý hệ thống rạp phim</p>
    </div>
</div>

<!-- Stats Widgets Grid -->
<div class="row mb-5">
    <div class="col-sm-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-4 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Tổng Số Phim</div>
                <div class="fs-2 fw-extrabold text-warning mt-2"><?php echo $moviesCount; ?></div>
            </div>
            <i class="fa-solid fa-film text-warning-50 fs-1 opacity-25"></i>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-4 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Thành Viên</div>
                <div class="fs-2 fw-extrabold text-info mt-2"><?php echo $usersCount; ?></div>
            </div>
            <i class="fa-solid fa-users text-info-50 fs-1 opacity-25"></i>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-4 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Vé Đã Bán</div>
                <div class="fs-2 fw-extrabold text-purple mt-2" style="color: var(--accent-purple);"><?php echo $bookingsCount; ?></div>
            </div>
            <i class="fa-solid fa-ticket text-purple-50 fs-1 opacity-25"></i>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3 mb-3">
        <div class="admin-card d-flex align-items-center justify-content-between py-4 px-4 bg-secondary">
            <div>
                <div class="text-white-50 text-uppercase fw-semibold" style="font-size: 13px;">Doanh Thu</div>
                <div class="fs-2 fw-extrabold text-success mt-2"><?php echo number_format($totalRevenue, 0, ',', '.'); ?> đ</div>
            </div>
            <i class="fa-solid fa-hand-holding-dollar text-success-50 fs-1 opacity-25"></i>
        </div>
    </div>
</div>

<!-- Chart.js CDN -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Business Analytics Charts Section -->
<div class="row mb-5">
    <div class="col-lg-8 mb-4 mb-lg-0">
        <div class="admin-card h-100">
            <h5 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-chart-line me-2"></i>Doanh thu 7 ngày gần nhất (VNĐ)</h5>
            <div style="position: relative; height: 300px; width: 100%;">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="admin-card h-100">
            <h5 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-chart-pie me-2"></i>Tỷ lệ doanh thu phim</h5>
            <div style="position: relative; height: 300px; width: 100%;">
                <?php if (empty($movieTitles)): ?>
                    <div class="text-white-50 text-center py-5 d-flex align-items-center justify-content-center h-100">Chưa có dữ liệu đặt vé.</div>
                <?php else: ?>
                    <canvas id="movieChart"></canvas>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Recent Transactions Table -->
<div class="row">
    <div class="col-12">
        <div class="admin-card">
            <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-clock-rotate-left me-2"></i>Giao dịch đặt vé gần đây</h4>
            
            <?php if (empty($recentBookings)): ?>
                <p class="text-white-50 py-3 mb-0 text-center">Chưa có giao dịch đặt vé nào gần đây.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table admin-table m-0">
                        <thead>
                            <tr>
                                <th>Mã</th>
                                <th>Khách hàng</th>
                                <th>Phim</th>
                                <th>Rạp</th>
                                <th>Suất chiếu</th>
                                <th>Ghế</th>
                                <th>Bắp nước</th>
                                <th>Tổng tiền</th>
                                <th>Ngày đặt</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($recentBookings as $booking): ?>
                                <tr>
                                    <td><strong>#<?php echo $booking['id']; ?></strong></td>
                                    <td><?php echo htmlspecialchars($booking['fullname']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['movie_title']); ?></td>
                                    <td><?php echo htmlspecialchars($booking['cinema_name']); ?></td>
                                    <td>
                                        <span class="text-warning fw-semibold"><?php echo date('H:i', strtotime($booking['show_time'])); ?></span>
                                        <small class="text-white-50 ms-1"><?php echo date('d/m/Y', strtotime($booking['show_date'])); ?></small>
                                    </td>
                                    <td class="text-info fw-bold"><?php echo htmlspecialchars($booking['seats']); ?></td>
                                    <td style="font-size: 13px;"><?php echo !empty($booking['concessions']) ? htmlspecialchars($booking['concessions']) : '-'; ?></td>
                                    <td><span class="text-success fw-bold"><?php echo number_format($booking['total_price'], 0, ',', '.'); ?> đ</span></td>
                                    <td class="text-white-50" style="font-size: 13px;"><?php echo date('d/m/Y H:i', strtotime($booking['booking_date'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Chart 1: Revenue Line Chart
const ctxRevenue = document.getElementById('revenueChart').getContext('2d');
const gradient = ctxRevenue.createLinearGradient(0, 0, 0, 300);
gradient.addColorStop(0, 'rgba(245, 158, 11, 0.4)');
gradient.addColorStop(1, 'rgba(245, 158, 11, 0.0)');

new Chart(ctxRevenue, {
    type: 'line',
    data: {
        labels: <?php echo json_encode($dailyDates); ?>,
        datasets: [{
            label: 'Doanh thu',
            data: <?php echo json_encode($dailyValues); ?>,
            borderColor: '#f59e0b',
            borderWidth: 3,
            backgroundColor: gradient,
            fill: true,
            tension: 0.3,
            pointBackgroundColor: '#f59e0b',
            pointHoverRadius: 7
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: { display: false }
        },
        scales: {
            x: {
                grid: { color: 'rgba(255, 255, 255, 0.05)' },
                ticks: { color: '#94a3b8' }
            },
            y: {
                grid: { color: 'rgba(255, 255, 255, 0.05)' },
                ticks: {
                    color: '#94a3b8',
                    callback: function(value) {
                        return value.toLocaleString('vi-VN') + ' đ';
                    }
                }
            }
        }
    }
});

// Chart 2: Movie Doughnut Chart
const ctxMovie = document.getElementById('movieChart');
if (ctxMovie) {
    new Chart(ctxMovie, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($movieTitles); ?>,
            datasets: [{
                data: <?php echo json_encode($movieRevenues); ?>,
                backgroundColor: [
                    '#f59e0b', // Amber
                    '#7c3aed', // Purple
                    '#ef4444', // Red
                    '#06b6d4', // Cyan
                    '#10b981'  // Emerald
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#f8fafc',
                        font: { size: 11 },
                        padding: 10
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed !== null) {
                                label += context.parsed.toLocaleString('vi-VN') + ' đ';
                            }
                            return label;
                        }
                    }
                }
            }
        }
    });
}
</script>

<?php
require_once __DIR__ . '/footer.php';
?>
