<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Movie.php';
require_once __DIR__ . '/../models/Cinema.php';
require_once __DIR__ . '/../models/Showtime.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/Banner.php';
require_once __DIR__ . '/../models/Concession.php';

// Access control check
$database = new Database();
$db = $database->getConnection();
$userModel = new User($db);

if (!isset($_SESSION['user_id'])) {
    $_SESSION['error'] = "Vui lòng đăng nhập tài khoản quản trị!";
    header('Location: ../login.php');
    exit;
}

$currentUser = $userModel->getById($_SESSION['user_id']);
if (!$currentUser || $currentUser['role'] !== 'admin') {
    $_SESSION['error'] = "Tài khoản của bạn không có quyền truy cập trang quản trị!";
    header('Location: ../index.php');
    exit;
}

$movieModel = new Movie($db);
$cinemaModel = new Cinema($db);
$showtimeModel = new Showtime($db);
$bookingModel = new Booking($db);
$bannerModel = new Banner($db);
$concessionModel = new Concession($db);

// Fallback movie poster generator if local image is missing
function getMoviePosterUrl($image, $title = '') {
    $local_path = __DIR__ . '/../assets/images/' . $image;
    if (!empty($image) && file_exists($local_path) && is_file($local_path)) {
        return 'assets/images/' . $image;
    }
    
    // Choose gradient colors based on title hash
    $colors = [
        ['#1e1b4b', '#4338ca'], // Indigo dark to light
        ['#311042', '#7c3aed'], // Purple
        ['#450a0a', '#ef4444'], // Red
        ['#064e3b', '#10b981'], // Green
        ['#78350f', '#f59e0b'], // Amber
        ['#0f172a', '#334155'], // Slate
    ];
    $idx = abs(crc32($title)) % count($colors);
    $c1 = $colors[$idx][0];
    $c2 = $colors[$idx][1];
    
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 450" width="300" height="450">';
    $svg .= '<defs><linearGradient id="g'. $idx .'" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="'. $c1 .'"/><stop offset="100%" stop-color="'. $c2 .'"/></linearGradient></defs>';
    $svg .= '<rect width="100%" height="100%" fill="url(#g'. $idx .')"/>';
    
    // Play decoration
    $svg .= '<circle cx="150" cy="180" r="50" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="6"/>';
    $svg .= '<polygon points="140,160 175,180 140,200" fill="rgba(255,255,255,0.7)"/>';
    
    // Wrap title
    $words = explode(' ', $title);
    $lines = [];
    $line = '';
    foreach ($words as $word) {
        if (strlen($line . ' ' . $word) > 15) {
            $lines[] = trim($line);
            $line = $word;
        } else {
            $line .= ' ' . $word;
        }
    }
    $lines[] = trim($line);
    
    $y = 280;
    foreach (array_slice($lines, 0, 4) as $l) {
        $svg .= '<text x="150" y="'. $y .'" fill="#ffffff" font-family="system-ui, sans-serif" font-size="18" font-weight="800" text-anchor="middle">'. htmlspecialchars($l) .'</text>';
        $y += 24;
    }
    
    $svg .= '<text x="150" y="410" fill="rgba(255,255,255,0.4)" font-family="system-ui, sans-serif" font-size="11" font-weight="700" text-anchor="middle" letter-spacing="3">CINESTAR CINEMAS</text>';
    $svg .= '</svg>';
    
    return 'data:image/svg+xml;base64,' . base64_encode($svg);
}

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trang Quản Trị - Cinestar Cinemas</title>
    <!-- Bootstrap 5.3 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/style.css?v=<?php echo filemtime(__DIR__ . '/../assets/css/style.css'); ?>">
    <style>
        body {
            background-color: #090d16;
        }
    </style>
</head>
<body>

    <!-- Admin Top Navbar -->
    <nav class="navbar navbar-expand-lg navbar-cinestar py-3">
        <div class="container-fluid px-4">
            <a class="brand-logo text-decoration-none" href="../index.php">
                <i class="fa-solid fa-star text-warning me-1"></i><span>CINE</span>STAR <span class="ms-2 fs-6 text-white-50 border-start border-secondary ps-2 text-uppercase fw-semibold" style="letter-spacing: 0;">Trang Quản Trị</span>
            </a>
            
            <div class="d-flex align-items-center gap-3 ms-auto">
                <div class="text-white me-2">
                    <i class="fa-solid fa-user-shield text-warning me-2"></i>Chào, <span class="fw-bold"><?php echo htmlspecialchars($currentUser['fullname']); ?></span>
                </div>
                <a href="../index.php" class="btn btn-sm btn-outline-warning text-uppercase"><i class="fa-solid fa-globe me-1"></i>Trang Chủ</a>
                <a href="../logout.php" class="btn btn-sm btn-danger text-uppercase"><i class="fa-solid fa-power-off me-1"></i>Đăng xuất</a>
            </div>
        </div>
    </nav>

    <!-- Admin Content Layout -->
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar column -->
            <div class="col-md-3 col-xl-2 px-0 admin-sidebar">
                <div class="list-group list-group-flush">
                    <a href="index.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-chart-line"></i> Bảng điều khiển
                    </a>
                    <a href="reports.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'reports.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-chart-pie"></i> Báo cáo thống kê
                    </a>
                    <a href="movies.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'movies.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-film"></i> Quản lý phim
                    </a>
                    <a href="banners.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'banners.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-images"></i> Quản lý banner
                    </a>
                    <a href="concessions.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'concessions.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-ice-cream"></i> Quản lý bắp nước
                    </a>
                    <a href="cinemas.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'cinemas.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-building"></i> Quản lý cụm rạp
                    </a>
                    <a href="showtimes.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'showtimes.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu
                    </a>
                    <a href="bookings.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'bookings.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-ticket"></i> Quản lý đặt vé
                    </a>
                    <a href="users.php" class="admin-nav-item text-decoration-none <?php echo $current_page == 'users.php' ? 'active' : ''; ?>">
                        <i class="fa-solid fa-users-gear"></i> Quản lý thành viên
                    </a>
                </div>
            </div>
            
            <!-- Main Content Area Column -->
            <div class="col-md-9 col-xl-10 p-4">
                
                <!-- Feedback Alerts inside Admin area -->
                <?php if (isset($_SESSION['success'])): ?>
                    <div class="alert alert-success alert-dismissible fade show bg-success text-white border-0" role="alert">
                        <i class="fa-solid fa-circle-check me-2"></i><?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <?php if (isset($_SESSION['error'])): ?>
                    <div class="alert alert-danger alert-dismissible fade show bg-danger text-white border-0" role="alert">
                        <i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>
