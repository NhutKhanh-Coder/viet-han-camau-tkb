<?php
require_once __DIR__ . '/header.php';

$action = isset($_GET['action']) ? $_GET['action'] : '';

// 1. DELETE ACTION
if ($action === 'delete') {
    $cinemaId = isset($_GET['id']) ? intval($_GET['id']) : 0;
    if ($cinemaId > 0) {
        // Check if cinema has showtimes linked
        $showtimeCount = $cinemaModel->countShowtimes($cinemaId);
        if ($showtimeCount > 0) {
            $_SESSION['error'] = "Không thể xóa rạp này vì còn <strong>{$showtimeCount} suất chiếu</strong> liên quan! Vui lòng xóa các suất chiếu trước.";
        } else {
            if ($cinemaModel->delete($cinemaId)) {
                $_SESSION['success'] = "Xóa cụm rạp thành công!";
            } else {
                $_SESSION['error'] = "Có lỗi xảy ra khi xóa cụm rạp!";
            }
        }
    }
    header('Location: cinemas.php');
    exit;
}

// 2. POST ACTIONS (Create / Update)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $postAction = isset($_POST['action']) ? $_POST['action'] : '';
    $name    = trim($_POST['name'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if (empty($name) || empty($address)) {
        $_SESSION['error'] = "Vui lòng nhập đầy đủ tên cụm rạp và địa chỉ!";
    } elseif ($postAction === 'add') {
        if ($cinemaModel->create($name, $address)) {
            $_SESSION['success'] = "Thêm cụm rạp mới thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra khi thêm cụm rạp!";
        }
    } elseif ($postAction === 'edit') {
        $id = intval($_POST['id'] ?? 0);
        if ($id > 0 && $cinemaModel->update($id, $name, $address)) {
            $_SESSION['success'] = "Cập nhật thông tin cụm rạp thành công!";
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra khi cập nhật cụm rạp!";
        }
    }
    header('Location: cinemas.php');
    exit;
}

// 3. RENDER VIEW
$cinemas = $cinemaModel->getAll();
?>

<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <h2 class="text-white fw-extrabold text-uppercase">Quản Lý Cụm Rạp</h2>
        <p class="text-white-50">Thêm, sửa, xóa thông tin các cụm rạp chiếu phim</p>
    </div>
    <div class="col-md-6 text-md-end">
        <?php if ($action !== 'add' && $action !== 'edit'): ?>
            <a href="cinemas.php?action=add" class="btn btn-yellow text-uppercase fw-bold">
                <i class="fa-solid fa-circle-plus me-1"></i>Thêm Cụm Rạp Mới
            </a>
        <?php else: ?>
            <a href="cinemas.php" class="btn btn-outline-warning text-uppercase fw-bold">
                <i class="fa-solid fa-arrow-left-long me-1"></i>Quay lại danh sách
            </a>
        <?php endif; ?>
    </div>
</div>

<?php if ($action === 'add'): ?>
<!-- ===== ADD FORM ===== -->
<div class="admin-card text-white">
    <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-building me-2"></i>Thêm Cụm Rạp Mới</h4>
    <form action="cinemas.php" method="POST">
        <input type="hidden" name="action" value="add">
        <div class="row">
            <div class="col-md-5 mb-3">
                <label for="name" class="form-label text-white-50">Tên cụm rạp *</label>
                <input type="text" class="form-control form-control-dark" id="name" name="name"
                       required placeholder="Ví dụ: Cinestar Quốc Thanh">
            </div>
            <div class="col-md-7 mb-3">
                <label for="address" class="form-label text-white-50">Địa chỉ đầy đủ *</label>
                <input type="text" class="form-control form-control-dark" id="address" name="address"
                       required placeholder="Số nhà, đường, phường, quận, TP...">
            </div>
        </div>
        <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">
            <i class="fa-solid fa-floppy-disk me-1"></i>Lưu cụm rạp
        </button>
    </form>
</div>

<?php elseif ($action === 'edit'):
    $cinemaId = intval($_GET['id'] ?? 0);
    $cinema   = $cinemaModel->getById($cinemaId);
    if (!$cinema) { header('Location: cinemas.php'); exit; }
?>
<!-- ===== EDIT FORM ===== -->
<div class="admin-card text-white">
    <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-pen-to-square me-2"></i>Sửa Thông Tin Cụm Rạp</h4>
    <form action="cinemas.php" method="POST">
        <input type="hidden" name="action" value="edit">
        <input type="hidden" name="id"     value="<?php echo $cinema['id']; ?>">
        <div class="row">
            <div class="col-md-5 mb-3">
                <label for="name" class="form-label text-white-50">Tên cụm rạp *</label>
                <input type="text" class="form-control form-control-dark" id="name" name="name"
                       required value="<?php echo htmlspecialchars($cinema['name']); ?>">
            </div>
            <div class="col-md-7 mb-3">
                <label for="address" class="form-label text-white-50">Địa chỉ đầy đủ *</label>
                <input type="text" class="form-control form-control-dark" id="address" name="address"
                       required value="<?php echo htmlspecialchars($cinema['address']); ?>">
            </div>
        </div>
        <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">
            <i class="fa-solid fa-floppy-disk me-1"></i>Cập nhật
        </button>
    </form>
</div>

<?php else: ?>
<!-- ===== LIST VIEW ===== -->
<div class="admin-card">
    <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-map-location-dot me-2"></i>Danh sách cụm rạp</h4>
    <?php if (empty($cinemas)): ?>
        <p class="text-white-50 text-center py-5">Chưa có cụm rạp nào được thêm vào hệ thống.</p>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table admin-table m-0">
                <thead>
                    <tr>
                        <th style="width:50px">ID</th>
                        <th>Tên cụm rạp</th>
                        <th>Địa chỉ</th>
                        <th class="text-center">Suất chiếu</th>
                        <th class="text-end">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($cinemas as $c):
                        $stCount = $cinemaModel->countShowtimes($c['id']);
                    ?>
                        <tr>
                            <td class="text-white-50">#<?php echo $c['id']; ?></td>
                            <td>
                                <strong class="text-white"><?php echo htmlspecialchars($c['name']); ?></strong>
                            </td>
                            <td class="text-white-50" style="font-size:13px;">
                                <i class="fa-solid fa-location-dot text-warning me-1"></i>
                                <?php echo htmlspecialchars($c['address']); ?>
                            </td>
                            <td class="text-center">
                                <span class="badge <?php echo $stCount > 0 ? 'bg-info' : 'bg-secondary'; ?>">
                                    <?php echo $stCount; ?> suất
                                </span>
                            </td>
                            <td class="text-end">
                                <a href="cinemas.php?action=edit&id=<?php echo $c['id']; ?>"
                                   class="btn btn-sm btn-outline-info me-1">
                                    <i class="fa-solid fa-pen-to-square"></i> Sửa
                                </a>
                                <?php if ($stCount == 0): ?>
                                    <a href="cinemas.php?action=delete&id=<?php echo $c['id']; ?>"
                                       class="btn btn-sm btn-outline-danger"
                                       onclick="return confirm('Xóa cụm rạp «<?php echo addslashes($c['name']); ?>»?')">
                                        <i class="fa-solid fa-trash-can"></i> Xóa
                                    </a>
                                <?php else: ?>
                                    <button class="btn btn-sm btn-secondary" disabled
                                            title="Còn <?php echo $stCount; ?> suất chiếu liên quan">
                                        <i class="fa-solid fa-lock"></i> Xóa
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/footer.php'; ?>
