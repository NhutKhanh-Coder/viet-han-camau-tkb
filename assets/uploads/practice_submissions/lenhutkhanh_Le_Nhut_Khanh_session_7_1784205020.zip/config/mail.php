<?php
return [
    'smtp_host' => 'smtp.gmail.com',          // Máy chủ SMTP của Gmail
    'smtp_auth' => true,                       // Yêu cầu xác thực SMTP
    'smtp_username' => 'your-email@gmail.com', // Tài khoản email của bạn (Ví dụ: abc@gmail.com)
    'smtp_password' => 'your-app-password',    // MẬT KHẨU ỨNG DỤNG của tài khoản Gmail (không phải mật khẩu chính)
    'smtp_secure' => 'tls',                    // Phương thức bảo mật (tls hoặc ssl)
    'smtp_port' => 587,                        // Cổng SMTP (587 cho TLS, 465 cho SSL)
    'from_email' => 'noreply@cinestar-clone.com.vn', // Email hiển thị ở mục Người gửi
    'from_name' => 'Cinestar Cinemas Clone'    // Tên hiển thị ở mục Người gửi
];
