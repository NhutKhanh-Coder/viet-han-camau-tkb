<?php
class Database {
    private $host = "localhost"; 
    private $username = "root";       
    private $password = ""; 
    private $db_name = "rapphim";
    private $conn = null; // ➔ THÊM CHÍNH XÁC DÒNG NÀY VÀO ĐÂY

    public function getConnection() {
        if ($this->conn !== null) {
            return $this->conn;
        }

        try {
            // ĐÃ BỎ: Đoạn code kết nối tạo Database tự động (vì InfinityFree cấm lệnh này)
            
            // Kết nối trực tiếp vào database đã được tạo sẵn trên Hosting
            $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->db_name, $this->username, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8mb4");

            // Khởi tạo các bảng và nạp dữ liệu mẫu nếu chưa có
            $this->initializeTables();

        } catch (PDOException $exception) {
            die("Database Connection Error: " . $exception->getMessage());
        }

        return $this->conn;
    }

    private function initializeTables() {
        // 1. Users table
        $sql = "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            fullname VARCHAR(100) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            role VARCHAR(20) DEFAULT 'member',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // 2. Movies table
        $sql = "CREATE TABLE IF NOT EXISTS movies (
            id INT AUTO_INCREMENT PRIMARY KEY,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            image VARCHAR(255) NOT NULL,
            duration INT NOT NULL,
            release_date DATE NOT NULL,
            rating VARCHAR(50) NOT NULL,
            status VARCHAR(20) NOT NULL,
            trailer_url VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // 3. Cinemas table
        $sql = "CREATE TABLE IF NOT EXISTS cinemas (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(255) NOT NULL,
            address VARCHAR(255) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // 4. Showtimes table
        $sql = "CREATE TABLE IF NOT EXISTS showtimes (
            id INT AUTO_INCREMENT PRIMARY KEY,
            movie_id INT NOT NULL,
            cinema_id INT NOT NULL,
            show_date DATE NOT NULL,
            show_time TIME NOT NULL,
            price DECIMAL(10, 2) NOT NULL,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE,
            FOREIGN KEY (cinema_id) REFERENCES cinemas(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // 5. Bookings table
        $sql = "CREATE TABLE IF NOT EXISTS bookings (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            showtime_id INT NOT NULL,
            seats VARCHAR(255) NOT NULL,
            concessions TEXT,
            total_price DECIMAL(10, 2) NOT NULL,
            booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (showtime_id) REFERENCES showtimes(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // 6. Banners table
        $sql = "CREATE TABLE IF NOT EXISTS banners (
            id INT AUTO_INCREMENT PRIMARY KEY,
            movie_id INT NOT NULL,
            subtitle VARCHAR(100) NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            image VARCHAR(255) NOT NULL,
            trim_seconds INT DEFAULT 3,
            sort_order INT DEFAULT 0,
            FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // 7. Concession Items table
        $sql = "CREATE TABLE IF NOT EXISTS concession_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            description TEXT,
            price DECIMAL(10, 2) NOT NULL,
            image VARCHAR(255) DEFAULT NULL,
            icon_type VARCHAR(50) DEFAULT 'solo'
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
        $this->conn->exec($sql);

        // Tự động kiểm tra và nâng cấp cột nếu cần thiết
        try {
            $this->conn->exec("ALTER TABLE bookings ADD COLUMN concessions TEXT AFTER seats");
        } catch (PDOException $e) {}

        try {
            $this->conn->exec("ALTER TABLE concession_items ADD COLUMN image VARCHAR(255) DEFAULT NULL AFTER price");
        } catch (PDOException $e) {}

        try {
            $this->conn->exec("ALTER TABLE banners ADD COLUMN trim_seconds INT DEFAULT 3 AFTER image");
        } catch (PDOException $e) {}

        // Tiến hành đổ dữ liệu mẫu nếu bảng trống
        $this->seedData();
    }

    private function seedData() {
        // Seed Users
        $stmt = $this->conn->query("SELECT COUNT(*) FROM users");
        if ($stmt->fetchColumn() == 0) {
            $admin_pass = password_hash("admin123", PASSWORD_DEFAULT);
            $member_pass = password_hash("member123", PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO users (username, password, email, fullname, phone, role) VALUES 
                ('admin', :admin_pass, 'admin@cinestar.com.vn', 'Quản Trị Viên', '0912345678', 'admin'),
                ('member', :member_pass, 'khachhang@gmail.com', 'Nguyễn Nhật Khang', '0987654321', 'member')";
            
            $insert = $this->conn->prepare($sql);
            $insert->execute([
                ':admin_pass' => $admin_pass,
                ':member_pass' => $member_pass
            ]);
        }

        // Seed Cinemas
        $stmt = $this->conn->query("SELECT COUNT(*) FROM cinemas");
        if ($stmt->fetchColumn() == 0) {
            $sql = "INSERT INTO cinemas (name, address) VALUES 
                ('Cinestar Quốc Thanh', '271 Nguyễn Trãi, Phường Nguyễn Cư Trinh, Quận 1, TP.HCM'),
                ('Cinestar Hai Bà Trưng', '135 Hai Bà Trưng, Phường Bến Nghé, Quận 3, TP.HCM'),
                ('Cinestar Sinh Viên', 'Khu đô thị ĐHQG TP.HCM, Phường Đông Hòa, Dĩ An, Bình Dương'),
                ('Cinestar Lâm Đồng', 'Quảng trường Lâm Viên, Phường 10, Đà Lạt, Lâm Đồng')";
            $this->conn->exec($sql);
        }

        // Seed Movies
        $stmt = $this->conn->query("SELECT COUNT(*) FROM movies");
        if ($stmt->fetchColumn() == 0) {
            $sql = "INSERT INTO movies (title, description, image, duration, release_date, rating, status, trailer_url) VALUES 
                ('Ma Xó', 'Nghi lễ luyện ma xó ám ảnh nhất màn ảnh Việt. Phim kinh dị tâm linh đầy kịch tính.', 'ma_xo.png', 110, '2026-06-04', 'T18', 'showing', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Doraemon: Nobita và Lâu Đài Dưới Đáy Biển', 'Cuộc phiêu lưu kỳ thú của Nobita và nhóm bạn dưới đáy đại dương bao la, khám phá những bí ẩn và giải cứu thế giới.', 'doraemon.png', 95, '2026-05-22', 'P', 'showing', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Ngôi Đền Kỳ Quái 4', 'Sự trở lại của chuỗi phim kinh dị hài hước đình đám từ Thái Lan. Ngôi đền ma quái tiếp tục chào đón những nạn nhân mới.', 'ngoi_den_ky_quai_4.png', 115, '2026-05-28', 'T16', 'showing', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Ốc Mượn Hồn', 'Câu chuyện kinh dị về chiếc vỏ ốc mang lời nguyền chết chóc và những bí mật rùng rợn trong gia đình.', 'oc_muon_hon.jpg', 105, '2026-05-29', 'T16', 'showing', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Yên Chi Khấu', 'Tác phẩm nghệ thuật đỉnh cao, bộ phim tình cảm lãng mạn đầy cảm xúc kể về tình yêu vượt thời gian.', 'yen_chi_khau.jpg', 96, '2026-06-12', 'T18', 'coming', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Gintama: The Movie', 'Phiên bản điện ảnh đầy ắp tiếng cười và các pha hành động mãn nhãn của nhóm thợ vạn năng Gintoki.', 'gintama.jpg', 104, '2026-06-12', 'CHƯA PHÂN LOẠI', 'coming', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Colony: Bầy Xác Sống', 'Phim hành động giả tưởng sinh tồn trong thế giới hậu tận thế bị thống trị bởi bầy xác sống khát máu.', 'colony.jpg', 90, '2026-06-12', 'T16', 'coming', 'https://www.youtube.com/embed/dQw4w9WgXcQ'),
                ('Quỷ Nhập Xác Đòi Mạng', 'Trận chiến kinh hoàng chống lại các thế lực quỷ dữ nhập vào thân xác con người để trả thù.', 'quy_nhap_xac.jpg', 100, '2026-06-12', 'T18', 'coming', 'https://www.youtube.com/embed/dQw4w9WgXcQ')";
            $this->conn->exec($sql);
        }

        // Seed Banners
        $stmt = $this->conn->query("SELECT COUNT(*) FROM banners");
        if ($stmt->fetchColumn() == 0) {
            $sql = "INSERT INTO banners (movie_id, subtitle, title, description, image, sort_order) VALUES 
                (2, 'Hot Ticket', 'Doraemon: Nobita và Lâu Đài Dưới Đáy Biển', 'Mua 01 Vé Xem Phim Doraemon Tặng 01 Ấn Phẩm Đồng Hành. Áp dụng cho các suất chiếu sớm đặc biệt!', 'doraemon.png', 1),
                (1, 'Kinh Dị Việt', 'Ma Xó', 'Tác phẩm tâm linh rùng rợn, khai thác nghi thức luyện ma xó đầy bí ẩn và ghê rợn.', 'ma_xo.png', 2),
                (3, 'Phim Bom Tấn', 'Ngôi Đền Kỳ Quái 4', 'Bộ phim kinh dị hài hước số 1 của Thái Lan đã quay trở lại. Hãy sẵn sàng cho những tràng cười rớt hàm và giật mình thon thót.', 'ngoi_den_ky_quai_4.png', 3)";
            $this->conn->exec($sql);
        }

        // Seed Concession Items
        $stmt = $this->conn->query("SELECT COUNT(*) FROM concession_items");
        if ($stmt->fetchColumn() == 0) {
            $sql = "INSERT INTO concession_items (name, description, price, icon_type) VALUES 
                ('Solo Combo', 'Dành cho 1 người ăn. Gồm 1 Bắp lớn 60oz (vị Ngọt/Mặn) + 1 Nước ngọt lớn 32oz (Coke/Sprite/Fanta) tự chọn vị tại rạp.', 75000.00, 'solo'),
                ('Twin Combo', 'Dành cho cặp đôi. Gồm 1 Bắp lớn 60oz (vị Ngọt/Mặn) + 2 Nước ngọt lớn 32oz tùy chọn hương vị yêu thích.', 110000.00, 'twin'),
                ('Party Combo', 'Dành cho gia đình hoặc nhóm bạn. Gồm 2 Bắp lớn 60oz + 4 Nước ngọt lớn 32oz siêu tiết kiệm.', 190000.00, 'party')";
            $this->conn->exec($sql);
        }

        // Seed Showtimes for the next 7 days
        $stmt = $this->conn->query("SELECT COUNT(*) FROM showtimes");
        $count = $stmt->fetchColumn();
        
        $reseed = false;
        if ($count > 0) {
            $max_date = $this->conn->query("SELECT MAX(show_date) FROM showtimes")->fetchColumn();
            if ($max_date < date('Y-m-d')) {
                $this->conn->exec("SET FOREIGN_KEY_CHECKS = 0; TRUNCATE TABLE showtimes; SET FOREIGN_KEY_CHECKS = 1;");
                $reseed = true;
            }
        } else {
            $reseed = true;
        }

        if ($reseed) {
            $movies = $this->conn->query("SELECT id FROM movies WHERE status = 'showing'")->fetchAll(PDO::FETCH_COLUMN);
            $cinemas = $this->conn->query("SELECT id FROM cinemas")->fetchAll(PDO::FETCH_COLUMN);
            
            if (!empty($movies) && !empty($cinemas)) {
                $times = ['09:00:00', '12:15:00', '15:30:00', '18:45:00', '21:30:00'];
                $prices = [75000.00, 85000.00, 95000.00];

                $sql = "INSERT INTO showtimes (movie_id, cinema_id, show_date, show_time, price) VALUES (:movie_id, :cinema_id, :show_date, :show_time, :price)";
                $insert = $this->conn->prepare($sql);

                for ($i = 0; $i < 7; $i++) {
                    $date = date('Y-m-d', strtotime("+$i days"));
                    foreach ($movies as $movie_id) {
                        foreach ($cinemas as $cinema_id) {
                            $selected_times = array_rand($times, 3);
                            foreach ($selected_times as $idx) {
                                $time = $times[$idx];
                                $price = $prices[array_rand($prices)];
                                $insert->execute([
                                    ':movie_id' => $movie_id,
                                    ':cinema_id' => $cinema_id,
                                    ':show_date' => $date,
                                    ':show_time' => $time,
                                    ':price' => $price
                                ]);
                            }
                        }
                    }
                }
            }
        }
    }
}
?>