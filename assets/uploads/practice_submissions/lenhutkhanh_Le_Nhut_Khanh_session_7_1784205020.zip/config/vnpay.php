<?php
return [
    'vnp_Url'        => 'https://sandbox.vnpayment.vn/paymentv2/vpcpay.html',
    'vnp_TmnCode'    => 'JQ9SAU28',                       // Mã định danh website (Sandbox)
    'vnp_HashSecret' => 'A8YAVY18F93PW4P4ZCY5IDGN93LG730E', // Chuỗi bí mật tạo chữ ký (Sandbox)
    'vnp_Returnurl'  => 'http://localhost/rapphim/vnpay_return.php' // Đường dẫn phản hồi sau thanh toán
];
