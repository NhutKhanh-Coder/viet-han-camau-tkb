# -*- coding: utf-8 -*-
"""
Generate a Word (.docx) report for Cinestar Clone Website project
"""
import sys
import os
import re
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

BASE_DIR = r"c:\xampp\htdocs\rapphim"
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "assets", "images")
OUTPUT = os.path.join(BASE_DIR, "BaoCao_DoAn_Cinestar.docx")
MARKDOWN_FILE = os.path.join(BASE_DIR, "BaoCao_DoAn.md")

def add_horizontal_line(paragraph):
    """Add a bottom border to a paragraph to simulate a horizontal line."""
    pPr = paragraph._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    bottom = OxmlElement('w:bottom')
    bottom.set(qn('w:val'), 'single')
    bottom.set(qn('w:sz'), '6')
    bottom.set(qn('w:space'), '1')
    bottom.set(qn('w:color'), '0284c7') # Primary theme color
    pBdr.append(bottom)
    pPr.append(pBdr)

def set_font(run, size=13, bold=False, italic=False, color=None):
    run.font.name = 'Times New Roman'
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    if color:
        run.font.color.rgb = RGBColor(*color)

def add_formatted_text(paragraph, text, default_size=13, default_color=None):
    parts = re.split(r'(\*\*.*?\*\*|`.*?`)', text)
    for part in parts:
        if not part:
            continue
        if part.startswith('**') and part.endswith('**'):
            clean_text = part[2:-2]
            run = paragraph.add_run(clean_text)
            set_font(run, size=default_size, bold=True, color=default_color)
        elif part.startswith('`') and part.endswith('`'):
            clean_text = part[1:-1]
            run = paragraph.add_run(clean_text)
            set_font(run, size=default_size - 1, bold=False, italic=False, color=(3, 105, 161)) # Blue color for code
        else:
            run = paragraph.add_run(part)
            set_font(run, size=default_size, color=default_color)

def heading(doc, text, level=1, size=16, center=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(6)
    p.paragraph_format.keep_with_next = True
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_formatted_text(p, text, default_size=size)
    # Bold the whole heading paragraph
    for r in p.runs:
        r.font.bold = True
    if level == 1:
        add_horizontal_line(p)
    return p

def body(doc, text, indent=True, italic=False, size=13, center=False):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(6)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    if center:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if indent and not center:
        p.paragraph_format.first_line_indent = Cm(1.27)
    add_formatted_text(p, text, default_size=size)
    if italic:
        for r in p.runs:
            r.font.italic = True
    return p

def bullet_item(doc, text, size=13):
    p = doc.add_paragraph(style='List Bullet')
    p.paragraph_format.space_after = Pt(4)
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    add_formatted_text(p, text, default_size=size)
    return p

def code_block(doc, code_text, size=9.5):
    p = doc.add_paragraph()
    p.paragraph_format.left_indent = Cm(0.5)
    p.paragraph_format.space_before = Pt(6)
    p.paragraph_format.space_after = Pt(6)
    
    pPr = p._p.get_or_add_pPr()
    pBdr = OxmlElement('w:pBdr')
    for side in ['top', 'left', 'bottom', 'right']:
        el = OxmlElement(f'w:{side}')
        el.set(qn('w:val'), 'single')
        el.set(qn('w:sz'), '4')
        el.set(qn('w:space'), '4')
        el.set(qn('w:color'), 'cbd5e1')
        pBdr.append(el)
    pPr.append(pBdr)
    
    shd = OxmlElement('w:shd')
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), 'F8FAFC')
    pPr.append(shd)
    
    run = p.add_run(code_text)
    run.font.name = 'Courier New'
    run.font.size = Pt(size)
    return p

def insert_image(doc, img_name, caption, width=Cm(15.5)):
    img_path = os.path.join(SCREENSHOTS_DIR, img_name)
    if os.path.exists(img_path):
        try:
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.add_run().add_picture(img_path, width=width)
        except Exception as e:
            body(doc, f"[Hình ảnh: {img_name} - Lỗi tải ảnh]", indent=False, center=True)
    else:
        body(doc, f"[Hình ảnh: {img_name} - Không tìm thấy file]", indent=False, center=True)
    
    cap = doc.add_paragraph()
    cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    cap.paragraph_format.space_after = Pt(12)
    run = cap.add_run(caption)
    run.font.name = 'Times New Roman'
    run.font.size = Pt(10)
    run.font.italic = True
    return cap

def build_table(doc, rows):
    if not rows:
        return
    num_cols = len(rows[0])
    num_rows = len(rows)
    
    table = doc.add_table(rows=num_rows, cols=num_cols)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    
    # Calculate even column width
    col_width = Cm(15.5 / num_cols)
    
    for r_idx, row_cells in enumerate(rows):
        row = table.rows[r_idx]
        is_header = (r_idx == 0)
        for c_idx, cell_value in enumerate(row_cells):
            cell = row.cells[c_idx]
            cell.width = col_width
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.space_before = Pt(2)
            
            # Formatting text
            cell_value_clean = cell_value.replace('`', '')
            run = p.add_run(cell_value_clean)
            set_font(run, size=10, bold=is_header)
            if is_header:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER

def set_margins(doc):
    for section in doc.sections:
        section.page_height = Cm(29.7)
        section.page_width = Cm(21.0)
        section.left_margin = Cm(3.0)
        section.right_margin = Cm(2.0)
        section.top_margin = Cm(2.5)
        section.bottom_margin = Cm(2.0)

doc = Document()
set_margins(doc)

# ============================================================
# TRANG 1: TRANG BÌA
# ============================================================
p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("BỘ LAO ĐỘNG - THƯƠNG BINH VÀ XÃ HỘI\n")
set_font(r, 13, bold=True)
r2 = p.add_run("TRƯỜNG CAO ĐẲNG NGHỀ VN-HQ CÀ MAU")
set_font(r2, 14, bold=True)

# Add some spacing
for _ in range(4):
    doc.add_paragraph()

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("BÁO CÁO ĐỒ ÁN MÔN HỌC: LẬP TRÌNH WEB\n")
set_font(r, 15, bold=True)

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("XÂY DỰNG WEBSITE ĐẶT VÉ XEM PHIM TRỰC TUYẾN MÔ PHỎNG CINESTAR CINEMAS\n")
set_font(r, 22, bold=True, color=(30, 58, 138)) # Navy color

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("Hệ thống quản lý đặt vé & bắp nước trực tuyến dựa trên mô hình PHP OOP & MySQL")
set_font(r, 12, italic=True)

for _ in range(4):
    doc.add_paragraph()

# Cover Info Table
table = doc.add_table(rows=5, cols=2)
table.alignment = WD_TABLE_ALIGNMENT.CENTER
info = [
    ("Ngành học:", "CÔNG NGHỆ THÔNG TIN"),
    ("Giảng viên hướng dẫn:", "PHẠM DUY CƯỜNG"),
    ("Sinh viên thực hiện:", "NGUYỄN NHẬT KHANG"),
    ("Mã số sinh viên:", "22CT0129"),
    ("Lớp học:", "Cao đẳng CNTT K22"),
]
for i, (label, value) in enumerate(info):
    row = table.rows[i]
    r1 = row.cells[0].paragraphs[0].add_run(label)
    set_font(r1, 13, bold=True)
    r2 = row.cells[1].paragraphs[0].add_run(value)
    set_font(r2, 13)
    row.cells[0].width = Cm(5.5)
    row.cells[1].width = Cm(10)

for _ in range(3):
    doc.add_paragraph()

p = doc.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run("CÀ MAU — NĂM 2026")
set_font(r, 13, bold=True)

doc.add_page_break()

# ============================================================
# TRANG 2: MỤC LỤC
# ============================================================
heading(doc, "MỤC LỤC BÁO CÁO", level=1, center=True)

toc_items = [
    ("GIỚI THIỆU TỔNG QUAN ĐỀ TÀI", "1"),
    ("  1.1. Lý do chọn đề tài", "1"),
    ("  1.2. Mục tiêu nghiên cứu và phát triển", "2"),
    ("  1.3. Phạm vi ứng dụng", "2"),
    ("  1.4. Đối tượng sử dụng hệ thống", "3"),
    ("CÔNG NGHỆ VÀ MÔ HÌNH PHÁT TRIỂN", "4"),
    ("  2.1. Ngôn ngữ PHP 8.x và Lập trình hướng đối tượng (OOP)", "4"),
    ("  2.2. Hệ quản trị cơ sở dữ liệu MySQL và Thư viện PDO", "5"),
    ("  2.3. Công nghệ giao diện (HTML5, CSS3, Bootstrap, jQuery, AJAX)", "5"),
    ("  2.4. Công nghệ AJAX và cơ chế cập nhật không tải lại trang", "6"),
    ("  2.5. Kiến trúc thư mục và sơ đồ tổ chức source code", "7"),
    ("PHÂN TÍCH YÊU CẦU HỆ THỐNG", "8"),
    ("  3.1. Phân tích tác nhân (Actors)", "8"),
    ("  3.2. Sơ đồ Use Case tổng quát", "9"),
    ("  3.3. Đặc tả các Use Case trọng tâm", "9"),
    ("  3.4. Các yêu cầu phi chức năng (Non-functional Requirements)", "12"),
    ("THIẾT KẾ CƠ SỞ DỮ LIỆU CHI TIẾT", "13"),
    ("  4.1. Sơ đồ thực thể quan hệ (ERD Diagram)", "13"),
    ("  4.2. Thiết kế chi tiết các bảng dữ liệu", "14"),
    ("  4.3. Ràng buộc toàn vẹn và toàn vẹn tham chiếu CSDL", "16"),
    ("  4.4. Cơ chế cài đặt tự động (Auto Installer & Seeder)", "16"),
    ("THIẾT KẾ KIẾN TRÚC LỚP & ĐỐI TƯỢNG (OOP CLASS DESIGN)", "17"),
    ("  5.1. Sơ đồ Class Diagram", "17"),
    ("  5.2. Lớp Database và thiết kế Singleton Pattern", "17"),
    ("  5.3. Đặc tả chi tiết 7 lớp Model", "18"),
    ("  5.4. Ví dụ code triển khai các Model", "20"),
    ("MÔ TẢ CHI TIẾT CÁC CHỨC NĂNG HỆ THỐNG", "22"),
    ("  6.1. Phân hệ Khách hàng / Thành viên công cộng", "22"),
    ("  6.2. Nghiệp vụ Chọn ghế và Tính tiền động (Booking Flow)", "22"),
    ("  6.3. Xử lý Combo bắp nước và lưu trữ JSON Concessions", "25"),
    ("  6.4. Phân hệ Quản trị viên (Admin Area)", "25"),
    ("LUỒNG XỬ LÝ NGHIỆP VỤ & SƠ ĐỒ TUẦN TỰ", "26"),
    ("  7.1. Sơ đồ tuần tự luồng Đặt vé trực tuyến", "26"),
    ("  7.2. Sơ đồ tuần tự luồng AJAX Đặt vé nhanh tại trang chủ", "27"),
    ("GIAO DIỆN HỆ THỐNG & HƯỚNG DẪN SỬ DỤNG", "28"),
    ("  8.1. Hướng dẫn cài đặt chi tiết trên localhost", "28"),
    ("  8.2. Tài khoản kiểm thử hệ thống", "28"),
    ("  8.3. Mô tả các màn hình giao diện chính", "29"),
    ("KIỂM THỬ HỆ THỐNG (TESTING & VALIDATION)", "33"),
    ("  9.1. Kịch bản kiểm thử (Test Cases) các chức năng chính", "33"),
    ("  9.2. Đánh giá kết quả kiểm thử thực tế", "38"),
    ("KẾT LUẬN & HƯỚNG PHÁT TRIỂN", "39"),
    ("  10.1. Các kết quả đã đạt được", "39"),
    ("  10.2. Hạn chế hiện tại của đồ án", "40"),
    ("  10.3. Đề xuất hướng phát triển tiếp theo", "40"),
    ("PHỤ LỤC: MÃ NGUỒN CÁC FILE CỐT LÕI", "41"),
]

toc_table = doc.add_table(rows=len(toc_items), cols=2)
for i, (title, page) in enumerate(toc_items):
    row = toc_table.rows[i]
    is_chapter = not title.startswith("  ")
    r1 = row.cells[0].paragraphs[0].add_run(title)
    set_font(r1, 12, bold=is_chapter)
    r2 = row.cells[1].paragraphs[0].add_run(page)
    set_font(r2, 12, bold=is_chapter)
    row.cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT
    row.cells[0].width = Cm(13.5)
    row.cells[1].width = Cm(2)

doc.add_page_break()

# ============================================================
# PARSE MARKDOWN FILE
# ============================================================
print(f"Reading markdown file: {MARKDOWN_FILE}")
with open(MARKDOWN_FILE, "r", encoding="utf-8") as f:
    lines = f.readlines()

in_toc = True
in_code = False
in_table = False
table_rows = []
code_lines = []

for line_num, raw_line in enumerate(lines, 1):
    line = raw_line.rstrip('\r\n')
    
    # Check if we should skip the markdown's own TOC
    if in_toc:
        if line.startswith("## 1. GIỚI THIỆU"):
            in_toc = False
        else:
            continue
            
    # Page breaks simulated by markdown dividers
    if line.strip() == "---" and not in_code:
        # If there is a table pending, build it first
        if in_table and table_rows:
            build_table(doc, table_rows)
            table_rows = []
            in_table = False
        doc.add_page_break()
        continue

    # Code blocks
    if line.strip().startswith("```"):
        if in_code:
            # End code block
            code_block(doc, '\n'.join(code_lines))
            code_lines = []
            in_code = False
        else:
            # If there is a table pending, build it first
            if in_table and table_rows:
                build_table(doc, table_rows)
                table_rows = []
                in_table = False
            in_code = True
        continue
        
    if in_code:
        code_lines.append(line)
        continue

    # Tables parsing
    if line.strip().startswith('|') and line.strip().endswith('|') and not in_code:
        # Check if it is a separator line like | :--- | :--- |
        clean_line = line.strip()
        is_separator = all(c in ':- |' for c in clean_line)
        if not is_separator:
            # Parse columns
            cols = [c.strip() for c in clean_line.split('|')[1:-1]]
            table_rows.append(cols)
            in_table = True
        continue
    else:
        # If table was building and now we exited the table
        if in_table and table_rows:
            build_table(doc, table_rows)
            table_rows = []
            in_table = False

    # Headings
    if line.startswith("# ") and not in_code:
        heading(doc, line[2:].strip(), level=1, size=16)
        continue
    elif line.startswith("## ") and not in_code:
        heading(doc, line[3:].strip(), level=2, size=14)
        continue
    elif line.startswith("### ") and not in_code:
        heading(doc, line[4:].strip(), level=3, size=12)
        continue
    elif line.startswith("#### ") and not in_code:
        heading(doc, line[5:].strip(), level=4, size=11)
        continue

    # Image markup: ![Caption](path)
    img_match = re.search(r'!\[(.*?)\]\((.*?)\)', line)
    if img_match and not in_code:
        caption = img_match.group(1)
        img_path = img_match.group(2)
        # Extract filename only since screenshots are all in SCREENSHOTS_DIR
        img_name = os.path.basename(img_path)
        insert_image(doc, img_name, f"Hình: {caption}")
        continue

    # List items
    list_match = re.match(r'^\s*[\*\-\+]\s+(.*)', line)
    if list_match and not in_code:
        bullet_item(doc, list_match.group(1).strip())
        continue

    # Order list items (e.g. 1.  or 1. )
    num_list_match = re.match(r'^\s*\d+\.\s+(.*)', line)
    if num_list_match and not in_code:
        # Render numbered lists as bullet items or text with indent
        bullet_item(doc, num_list_match.group(1).strip())
        continue

    # Normal text block
    if line.strip() and not in_code:
        body(doc, line.strip())

# Build any final pending table
if in_table and table_rows:
    build_table(doc, table_rows)

# ============================================================
# CHƯƠNG 9 ADDENDUM: SCREENSHOTS MÀN HÌNH GIAO DIỆN
# (Chèn trực tiếp để đảm bảo tất cả ảnh có trong Word)
# ============================================================
doc.add_page_break()
heading(doc, "9. GIAO DIỆN HỆ THỐNG — MÀN HÌNH CHỨC NĂNG CHI TIẾT (PHẦN BỔ SUNG)", level=1, size=16)
body(doc, "Phần này trình bày toàn bộ 18 màn hình giao diện chức năng chính của Website Cinestar Clone, bao gồm cả giao diện phía khách hàng và phân hệ quản trị Admin Panel.")

screenshots_to_add = [
    ("sc_home.png", "Hình 9.1: Trang chủ Homepage — Slide banner lớn và thanh Đặt Vé Nhanh AJAX 4 bước"),
    ("sc_home2.png", "Hình 9.2: Trang chủ phần dưới — Danh sách phim đang chiếu dạng card hover neon"),
    ("sc_login.png", "Hình 9.3: Form Đăng nhập — Glassmorphism dark mode, viền vàng neon tinh tế"),
    ("sc_register.png", "Hình 9.4: Form Đăng ký — Validation HTML5 và kiểm tra trùng tài khoản"),
    ("sc_booking.png", "Hình 9.5: Trang Đặt vé — Sơ đồ ghế tương tác: Thường (xám), VIP (tím), Đang chọn (vàng), Đã bán (đỏ)"),
    ("sc_concessions.png", "Hình 9.6: Trang Bắp nước (Phần 1) — Danh mục combo bắp nước kèm giá online"),
    ("sc_concessions2.png", "Hình 9.7: Trang Bắp nước (Phần 2) — Mở rộng combo và banner khuyến mãi kèm vé"),
    ("sc_promotions.png", "Hình 9.8: Trang Khuyến mãi — Thẻ thành viên, ưu đãi sinh viên, Happy Day"),
    ("sc_events.png", "Hình 9.9: Trang Sự kiện — Chiếu phim doanh nghiệp, gala screening"),
    ("sc_services.png", "Hình 9.10: Trang Dịch vụ — Bowling, café, arcade trong tổ hợp rạp"),
    ("sc_about.png", "Hình 9.11: Trang Giới thiệu — Lịch sử, sứ mệnh và công nghệ Dolby Atmos"),
    ("sc_admin.png", "Hình 9.12: Admin Dashboard — Tổng doanh thu, tổng vé bán, bảng giao dịch thời gian thực"),
    ("sc_movies.png", "Hình 9.13: Admin Quản lý phim — CRUD phim, upload poster và trailer YouTube"),
    ("sc_admin_cinemas.png", "Hình 9.14: Admin Quản lý rạp — CRUD chi nhánh rạp, địa chỉ và sức chứa"),
    ("sc_admin_users.png", "Hình 9.15: Admin Quản lý thành viên — Danh sách tài khoản, phân quyền"),
    ("sc_admin_reports.png", "Hình 9.16: Admin Báo cáo doanh thu — Thống kê theo ngày/tháng/phim"),
    ("sc_admin_concessions2.png", "Hình 9.17: Admin Quản lý bắp nước — CRUD combo, cập nhật giá và mô tả"),
    ("sc_admin_dashboard.png", "Hình 9.18: Admin Panel tổng quan — Sidebar điều hướng và thống kê tóm tắt thẻ"),
]

for img_file, caption in screenshots_to_add:
    insert_image(doc, img_file, caption)

# ============================================================
# CHƯƠNG 11: PHỤ LỤC MÃ NGUỒN CỐT LÕI
# ============================================================
doc.add_page_break()
heading(doc, "11. PHỤ LỤC: MÃ NGUỒN CÁC FILE CỐT LÕI", level=1, size=16)
body(doc, "Dưới đây là toàn bộ mã nguồn của các tệp tin cấu hình và các lớp thực thể xử lý nghiệp vụ cốt lõi trong hệ thống rạp phim Cinestar Clone, giúp minh chứng tính chân thực của đồ án môn học:")

files_to_include = [
    ("1. File Cấu Hình Kết Nối & Tự Sinh CSDL: `config/Database.php`", os.path.join(BASE_DIR, "config", "Database.php")),
    ("2. Lớp Đối Tượng Quản Lý Tài Khoản User: `models/User.php`", os.path.join(BASE_DIR, "models", "User.php")),
    ("3. Lớp Đối Tượng Xử Lý Đặt Vé & Ghế: `models/Booking.php`", os.path.join(BASE_DIR, "models", "Booking.php")),
    ("4. Lớp Đối Tượng Quản Lý Suất Chiếu: `models/Showtime.php`", os.path.join(BASE_DIR, "models", "Showtime.php")),
    ("5. Router API Nhận Yêu Cầu Đặt Vé Nhanh AJAX: `ajax-quick-book.php`", os.path.join(BASE_DIR, "ajax-quick-book.php")),
    ("6. File Script Xử Lý Tương Tác Khách Hàng: `assets/js/main.js`", os.path.join(BASE_DIR, "assets", "js", "main.js")),
]

for title, fpath in files_to_include:
    heading(doc, title, level=2, size=13)
    if os.path.exists(fpath):
        print(f"Reading source file: {fpath}")
        with open(fpath, "r", encoding="utf-8") as sf:
            code_content = sf.read()
        code_block(doc, code_content)
    else:
        body(doc, f"[Không tìm thấy tệp tin: {os.path.basename(fpath)}]", indent=False, italic=True)

# Save document
doc.save(OUTPUT)
print(f"Word document successfully created: {OUTPUT}")
print(f"File size: {os.path.getsize(OUTPUT) / 1024 / 1024:.2f} MB")
