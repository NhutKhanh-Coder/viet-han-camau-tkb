<?php
require_once __DIR__ . '/views/header.php';
?>

<div class="container py-5 min-vh-100">
    <!-- Page Header -->
    <div class="text-center mb-5">
        <h1 class="display-4 fw-bold text-white text-uppercase">
            <span class="text-warning"><i class="fa-solid fa-gamepad me-2"></i>Dịch Vụ</span> Giải Trí Khác
        </h1>
        <p class="text-white-50 fs-5">Khám phá tổ hợp vui chơi giải trí đa phương tiện đỉnh cao bên cạnh phòng chiếu phim</p>
        <div class="mx-auto" style="width: 80px; height: 4px; background: linear-gradient(90deg, var(--accent-yellow), var(--accent-purple)); border-radius: 2px;"></div>
    </div>

    <!-- Service Section 1: Star Bowling -->
    <div class="row align-items-center mb-5 bg-secondary-cinestar rounded-4 overflow-hidden border border-secondary-light mx-0 shadow-lg">
        <div class="col-lg-6 px-0">
            <div class="img-zoom-wrapper position-relative" style="height: 350px;">
                <img src="assets/images/service_bowling_v2.png" class="w-100 h-100 object-fit-cover transition-zoom" alt="Star Bowling">
                <div class="gradient-overlay position-absolute bottom-0 start-0 w-100" style="height: 100px; background: linear-gradient(0deg, var(--bg-secondary), transparent);"></div>
            </div>
        </div>
        <div class="col-lg-6 p-5">
            <span class="badge bg-warning text-dark mb-3 fw-bold text-uppercase px-3 py-2" style="font-size: 11px; letter-spacing: 1px;"><i class="fa-solid fa-star me-1"></i> Trải nghiệm nổi bật</span>
            <h2 class="text-white fw-bold mb-3">STAR BOWLING - Sân Chơi Cực Đỉnh</h2>
            <p class="text-white-50 fs-6 mb-4" style="line-height: 1.7;">
                Trang bị làn bowling chuẩn thi đấu quốc tế cùng hệ thống đèn neon phát sáng nhảy theo nhạc. Điểm tụ họp lý tưởng hàng đầu dành cho nhóm bạn hoặc gia đình so tài kỹ năng ném bóng.
            </p>
            <div class="row mb-4">
                <div class="col-6">
                    <h6 class="text-warning fw-bold mb-1"><i class="fa-solid fa-tags me-1"></i> Giá Vé Ngày Thường</h6>
                    <p class="text-white mb-0" style="font-size: 14px;">50,000 VNĐ / Game</p>
                </div>
                <div class="col-6">
                    <h6 class="text-warning fw-bold mb-1"><i class="fa-solid fa-tags me-1"></i> Cuối Tuần & Ngày Lễ</h6>
                    <p class="text-white mb-0" style="font-size: 14px;">70,000 VNĐ / Game</p>
                </div>
            </div>
            <ul class="list-unstyled text-white-50 d-flex flex-wrap gap-3 mb-0" style="font-size: 14px;">
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Miễn phí thuê giày</li>
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> 12 làn ném chất lượng</li>
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Phục vụ đồ ăn nhẹ</li>
            </ul>
        </div>
    </div>

    <!-- Service Section 2: Star Arcade -->
    <div class="row align-items-center mb-5 bg-secondary-cinestar rounded-4 overflow-hidden border border-secondary-light mx-0 shadow-lg flex-row-reverse">
        <div class="col-lg-6 px-0">
            <div class="img-zoom-wrapper position-relative" style="height: 350px;">
                <img src="assets/images/service_arcade_v2.png" class="w-100 h-100 object-fit-cover transition-zoom" alt="Star Arcade">
                <div class="gradient-overlay position-absolute bottom-0 start-0 w-100" style="height: 100px; background: linear-gradient(0deg, var(--bg-secondary), transparent);"></div>
            </div>
        </div>
        <div class="col-lg-6 p-5">
            <span class="badge bg-purple text-white mb-3 fw-bold text-uppercase px-3 py-2" style="font-size: 11px; letter-spacing: 1px; background-color: var(--accent-purple) !important;"><i class="fa-solid fa-gamepad me-1"></i> Khu vui chơi điện tử</span>
            <h2 class="text-white fw-bold mb-3">STAR ARCADE - Thiên Đường Trò Chơi</h2>
            <p class="text-white-50 fs-6 mb-4" style="line-height: 1.7;">
                Hệ thống máy chơi game thùng (arcade) thế hệ mới tích hợp hơn 50 trò chơi hấp dẫn: từ đua xe thực tế ảo, bắn súng kịch tính đến máy nhảy theo nhạc Audition nhộn nhịp và gắp gấu bông dễ thương.
            </p>
            <div class="row mb-4">
                <div class="col-6">
                    <h6 class="text-warning fw-bold mb-1"><i class="fa-solid fa-coins me-1"></i> Giá Xu Lẻ</h6>
                    <p class="text-white mb-0" style="font-size: 14px;">4,000 VNĐ / Xu</p>
                </div>
                <div class="col-6">
                    <h6 class="text-warning fw-bold mb-1"><i class="fa-solid fa-gift me-1"></i> Khuyến Mãi Thành Viên</h6>
                    <p class="text-white mb-0" style="font-size: 14px;">Mua 10 xu tặng 2 xu free</p>
                </div>
            </div>
            <ul class="list-unstyled text-white-50 d-flex flex-wrap gap-3 mb-0" style="font-size: 14px;">
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Tích điểm đổi quà lưu niệm</li>
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Thẻ từ nạp tiền tiện lợi</li>
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Không gian rộng rãi máy lạnh</li>
            </ul>
        </div>
    </div>

    <!-- Service Section 3: Star Coffee -->
    <div class="row align-items-center mb-0 bg-secondary-cinestar rounded-4 overflow-hidden border border-secondary-light mx-0 shadow-lg">
        <div class="col-lg-6 px-0">
            <div class="img-zoom-wrapper position-relative" style="height: 350px;">
                <img src="assets/images/service_coffee_v2.png" class="w-100 h-100 object-fit-cover transition-zoom" alt="Star Coffee">
                <div class="gradient-overlay position-absolute bottom-0 start-0 w-100" style="height: 100px; background: linear-gradient(0deg, var(--bg-secondary), transparent);"></div>
            </div>
        </div>
        <div class="col-lg-6 p-5">
            <span class="badge bg-success text-white mb-3 fw-bold text-uppercase px-3 py-2" style="font-size: 11px; letter-spacing: 1px; background-color: #16a34a !important;"><i class="fa-solid fa-mug-hot me-1"></i> Thư giãn & Ẩm thực</span>
            <h2 class="text-white fw-bold mb-3">STAR COFFEE - Góc Cà Phê Ấm Cúng</h2>
            <p class="text-white-50 fs-6 mb-4" style="line-height: 1.7;">
                Góc trò chuyện lý tưởng trước giờ chiếu phim hoặc nơi nghỉ chân mát mẻ sau những ván bowling bùng nổ. Phục vụ menu đa dạng các loại cà phê hạt xay, trà sữa, trà hoa quả tươi và bánh ngọt.
            </p>
            <div class="row mb-4">
                <div class="col-6">
                    <h6 class="text-warning fw-bold mb-1"><i class="fa-solid fa-dollar-sign me-1"></i> Mức Giá Nước</h6>
                    <p class="text-white mb-0" style="font-size: 14px;">Chỉ từ 29,000 VNĐ</p>
                </div>
                <div class="col-6">
                    <h6 class="text-warning fw-bold mb-1"><i class="fa-solid fa-percent me-1"></i> Ưu Đãi Vé Xem Phim</h6>
                    <p class="text-white mb-0" style="font-size: 14px;">Giảm 10% khi kèm vé xem phim</p>
                </div>
            </div>
            <ul class="list-unstyled text-white-50 d-flex flex-wrap gap-3 mb-0" style="font-size: 14px;">
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Wifi tốc độ cao miễn phí</li>
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Ghế sofa bọc nỉ êm ái</li>
                <li><i class="fa-solid fa-circle-check text-warning me-1"></i> Take-away mang vào phòng chiếu</li>
            </ul>
        </div>
    </div>
</div>

<style>
.bg-secondary-cinestar {
    background-color: var(--bg-secondary);
    border: 1px solid rgba(255, 255, 255, 0.05) !important;
}
.border-secondary-light {
    border-color: rgba(255, 255, 255, 0.08) !important;
}
.img-zoom-wrapper {
    overflow: hidden;
}
.transition-zoom {
    transition: transform 0.8s cubic-bezier(0.4, 0, 0.2, 1);
}
.bg-secondary-cinestar:hover .transition-zoom {
    transform: scale(1.06);
}
</style>

<?php
require_once __DIR__ . '/views/footer.php';
?>
