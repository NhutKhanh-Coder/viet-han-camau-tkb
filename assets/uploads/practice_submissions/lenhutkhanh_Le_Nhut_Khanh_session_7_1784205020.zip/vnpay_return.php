<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/Booking.php';
require_once __DIR__ . '/models/Showtime.php';

$config = require __DIR__ . '/config/vnpay.php';

$database = new Database();
$db = $database->getConnection();
$bookingModel = new Booking($db);
$showtimeModel = new Showtime($db);

$vnp_SecureHash = isset($_GET['vnp_SecureHash']) ? $_GET['vnp_SecureHash'] : '';
$vnp_ResponseCode = isset($_GET['vnp_ResponseCode']) ? $_GET['vnp_ResponseCode'] : '';
$vnp_TxnRef = isset($_GET['vnp_TxnRef']) ? $_GET['vnp_TxnRef'] : '';
$vnp_Amount = isset($_GET['vnp_Amount']) ? $_GET['vnp_Amount'] : 0;

$inputData = [];
foreach ($_GET as $key => $value) {
    if (substr($key, 0, 4) == "vnp_") {
        $inputData[$key] = $value;
    }
}

unset($inputData['vnp_SecureHash']);
ksort($inputData);

$i = 0;
$hashData = "";
foreach ($inputData as $key => $value) {
    if ($i == 1) {
        $hashData .= '&' . urlencode($key) . "=" . urlencode($value);
    } else {
        $hashData .= urlencode($key) . "=" . urlencode($value);
        $i = 1;
    }
}

$secureHash = hash_hmac('sha512', $hashData, $config['vnp_HashSecret']);

// Verify digital signature integrity
$isValidSignature = (strcasecmp($secureHash, $vnp_SecureHash) == 0);

if ($isValidSignature) {
    if ($vnp_ResponseCode == '00') {
        // Payment was successful!
        if (isset($_SESSION['pending_booking'])) {
            $pending = $_SESSION['pending_booking'];
            
            $user_id = $pending['user_id'];
            $showtimeId = $pending['showtime_id'];
            $seats_str = $pending['seats'];
            $concessions_str = $pending['concessions'];
            $total_price = $pending['total_price'];

            // Insert booking record into database
            $success = $bookingModel->create($user_id, $showtimeId, $seats_str, $total_price, $concessions_str);
            
            if ($success) {
                $booking_id = $db->lastInsertId();
                unset($_SESSION['pending_booking']); // Clear pending booking details

                // Fetch details of showtime for email ticket
                $showtime = $showtimeModel->getById($showtimeId);
                
                // Trigger email delivery
                try {
                    require_once __DIR__ . '/models/User.php';
                    $userModel = new User($db);
                    $currentUser = $userModel->getById($user_id);
                    $userEmail = ($currentUser && !empty($currentUser['email'])) ? $currentUser['email'] : ($_SESSION['user_email'] ?? 'khachhang@gmail.com');

                    require_once __DIR__ . '/services/EmailService.php';
                    $emailService = new EmailService();
                    $bookingDetails = [
                        'booking_id' => $booking_id,
                        'movie_title' => $showtime['movie_title'],
                        'cinema_name' => $showtime['cinema_name'],
                        'show_date' => $showtime['show_date'],
                        'show_time' => $showtime['show_time'],
                        'seats' => $seats_str,
                        'concessions' => $concessions_str,
                        'total_price' => $total_price
                    ];
                    $emailService->sendTicketConfirmation($userEmail, $bookingDetails);
                } catch (Exception $e) {
                    // Suppress mail exception
                }

                $_SESSION['success'] = "Đặt vé & Thanh toán trực tuyến thành công! Hóa đơn chi tiết đã được gửi đến email của bạn.";
                header('Location: profile.php');
                exit;
            } else {
                $_SESSION['error'] = "Thanh toán thành công nhưng không thể tạo hóa đơn đặt vé trong hệ thống. Vui lòng liên hệ hỗ trợ!";
                header('Location: index.php');
                exit;
            }
        } else {
            $_SESSION['error'] = "Không tìm thấy thông tin đặt vé đang chờ xử lý.";
            header('Location: index.php');
            exit;
        }
    } else {
        // Payment failed or was canceled
        $showtimeId = 0;
        if (isset($_SESSION['pending_booking'])) {
            $showtimeId = $_SESSION['pending_booking']['showtime_id'];
            unset($_SESSION['pending_booking']);
        }
        
        $_SESSION['error'] = "Thanh toán không thành công hoặc giao dịch bị hủy bỏ (Mã lỗi: " . htmlspecialchars($vnp_ResponseCode) . ")";
        if ($showtimeId > 0) {
            header('Location: booking.php?showtime_id=' . $showtimeId);
        } else {
            header('Location: index.php');
        }
        exit;
    }
} else {
    $_SESSION['error'] = "Chữ ký bảo mật thanh toán không hợp lệ (Invalid Secure Signature). Giao dịch đã bị từ chối!";
    header('Location: index.php');
    exit;
}
