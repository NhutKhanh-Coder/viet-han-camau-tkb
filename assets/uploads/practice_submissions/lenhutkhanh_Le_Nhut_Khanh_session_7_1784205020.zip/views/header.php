<?php
ob_start();
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Load core files relative to this directory
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/Movie.php';
require_once __DIR__ . '/../models/Cinema.php';
require_once __DIR__ . '/../models/Showtime.php';
require_once __DIR__ . '/../models/Booking.php';
require_once __DIR__ . '/../models/Banner.php';
require_once __DIR__ . '/../models/Concession.php';

// Instantiate DB & Models
$database = new Database();
$db = $database->getConnection();

$userModel = new User($db);
$movieModel = new Movie($db);
$cinemaModel = new Cinema($db);
$showtimeModel = new Showtime($db);
$bookingModel = new Booking($db);
$bannerModel = new Banner($db);
$concessionModel = new Concession($db);

// Fallback movie poster generator if local image is missing
function getMoviePosterUrl($image, $title = '') {
    $local_path = __DIR__ . '/../assets/images/' . $image;
    if (!empty($image) && file_exists($local_path) && is_file($local_path)) {
        return 'assets/images/' . $image;
    }
    
    // Choose gradient colors based on title hash
    $colors = [
        ['#1e1b4b', '#4338ca'], // Indigo dark to light
        ['#311042', '#7c3aed'], // Purple
        ['#450a0a', '#ef4444'], // Red
        ['#064e3b', '#10b981'], // Green
        ['#78350f', '#f59e0b'], // Amber
        ['#0f172a', '#334155'], // Slate
    ];
    $idx = abs(crc32($title)) % count($colors);
    $c1 = $colors[$idx][0];
    $c2 = $colors[$idx][1];
    
    $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 450" width="300" height="450">';
    $svg .= '<defs><linearGradient id="g'. $idx .'" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" stop-color="'. $c1 .'"/><stop offset="100%" stop-color="'. $c2 .'"/></linearGradient></defs>';
    $svg .= '<rect width="100%" height="100%" fill="url(#g'. $idx .')"/>';
    
    // Play decoration
    $svg .= '<circle cx="150" cy="180" r="50" fill="none" stroke="rgba(255,255,255,0.15)" stroke-width="6"/>';
    $svg .= '<polygon points="140,160 175,180 140,200" fill="rgba(255,255,255,0.7)"/>';
    
    // Wrap title
    $words = explode(' ', $title);
    $lines = [];
    $line = '';
    foreach ($words as $word) {
        if (strlen($line . ' ' . $word) > 15) {
            $lines[] = trim($line);
            $line = $word;
        } else {
            $line .= ' ' . $word;
        }
    }
    $lines[] = trim($line);
    
    $y = 280;
    foreach (array_slice($lines, 0, 4) as $l) {
        $svg .= '<text x="150" y="'. $y .'" fill="#ffffff" font-family="system-ui, sans-serif" font-size="18" font-weight="800" text-anchor="middle">'. htmlspecialchars($l) .'</text>';
        $y += 24;
    }
    
    $svg .= '<text x="150" y="410" fill="rgba(255,255,255,0.4)" font-family="system-ui, sans-serif" font-size="11" font-weight="700" text-anchor="middle" letter-spacing="3">CINESTAR CINEMAS</text>';
    $svg .= '</svg>';
    
    return 'data:image/svg+xml;base64,' . base64_encode($svg);
}

// Determine base URL dynamically
$protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$host = $_SERVER['HTTP_HOST'];
$uri = $_SERVER['REQUEST_URI'];
// We know the app is in /rapphim
$base_url = $protocol . '://' . $host . '/rapphim/';

// Check if user is logged in
$is_logged_in = isset($_SESSION['user_id']);
$logged_user = null;
if ($is_logged_in) {
    $logged_user = $userModel->getById($_SESSION['user_id']);
    if (!$logged_user) {
        // Session stale
        session_destroy();
        $is_logged_in = false;
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cinestar - Hệ thống rạp chiếu phim chất lượng cao</title>

    <!-- Bootstrap 5.3 CSS (official CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?php echo $base_url; ?>assets/css/style.css?v=<?php echo filemtime(__DIR__ . '/../assets/css/style.css'); ?>">
</head>
<body>

    <!-- Promo Top Bar -->
    <div class="bg-dark text-white py-2 px-3 text-center border-bottom border-secondary d-none d-md-block" style="font-size: 13px; background-color: #0c0f19 !important;">
        <span class="me-2"><i class="fa-solid fa-mobile-screen-button text-warning me-1"></i> Tải ứng dụng Cinestar Cinemas. Tra cứu lịch chiếu và đặt vé siêu nhanh</span>
        <a href="#" class="btn btn-sm btn-outline-warning py-0 px-2" style="font-size: 11px;">Mở</a>
    </div>

    <!-- Main Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-cinestar">
        <div class="container">
            <!-- Brand Logo -->
            <a class="brand-logo text-decoration-none" href="<?php echo $base_url; ?>index.php">
                <i class="fa-solid fa-star text-warning me-1"></i><span>CINE</span>STAR
            </a>
            
            <button class="navbar-toggler text-white border-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent">
                <span class="navbar-toggler-icon" style="filter: invert(1);"></span>
            </button>
            
            <div class="collapse navbar-collapse" id="navbarContent">
                <!-- Action Buttons -->
                <div class="d-flex my-2 my-lg-0 ms-lg-3 gap-2">
                    <a href="<?php echo $base_url; ?>index.php#dat-ve-nhanh" class="btn btn-yellow text-uppercase"><i class="fa-solid fa-ticket me-1"></i> Đặt vé ngay</a>
                    <a href="<?php echo $base_url; ?>concessions.php" class="btn btn-purple text-uppercase"><i class="fa-solid fa-ice-cream me-1"></i> Đặt bắp nước</a>
                </div>

                <!-- Search Bar -->
                <div class="ms-lg-4 my-2 my-lg-0 search-box-container me-auto">
                    <form action="<?php echo $base_url; ?>index.php" method="GET" class="m-0">
                        <i class="fa-solid fa-magnifying-glass"></i>
                        <input type="text" name="search" placeholder="Tìm phim..." value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    </form>
                </div>

                <!-- User Management -->
                <div class="d-flex align-items-center gap-3">
                    <?php if ($is_logged_in): ?>
                        <div class="dropdown">
                            <a class="text-white text-decoration-none dropdown-toggle fw-semibold d-flex align-items-center gap-2" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-user-astronaut text-warning fs-5"></i>
                                <span><?php echo htmlspecialchars($logged_user['fullname']); ?></span>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-dark dropdown-menu-end mt-2">
                                <li><a class="dropdown-item" href="<?php echo $base_url; ?>profile.php"><i class="fa-solid fa-address-card me-2"></i>Tài khoản của tôi</a></li>
                                <?php if ($logged_user['role'] === 'admin'): ?>
                                    <li><a class="dropdown-item text-warning" href="<?php echo $base_url; ?>admin/index.php"><i class="fa-solid fa-gauge-high me-2"></i>Trang quản trị</a></li>
                                <?php endif; ?>
                                <li><hr class="dropdown-divider border-secondary"></li>
                                <li><a class="dropdown-item text-danger" href="<?php echo $base_url; ?>logout.php"><i class="fa-solid fa-right-from-bracket me-2"></i>Đăng xuất</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo $base_url; ?>login.php" class="text-white text-decoration-none fw-semibold d-flex align-items-center gap-2">
                            <i class="fa-solid fa-circle-user fs-4 text-warning"></i>
                            <span>Đăng nhập</span>
                        </a>
                    <?php endif; ?>
                    
                    <div class="text-white-50 border-start border-secondary ps-3 d-none d-lg-block">
                        <span class="text-warning fw-bold">VN</span> | EN
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Sub Navigation Bar -->
    <div class="nav-bottom d-none d-lg-block">
        <div class="container d-flex justify-content-between">
            <div>
                <a href="<?php echo $base_url; ?>index.php#dat-ve-nhanh" class="nav-bottom-link"><i class="fa-solid fa-map-pin"></i> Chọn rạp</a>
                <a href="<?php echo $base_url; ?>index.php#phim-dang-chieu" class="nav-bottom-link"><i class="fa-solid fa-calendar-days"></i> Lịch chiếu</a>
                <a href="<?php echo $base_url; ?>promotions.php" class="nav-bottom-link">Khuyến mãi</a>
                <a href="<?php echo $base_url; ?>events.php" class="nav-bottom-link">Tổ chức sự kiện</a>
                <a href="<?php echo $base_url; ?>services.php" class="nav-bottom-link">Dịch vụ giải trí khác</a>
                <a href="<?php echo $base_url; ?>about.php" class="nav-bottom-link">Giới thiệu</a>
            </div>
            <div class="text-warning fw-semibold">
                <i class="fa-solid fa-phone me-1"></i> Hotline: 1900 2929
            </div>
        </div>
    </div>
    
    <!-- Toast Messages / Session Alerts -->
    <div class="container mt-3">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success alert-dismissible fade show bg-success text-white border-0" role="alert">
                <i class="fa-solid fa-circle-check me-2"></i><?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger alert-dismissible fade show bg-danger text-white border-0" role="alert">
                <i class="fa-solid fa-triangle-exclamation me-2"></i><?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
    </div>
