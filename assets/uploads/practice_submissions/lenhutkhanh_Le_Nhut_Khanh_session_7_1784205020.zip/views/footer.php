    <!-- Footer Section -->
    <footer class="footer-cinestar">
        <div class="container">
            <div class="row">
                <!-- Column 1: Brand Info -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <h5 class="text-uppercase"><i class="fa-solid fa-star text-warning me-1"></i> CINESTAR</h5>
                    <p class="text-white-50 mt-3" style="font-size: 14px; line-height: 1.6;">
                        Cinestar đem đến trải nghiệm điện ảnh đỉnh cao với hệ thống phòng chiếu hiện đại, âm thanh Dolby Atmos sống động và dịch vụ bắp nước đẳng cấp, giá vé siêu sinh viên.
                    </p>
                    <p class="text-white-50 mb-0" style="font-size: 14px;">
                        <i class="fa-solid fa-location-dot text-warning me-2"></i> Lầu 2, 271 Nguyễn Trãi, Q.1, TP.HCM
                    </p>
                </div>

                <!-- Column 2: Navigation Links -->
                <div class="col-lg-2 col-md-6 mb-4">
                    <h5>Liên kết</h5>
                    <div class="mt-3">
                        <a href="index.php#phim-dang-chieu" class="footer-link">Phim Đang Chiếu</a>
                        <a href="promotions.php" class="footer-link">Khuyến Mãi</a>
                        <a href="events.php" class="footer-link">Tổ Chức Sự Kiện</a>
                        <a href="services.php" class="footer-link">Dịch Vụ Khác</a>
                        <a href="about.php" class="footer-link">Giới Thiệu</a>
                    </div>
                </div>

                <!-- Column 3: Policies -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Chính sách</h5>
                    <div class="mt-3">
                        <a href="about.php" class="footer-link">Điều khoản sử dụng</a>
                        <a href="about.php" class="footer-link">Chính sách bảo mật</a>
                        <a href="about.php" class="footer-link">Quy chế hoạt động</a>
                        <a href="about.php" class="footer-link">Chính sách thanh toán</a>
                    </div>
                </div>

                <!-- Column 4: Newsletter & Socials -->
                <div class="col-lg-3 col-md-6 mb-4">
                    <h5>Kết nối</h5>
                    <div class="mt-3 d-flex gap-3 mb-4">
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;"><i class="fa-brands fa-facebook-f"></i></a>
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;"><i class="fa-brands fa-instagram"></i></a>
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;"><i class="fa-brands fa-youtube"></i></a>
                        <a href="#" class="btn btn-outline-light btn-sm rounded-circle d-flex align-items-center justify-content-center" style="width: 36px; height: 36px;"><i class="fa-brands fa-tiktok"></i></a>
                    </div>
                    <h6 class="text-white">Chăm sóc khách hàng</h6>
                    <p class="text-warning fw-bold fs-5 mb-0">1900 2929</p>
                </div>
            </div>

            <hr class="border-secondary my-4">

            <!-- Copyright -->
            <div class="row align-items-center">
                <div class="col-md-6 text-center text-md-start text-white-50" style="font-size: 13px;">
                    &copy; 2026 CINESTAR. Mọi quyền được bảo lưu.
                </div>
                <div class="col-md-6 text-center text-md-end text-white-50 mt-2 mt-md-0" style="font-size: 13px;">
                    Thiết kế bởi Đồ án môn học Kế thừa và Phát triển Web.
                </div>
            </div>
        </div>
    </footer>

    <!-- jQuery CDN (Required before Bootstrap JS & main.js) -->
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <!-- Bootstrap Bundle with Popper JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Custom Main JS -->
    <script src="<?php echo $base_url; ?>assets/js/main.js?v=<?php echo filemtime(__DIR__ . '/../assets/js/main.js'); ?>"></script>
</body>
</html>
