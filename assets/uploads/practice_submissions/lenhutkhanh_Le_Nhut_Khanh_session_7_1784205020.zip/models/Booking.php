<?php
class Booking {
    private $db;
    private $table = "bookings";

    public $id;
    public $user_id;
    public $showtime_id;
    public $seats;
    public $total_price;
    public $booking_date;

    public function __construct($db) {
        $this->db = $db;
    }

    // Book ticket
    public function create($user_id, $showtime_id, $seats, $total_price, $concessions = '') {
        $sql = "INSERT INTO " . $this->table . " (user_id, showtime_id, seats, concessions, total_price) 
                VALUES (:user_id, :showtime_id, :seats, :concessions, :total_price)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':user_id' => $user_id,
            ':showtime_id' => $showtime_id,
            ':seats' => $seats,
            ':concessions' => $concessions,
            ':total_price' => $total_price
        ]);
    }

    // Get bookings by User
    public function getByUser($user_id) {
        $sql = "SELECT b.*, s.show_date, s.show_time, s.price, m.title as movie_title, m.image as movie_image, c.name as cinema_name 
                FROM " . $this->table . " b
                JOIN showtimes s ON b.showtime_id = s.id
                JOIN movies m ON s.movie_id = m.id
                JOIN cinemas c ON s.cinema_id = c.id
                WHERE b.user_id = :user_id
                ORDER BY b.booking_date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':user_id' => $user_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get all bookings (admin view)
    public function getAll() {
        $sql = "SELECT b.*, u.username, u.fullname, s.show_date, s.show_time, m.title as movie_title, c.name as cinema_name 
                FROM " . $this->table . " b
                JOIN users u ON b.user_id = u.id
                JOIN showtimes s ON b.showtime_id = s.id
                JOIN movies m ON s.movie_id = m.id
                JOIN cinemas c ON s.cinema_id = c.id
                ORDER BY b.booking_date DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get seats already reserved for a showtime (returns a flat array of seat codes e.g. ['A1', 'A2', 'B5'])
    public function getBookedSeats($showtime_id) {
        $sql = "SELECT seats FROM " . $this->table . " WHERE showtime_id = :showtime_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':showtime_id' => $showtime_id]);
        $rows = $stmt->fetchAll(PDO::FETCH_COLUMN);

        $booked_seats = [];
        foreach ($rows as $row) {
            $seats_list = explode(',', $row);
            foreach ($seats_list as $seat) {
                $seat = trim($seat);
                if (!empty($seat)) {
                    $booked_seats[] = $seat;
                }
            }
        }
        return array_unique($booked_seats);
    }

    // Delete booking (cancel booking)
    public function delete($id) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
