<?php
class Movie {
    private $db;
    private $table = "movies";

    public $id;
    public $title;
    public $description;
    public $image;
    public $duration;
    public $release_date;
    public $rating;
    public $status;
    public $trailer_url;
    public $created_at;

    public function __construct($db) {
        $this->db = $db;
    }

    // Get all movies
    public function getAll() {
        $sql = "SELECT * FROM " . $this->table . " ORDER BY release_date DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get showing movies
    public function getShowing() {
        $sql = "SELECT * FROM " . $this->table . " WHERE status = 'showing' ORDER BY release_date DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get coming soon movies
    public function getComing() {
        $sql = "SELECT * FROM " . $this->table . " WHERE status = 'coming' ORDER BY release_date DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get movie by ID
    public function getById($id) {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Search movies by title or description, optional status filter
    public function search($keyword, $status = null) {
        $sql = "SELECT * FROM " . $this->table . " WHERE (title LIKE :keyword OR description LIKE :keyword)";
        $params = [':keyword' => '%' . $keyword . '%'];
        
        if ($status !== null && $status !== '') {
            $sql .= " AND status = :status";
            $params[':status'] = $status;
        }
        
        $sql .= " ORDER BY release_date DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Create a new movie
    public function create($title, $description, $image, $duration, $release_date, $rating, $status, $trailer_url) {
        $sql = "INSERT INTO " . $this->table . " (title, description, image, duration, release_date, rating, status, trailer_url) 
                VALUES (:title, :description, :image, :duration, :release_date, :rating, :status, :trailer_url)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':title' => $title,
            ':description' => $description,
            ':image' => $image,
            ':duration' => $duration,
            ':release_date' => $release_date,
            ':rating' => $rating,
            ':status' => $status,
            ':trailer_url' => $trailer_url
        ]);
    }

    // Update a movie
    public function update($id, $title, $description, $image, $duration, $release_date, $rating, $status, $trailer_url) {
        if (!empty($image)) {
            $sql = "UPDATE " . $this->table . " 
                    SET title = :title, description = :description, image = :image, duration = :duration, 
                        release_date = :release_date, rating = :rating, status = :status, trailer_url = :trailer_url 
                    WHERE id = :id";
            $params = [
                ':title' => $title,
                ':description' => $description,
                ':image' => $image,
                ':duration' => $duration,
                ':release_date' => $release_date,
                ':rating' => $rating,
                ':status' => $status,
                ':trailer_url' => $trailer_url,
                ':id' => $id
            ];
        } else {
            $sql = "UPDATE " . $this->table . " 
                    SET title = :title, description = :description, duration = :duration, 
                        release_date = :release_date, rating = :rating, status = :status, trailer_url = :trailer_url 
                    WHERE id = :id";
            $params = [
                ':title' => $title,
                ':description' => $description,
                ':duration' => $duration,
                ':release_date' => $release_date,
                ':rating' => $rating,
                ':status' => $status,
                ':trailer_url' => $trailer_url,
                ':id' => $id
            ];
        }
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    // Delete a movie
    public function delete($id) {
        // Fetch image to delete file
        $movie = $this->getById($id);
        if ($movie && !empty($movie['image'])) {
            $image_path = dirname(__DIR__) . "/assets/images/" . $movie['image'];
            if (file_exists($image_path) && is_file($image_path)) {
                @unlink($image_path);
            }
        }

        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
