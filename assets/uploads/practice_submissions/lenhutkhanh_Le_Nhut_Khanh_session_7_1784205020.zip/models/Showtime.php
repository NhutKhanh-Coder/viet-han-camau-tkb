<?php
class Showtime {
    private $db;
    private $table = "showtimes";

    public $id;
    public $movie_id;
    public $cinema_id;
    public $show_date;
    public $show_time;
    public $price;

    public function __construct($db) {
        $this->db = $db;
    }

    // Get all showtimes with movie and cinema info
    public function getAll() {
        $sql = "SELECT s.*, m.title as movie_title, m.image as movie_image, c.name as cinema_name 
                FROM " . $this->table . " s
                JOIN movies m ON s.movie_id = m.id
                JOIN cinemas c ON s.cinema_id = c.id
                ORDER BY s.show_date DESC, s.show_time ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get showtime details by ID
    public function getById($id) {
        $sql = "SELECT s.*, m.title as movie_title, m.image as movie_image, m.duration, m.rating, c.name as cinema_name 
                FROM " . $this->table . " s
                JOIN movies m ON s.movie_id = m.id
                JOIN cinemas c ON s.cinema_id = c.id
                WHERE s.id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create showtime (admin feature)
    public function create($movie_id, $cinema_id, $show_date, $show_time, $price) {
        $sql = "INSERT INTO " . $this->table . " (movie_id, cinema_id, show_date, show_time, price) 
                VALUES (:movie_id, :cinema_id, :show_date, :show_time, :price)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':movie_id' => $movie_id,
            ':cinema_id' => $cinema_id,
            ':show_date' => $show_date,
            ':show_time' => $show_time,
            ':price' => $price
        ]);
    }

    // Delete showtime (admin feature)
    public function delete($id) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    // Helper: Get movies available in a specific cinema
    public function getMoviesByCinema($cinema_id) {
        $sql = "SELECT DISTINCT m.* FROM movies m
                JOIN " . $this->table . " s ON m.id = s.movie_id
                WHERE s.cinema_id = :cinema_id AND s.show_date >= CURDATE()
                ORDER BY m.title ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':cinema_id' => $cinema_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Helper: Get dates available for a specific cinema and movie
    public function getDatesByCinemaAndMovie($cinema_id, $movie_id) {
        $sql = "SELECT DISTINCT s.show_date FROM " . $this->table . " s
                WHERE s.cinema_id = :cinema_id AND s.movie_id = :movie_id AND s.show_date >= CURDATE()
                ORDER BY s.show_date ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':cinema_id' => $cinema_id, ':movie_id' => $movie_id]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    // Helper: Get times and prices for a specific cinema, movie, and date
    public function getTimesByCinemaMovieAndDate($cinema_id, $movie_id, $show_date) {
        $sql = "SELECT s.id, s.show_time, s.price FROM " . $this->table . " s
                WHERE s.cinema_id = :cinema_id AND s.movie_id = :movie_id AND s.show_date = :show_date
                ORDER BY s.show_time ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':cinema_id' => $cinema_id,
            ':movie_id' => $movie_id,
            ':show_date' => $show_date
        ]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get showtimes of a movie, grouped by Cinema and Date
    public function getShowtimesForMovie($movie_id) {
        $sql = "SELECT s.id, s.show_date, s.show_time, s.price, c.id as cinema_id, c.name as cinema_name 
                FROM " . $this->table . " s
                JOIN cinemas c ON s.cinema_id = c.id
                WHERE s.movie_id = :movie_id AND s.show_date >= CURDATE()
                ORDER BY c.name ASC, s.show_date ASC, s.show_time ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':movie_id' => $movie_id]);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Group by cinema, then by date
        $grouped = [];
        foreach ($results as $row) {
            $c_id = $row['cinema_id'];
            $c_name = $row['cinema_name'];
            $date = $row['show_date'];

            if (!isset($grouped[$c_id])) {
                $grouped[$c_id] = [
                    'name' => $c_name,
                    'dates' => []
                ];
            }

            if (!isset($grouped[$c_id]['dates'][$date])) {
                $grouped[$c_id]['dates'][$date] = [];
            }

            $grouped[$c_id]['dates'][$date][] = [
                'id' => $row['id'],
                'time' => date('H:i', strtotime($row['show_time'])),
                'price' => $row['price']
            ];
        }
        return $grouped;
    }
}
?>
