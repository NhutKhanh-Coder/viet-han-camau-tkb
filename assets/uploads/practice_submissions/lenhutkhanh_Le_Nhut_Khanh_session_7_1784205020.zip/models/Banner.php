<?php
class Banner {
    private $db;
    private $table = "banners";

    public $id;
    public $movie_id;
    public $subtitle;
    public $title;
    public $description;
    public $image;
    public $sort_order;

    public function __construct($db) {
        $this->db = $db;
    }

    // Get all banners with movie details
    public function getAll() {
        $sql = "SELECT b.*, m.title as movie_title, m.trailer_url 
                FROM " . $this->table . " b
                JOIN movies m ON b.movie_id = m.id
                ORDER BY b.sort_order ASC, b.id DESC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get specific banner by ID
    public function getById($id) {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create a new banner
    public function create($movie_id, $subtitle, $title, $description, $image, $trim_seconds, $sort_order) {
        $sql = "INSERT INTO " . $this->table . " (movie_id, subtitle, title, description, image, trim_seconds, sort_order) 
                VALUES (:movie_id, :subtitle, :title, :description, :image, :trim_seconds, :sort_order)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':movie_id' => $movie_id,
            ':subtitle' => $subtitle,
            ':title' => $title,
            ':description' => $description,
            ':image' => $image,
            ':trim_seconds' => $trim_seconds,
            ':sort_order' => $sort_order
        ]);
    }

    // Update banner details
    public function update($id, $movie_id, $subtitle, $title, $description, $image, $trim_seconds, $sort_order) {
        // If image is empty, keep existing image
        if (empty($image)) {
            $sql = "UPDATE " . $this->table . " 
                    SET movie_id = :movie_id, subtitle = :subtitle, title = :title, description = :description, trim_seconds = :trim_seconds, sort_order = :sort_order 
                    WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':movie_id' => $movie_id,
                ':subtitle' => $subtitle,
                ':title' => $title,
                ':description' => $description,
                ':trim_seconds' => $trim_seconds,
                ':sort_order' => $sort_order,
                ':id' => $id
            ]);
        } else {
            $sql = "UPDATE " . $this->table . " 
                    SET movie_id = :movie_id, subtitle = :subtitle, title = :title, description = :description, image = :image, trim_seconds = :trim_seconds, sort_order = :sort_order 
                    WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':movie_id' => $movie_id,
                ':subtitle' => $subtitle,
                ':title' => $title,
                ':description' => $description,
                ':image' => $image,
                ':trim_seconds' => $trim_seconds,
                ':sort_order' => $sort_order,
                ':id' => $id
            ]);
        }
    }

    // Delete banner
    public function delete($id) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
