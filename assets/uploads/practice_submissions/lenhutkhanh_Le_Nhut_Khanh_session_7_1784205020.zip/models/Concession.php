<?php
class Concession {
    private $db;
    private $table = "concession_items";

    public $id;
    public $name;
    public $description;
    public $price;
    public $image;
    public $icon_type;

    public function __construct($db) {
        $this->db = $db;
    }

    // Get all concessions
    public function getAll() {
        $sql = "SELECT * FROM " . $this->table . " ORDER BY price ASC, id ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get specific concession by ID
    public function getById($id) {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create a new concession combo
    public function create($name, $description, $price, $icon_type, $image = null) {
        $sql = "INSERT INTO " . $this->table . " (name, description, price, icon_type, image) 
                VALUES (:name, :description, :price, :icon_type, :image)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name' => $name,
            ':description' => $description,
            ':price' => $price,
            ':icon_type' => $icon_type,
            ':image' => $image
        ]);
    }

    // Update concession details
    public function update($id, $name, $description, $price, $icon_type, $image = null) {
        if ($image === null) {
            // Keep current image
            $sql = "UPDATE " . $this->table . " 
                    SET name = :name, description = :description, price = :price, icon_type = :icon_type 
                    WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':price' => $price,
                ':icon_type' => $icon_type,
                ':id' => $id
            ]);
        } else {
            // Update image
            $sql = "UPDATE " . $this->table . " 
                    SET name = :name, description = :description, price = :price, icon_type = :icon_type, image = :image 
                    WHERE id = :id";
            $stmt = $this->db->prepare($sql);
            return $stmt->execute([
                ':name' => $name,
                ':description' => $description,
                ':price' => $price,
                ':icon_type' => $icon_type,
                ':image' => $image,
                ':id' => $id
            ]);
        }
    }

    // Delete concession
    public function delete($id) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
?>
