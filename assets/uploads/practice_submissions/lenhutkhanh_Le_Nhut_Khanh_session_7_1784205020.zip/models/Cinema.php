<?php
class Cinema {
    private $db;
    private $table = "cinemas";

    public $id;
    public $name;
    public $address;

    public function __construct($db) {
        $this->db = $db;
    }

    // Get all cinemas
    public function getAll() {
        $sql = "SELECT * FROM " . $this->table . " ORDER BY name ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Get cinema by ID
    public function getById($id) {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Create a cinema (admin feature)
    public function create($name, $address) {
        $sql = "INSERT INTO " . $this->table . " (name, address) VALUES (:name, :address)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name' => $name,
            ':address' => $address
        ]);
    }

    // Update a cinema (admin feature)
    public function update($id, $name, $address) {
        $sql = "UPDATE " . $this->table . " SET name = :name, address = :address WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':name' => $name, ':address' => $address, ':id' => $id]);
    }

    // Delete a cinema (admin feature)
    public function delete($id) {
        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    // Count showtimes linked to a cinema
    public function countShowtimes($id) {
        $sql = "SELECT COUNT(*) FROM showtimes WHERE cinema_id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetchColumn();
    }
}
?>
