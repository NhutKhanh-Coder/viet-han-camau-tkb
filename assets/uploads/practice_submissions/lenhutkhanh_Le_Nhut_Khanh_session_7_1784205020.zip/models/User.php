<?php
class User {
    private $db;
    private $table = "users";

    public $id;
    public $username;
    public $password;
    public $email;
    public $fullname;
    public $phone;
    public $role;
    public $created_at;

    public function __construct($db) {
        $this->db = $db;
    }

    // Register member
    public function register($username, $password, $email, $fullname, $phone) {
        // Check if username already exists
        $check_stmt = $this->db->prepare("SELECT id FROM " . $this->table . " WHERE username = :username OR email = :email");
        $check_stmt->execute([':username' => $username, ':email' => $email]);
        if ($check_stmt->rowCount() > 0) {
            return false; // Already exists
        }

        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO " . $this->table . " (username, password, email, fullname, phone, role) 
                VALUES (:username, :password, :email, :fullname, :phone, 'member')";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':username' => $username,
            ':password' => $hashed_password,
            ':email' => $email,
            ':fullname' => $fullname,
            ':phone' => $phone
        ]);
    }

    // Login user
    public function login($username, $password) {
        $sql = "SELECT * FROM " . $this->table . " WHERE username = :username LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':username' => $username]);

        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($password, $row['password'])) {
                // Populate model properties
                $this->id = $row['id'];
                $this->username = $row['username'];
                $this->email = $row['email'];
                $this->fullname = $row['fullname'];
                $this->phone = $row['phone'];
                $this->role = $row['role'];
                $this->created_at = $row['created_at'];
                return $row;
            }
        }
        return false;
    }

    // Get user by ID
    public function getById($id) {
        $sql = "SELECT * FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        
        if ($stmt->rowCount() > 0) {
            return $stmt->fetch(PDO::FETCH_ASSOC);
        }
        return null;
    }

    // Update profile (email, fullname, phone)
    public function updateProfile($id, $email, $fullname, $phone) {
        // Check if email is used by another user
        $check_stmt = $this->db->prepare("SELECT id FROM " . $this->table . " WHERE email = :email AND id != :id");
        $check_stmt->execute([':email' => $email, ':id' => $id]);
        if ($check_stmt->rowCount() > 0) {
            return false; // Email already taken
        }

        $sql = "UPDATE " . $this->table . " SET email = :email, fullname = :fullname, phone = :phone WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':email' => $email,
            ':fullname' => $fullname,
            ':phone' => $phone,
            ':id' => $id
        ]);
    }

    // Change Password
    public function changePassword($id, $old_password, $new_password) {
        $sql = "SELECT password FROM " . $this->table . " WHERE id = :id LIMIT 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (password_verify($old_password, $row['password'])) {
                $new_hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $update_sql = "UPDATE " . $this->table . " SET password = :password WHERE id = :id";
                $update_stmt = $this->db->prepare($update_sql);
                return $update_stmt->execute([
                    ':password' => $new_hashed,
                    ':id' => $id
                ]);
            }
        }
        return false;
    }

    // Get all users (for admin panel)
    public function getAll() {
        $sql = "SELECT * FROM " . $this->table . " ORDER BY role ASC, username ASC";
        $stmt = $this->db->query($sql);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Delete a user
    public function delete($id) {
        // First delete the user's bookings to avoid foreign key constraints
        $stmtBookings = $this->db->prepare("DELETE FROM bookings WHERE user_id = :id");
        $stmtBookings->execute([':id' => $id]);

        $sql = "DELETE FROM " . $this->table . " WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    // Update user role
    public function updateRole($id, $role) {
        $sql = "UPDATE " . $this->table . " SET role = :role WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':role' => $role, ':id' => $id]);
    }

    // Create a user account (by admin, bypasses duplicate check optionally)
    public function createByAdmin($username, $password, $email, $fullname, $phone, $role = 'member') {
        // Check for uniqueness first
        $check = $this->db->prepare("SELECT id FROM " . $this->table . " WHERE username=:u OR email=:e");
        $check->execute([':u' => $username, ':e' => $email]);
        if ($check->rowCount() > 0) return false;

        $hashed = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO " . $this->table . " (username, password, email, fullname, phone, role)
                VALUES (:username, :password, :email, :fullname, :phone, :role)";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':username' => $username,
            ':password' => $hashed,
            ':email'    => $email,
            ':fullname' => $fullname,
            ':phone'    => $phone,
            ':role'     => $role
        ]);
    }

    // Admin reset password (no old password required)
    public function adminResetPassword($id, $new_password) {
        $hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $sql = "UPDATE " . $this->table . " SET password = :password WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':password' => $hashed, ':id' => $id]);
    }

    // Admin update full user profile
    public function adminUpdateProfile($id, $email, $fullname, $phone, $role) {
        $check = $this->db->prepare("SELECT id FROM " . $this->table . " WHERE email=:e AND id!=:id");
        $check->execute([':e' => $email, ':id' => $id]);
        if ($check->rowCount() > 0) return false;

        $sql = "UPDATE " . $this->table . " SET email=:email, fullname=:fullname, phone=:phone, role=:role WHERE id=:id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':email'    => $email,
            ':fullname' => $fullname,
            ':phone'    => $phone,
            ':role'     => $role,
            ':id'       => $id
        ]);
    }
}
?>
