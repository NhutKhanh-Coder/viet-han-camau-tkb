<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/User.php';
require_once __DIR__ . '/models/Booking.php';

$database = new Database();
$db = $database->getConnection();
$userModel = new User($db);
$bookingModel = new Booking($db);

$is_logged_in = isset($_SESSION['user_id']);

// Redirect if not logged in
if (!$is_logged_in) {
    $_SESSION['error'] = "Vui lòng đăng nhập để truy cập tài khoản!";
    header('Location: login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$currentUser = $userModel->getById($user_id);

// Handle Profile Updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = isset($_POST['action']) ? $_POST['action'] : '';

    if ($action === 'update_profile') {
        $fullname = trim($_POST['fullname']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);

        if (empty($fullname) || empty($email) || empty($phone)) {
            $_SESSION['error'] = "Vui lòng điền đầy đủ họ tên, email và số điện thoại!";
        } else {
            $update = $userModel->updateProfile($user_id, $email, $fullname, $phone);
            if ($update) {
                $_SESSION['success'] = "Cập nhật thông tin tài khoản thành công!";
            } else {
                $_SESSION['error'] = "Email này đã được sử dụng bởi tài khoản khác!";
            }
        }
    } elseif ($action === 'change_password') {
        $old_pass = $_POST['old_password'];
        $new_pass = $_POST['new_password'];
        $confirm_pass = $_POST['confirm_password'];

        if (empty($old_pass) || empty($new_pass) || empty($confirm_pass)) {
            $_SESSION['error'] = "Vui lòng nhập đầy đủ thông tin mật khẩu!";
        } elseif ($new_pass !== $confirm_pass) {
            $_SESSION['error'] = "Xác nhận mật khẩu mới không khớp!";
        } else {
            $change = $userModel->changePassword($user_id, $old_pass, $new_pass);
            if ($change) {
                $_SESSION['success'] = "Đổi mật khẩu thành công!";
            } else {
                $_SESSION['error'] = "Mật khẩu cũ không chính xác!";
            }
        }
    }

    header('Location: profile.php');
    exit;
}

// Fetch Booking History
$bookings = $bookingModel->getByUser($user_id);

require_once __DIR__ . '/views/header.php';
?>

<div class="container my-5 py-4 text-white">
    <div class="row mb-5">
        <div class="col-12">
            <h2 class="fw-extrabold text-uppercase text-white border-bottom border-secondary pb-3">
                <i class="fa-solid fa-address-card text-warning me-2"></i>Tài Khoản Của Tôi
            </h2>
        </div>
    </div>

    <div class="row">
        <!-- Account Info Form -->
        <div class="col-lg-6 mb-4">
            <div class="admin-card">
                <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-user-pen me-2"></i>Thông tin cá nhân</h4>
                
                <form action="profile.php" method="POST">
                    <input type="hidden" name="action" value="update_profile">
                    
                    <div class="mb-3">
                        <label class="form-label text-white-50">Tên đăng nhập</label>
                        <input type="text" class="form-control form-control-dark bg-dark text-white-50" value="<?php echo htmlspecialchars($currentUser['username']); ?>" readonly disabled>
                        <small class="text-white-50" style="font-size: 11px;">Tên đăng nhập không thể thay đổi</small>
                    </div>

                    <div class="mb-3">
                        <label for="fullname" class="form-label text-white-50">Họ và tên</label>
                        <input type="text" class="form-control form-control-dark" id="fullname" name="fullname" value="<?php echo htmlspecialchars($currentUser['fullname']); ?>" required>
                    </div>

                    <div class="mb-3">
                        <label for="email" class="form-label text-white-50">Email</label>
                        <input type="email" class="form-control form-control-dark" id="email" name="email" value="<?php echo htmlspecialchars($currentUser['email']); ?>" required>
                    </div>

                    <div class="mb-4">
                        <label for="phone" class="form-label text-white-50">Số điện thoại</label>
                        <input type="tel" class="form-control form-control-dark" id="phone" name="phone" value="<?php echo htmlspecialchars($currentUser['phone']); ?>" required>
                    </div>

                    <button type="submit" class="btn btn-yellow text-uppercase fw-bold px-4 py-2">Lưu thay đổi</button>
                </form>
            </div>
        </div>

        <!-- Password Change Form -->
        <div class="col-lg-6 mb-4">
            <div class="admin-card">
                <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-key me-2"></i>Đổi mật khẩu</h4>
                
                <form action="profile.php" method="POST">
                    <input type="hidden" name="action" value="change_password">
                    
                    <div class="mb-3">
                        <label for="old_password" class="form-label text-white-50">Mật khẩu cũ</label>
                        <input type="password" class="form-control form-control-dark" id="old_password" name="old_password" required placeholder="Nhập mật khẩu hiện tại...">
                    </div>

                    <div class="mb-3">
                        <label for="new_password" class="form-label text-white-50">Mật khẩu mới</label>
                        <input type="password" class="form-control form-control-dark" id="new_password" name="new_password" required placeholder="Tạo mật khẩu mới...">
                    </div>

                    <div class="mb-4">
                        <label for="confirm_password" class="form-label text-white-50">Xác nhận mật khẩu mới</label>
                        <input type="password" class="form-control form-control-dark" id="confirm_password" name="confirm_password" required placeholder="Xác nhận lại mật khẩu...">
                    </div>

                    <button type="submit" class="btn btn-purple text-uppercase fw-bold px-4 py-2">Đổi mật khẩu</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Booking History Section -->
    <div class="row mt-4">
        <div class="col-12">
            <h3 class="fw-bold mb-4 text-uppercase"><i class="fa-solid fa-ticket-simple text-warning me-2"></i> Lịch Sử Đặt Vé</h3>
            
            <?php if (empty($bookings)): ?>
                <div class="alert alert-warning bg-dark text-warning border-warning py-4">
                    <i class="fa-solid fa-circle-question me-2"></i> Bạn chưa thực hiện giao dịch đặt vé nào. 
                    <a href="index.php" class="text-warning fw-bold text-decoration-none ms-1">Khám phá phim đang chiếu ngay!</a>
                </div>
            <?php else: ?>
                <div class="row g-4">
                    <?php foreach ($bookings as $booking): ?>
                        <div class="col-md-6 col-lg-4">
                            <!-- Visual Receipt ticket card representation -->
                            <div class="card bg-secondary border-secondary text-white rounded-3 shadow h-100" style="background: radial-gradient(circle at 0 50%, transparent 12px, #121824 13px) 0 50%, radial-gradient(circle at 100% 50%, transparent 12px, #121824 13px) 100% 50%; background-repeat: no-repeat; background-size: 51% 100%;">
                                <div class="card-body p-4 d-flex flex-column justify-content-between">
                                    <div>
                                        <div class="d-flex justify-content-between align-items-center mb-3">
                                            <span class="badge bg-purple px-2 py-1" style="font-size: 10px; background-color: var(--accent-purple);">MÃ VÉ: #<?php echo $booking['id']; ?></span>
                                            <span class="text-white-50" style="font-size: 11px;"><?php echo date('d/m/Y H:i', strtotime($booking['booking_date'])); ?></span>
                                        </div>
                                        
                                        <h5 class="card-title fw-bold text-warning mb-3 text-truncate"><?php echo htmlspecialchars($booking['movie_title']); ?></h5>
                                        
                                        <div class="mb-2" style="font-size: 14px;">
                                            <span class="text-white-50">Rạp:</span> 
                                            <span class="fw-semibold ms-1"><?php echo htmlspecialchars($booking['cinema_name']); ?></span>
                                        </div>
                                        
                                        <div class="mb-2" style="font-size: 14px;">
                                            <span class="text-white-50">Suất chiếu:</span> 
                                            <span class="fw-bold text-info ms-1"><?php echo date('H:i', strtotime($booking['show_time'])); ?></span>
                                            <span class="text-white-50 ms-2">ngày</span>
                                            <span class="fw-bold text-info ms-1"><?php echo date('d/m/Y', strtotime($booking['show_date'])); ?></span>
                                        </div>
                                        
                                        <div class="mb-2" style="font-size: 14px;">
                                            <span class="text-white-50">Ghế ngồi:</span> 
                                            <span class="fw-extrabold text-warning ms-1"><?php echo htmlspecialchars($booking['seats']); ?></span>
                                        </div>
                                        
                                        <?php if (!empty($booking['concessions'])): ?>
                                        <div class="mb-2" style="font-size: 14px;">
                                            <span class="text-white-50">Bắp nước:</span> 
                                            <span class="fw-semibold text-white ms-1"><?php echo htmlspecialchars($booking['concessions']); ?></span>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div class="border-top border-secondary border-dashed pt-3 mt-3 d-flex justify-content-between align-items-center">
                                        <span class="text-white-50" style="font-size: 13px;">Tổng tiền thanh toán:</span>
                                        <span class="fw-extrabold text-warning fs-5"><?php echo number_format($booking['total_price'], 0, ',', '.'); ?> đ</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/views/footer.php';
?>
