<?php
$_SERVER['HTTP_HOST'] = 'localhost';
$_SERVER['REQUEST_URI'] = '/rapphim/index.php';
$_SERVER['HTTPS'] = 'off';
$_SERVER['REQUEST_METHOD'] = 'GET';
$_GET = [];
ob_start();
include __DIR__ . '/index.php';
$html = ob_get_clean();

// Extract hero-carousel section
$start = strpos($html, 'hero-carousel');
if ($start !== false) {
    // Go back to find the opening <div
    $start = strrpos(substr($html, 0, $start), '<div');
    $chunk = substr($html, $start, 4000);
    echo $chunk;
} else {
    echo "hero-carousel NOT FOUND in output!\n";
    echo "First 500 chars:\n" . substr($html, 0, 500);
}
