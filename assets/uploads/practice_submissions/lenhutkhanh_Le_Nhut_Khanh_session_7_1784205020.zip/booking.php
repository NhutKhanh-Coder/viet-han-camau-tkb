<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/Showtime.php';
require_once __DIR__ . '/models/Booking.php';
require_once __DIR__ . '/models/Concession.php';
require_once __DIR__ . '/models/User.php';

$database = new Database();
$db = $database->getConnection();
$showtimeModel = new Showtime($db);
$bookingModel = new Booking($db);
$concessionModel = new Concession($db);
$userModel = new User($db);

$is_logged_in = isset($_SESSION['user_id']);

// Redirect if not logged in
if (!$is_logged_in) {
    $_SESSION['error'] = "Vui lòng đăng nhập trước khi tiến hành đặt vé!";
    header('Location: login.php');
    exit;
}

$showtimeId = isset($_GET['showtime_id']) ? intval($_GET['showtime_id']) : 0;
if ($showtimeId <= 0) {
    header('Location: index.php');
    exit;
}

// Fetch showtime details
$showtime = $showtimeModel->getById($showtimeId);
if (!$showtime) {
    header('Location: index.php');
    exit;
}

$base_price = floatval($showtime['price']);
$bookedSeats = $bookingModel->getBookedSeats($showtimeId);

// Fetch all concessions from DB
$all_concessions = $concessionModel->getAll();

// Handle Ticket Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $seats_str = isset($_POST['selected_seats']) ? trim($_POST['selected_seats']) : '';
    $payment_method = isset($_POST['payment_method']) ? trim($_POST['payment_method']) : 'local';
    
    if (empty($seats_str)) {
        $_SESSION['error'] = "Vui lòng chọn ít nhất một ghế trước khi thanh toán!";
        header('Location: booking.php?showtime_id=' . $showtimeId);
        exit;
    }

    $seats_array = explode(',', $seats_str);
    $total_price = 0;
    
    // Server-side calculation of the price to prevent tampering
    foreach ($seats_array as $seat) {
        $seat = trim($seat);
        $row = substr($seat, 0, 1);
        $is_vip = in_array($row, ['E', 'F', 'G']);
        $total_price += $base_price + ($is_vip ? 20000 : 0);
    }

    // Process Concessions (Bắp Nước) dynamically
    $concession_items = [];
    $concessions_price = 0;
    
    foreach ($all_concessions as $item) {
        $input_name = 'concession_qty_' . $item['id'];
        $qty = isset($_POST[$input_name]) ? max(0, intval($_POST[$input_name])) : 0;
        if ($qty > 0) {
            $concession_items[] = "{$item['name']} x{$qty}";
            $concessions_price += $qty * floatval($item['price']);
        }
    }
    $concessions_str = implode(', ', $concession_items);
    $total_price += $concessions_price;

    if ($payment_method === 'vnpay') {
        // Save pending booking details in session
        $_SESSION['pending_booking'] = [
            'user_id' => $user_id,
            'showtime_id' => $showtimeId,
            'seats' => $seats_str,
            'concessions' => $concessions_str,
            'total_price' => $total_price
        ];
        
        // Redirect to VNPAY payment gateway initializer
        header('Location: vnpay_pay.php');
        exit;
    } else {
        // Save Booking locally (Simulated)
        $success = $bookingModel->create($user_id, $showtimeId, $seats_str, $total_price, $concessions_str);
        if ($success) {
            // Get the last inserted booking ID
            $booking_id = $db->lastInsertId();
            
            // Send email confirmation in background (we will implement this service next)
            try {
                require_once __DIR__ . '/services/EmailService.php';
                $emailService = new EmailService();
                $bookingDetails = [
                    'booking_id' => $booking_id,
                    'movie_title' => $showtime['movie_title'],
                    'cinema_name' => $showtime['cinema_name'],
                    'show_date' => $showtime['show_date'],
                    'show_time' => $showtime['show_time'],
                    'seats' => $seats_str,
                    'concessions' => $concessions_str,
                    'total_price' => $total_price
                ];
                $currentUser = $userModel->getById($user_id);
                $userEmail = ($currentUser && !empty($currentUser['email'])) ? $currentUser['email'] : ($_SESSION['user_email'] ?? 'khachhang@gmail.com');
                $emailService->sendTicketConfirmation($userEmail, $bookingDetails);
            } catch (Exception $e) {
                // Suppress email errors to not break booking experience
            }

            $_SESSION['success'] = "Đặt vé thành công! Hóa đơn chi tiết đã được gửi đến email của bạn.";
            header('Location: profile.php');
            exit;
        } else {
            $_SESSION['error'] = "Có lỗi xảy ra khi xử lý giao dịch. Vui lòng thử lại!";
            header('Location: booking.php?showtime_id=' . $showtimeId);
            exit;
        }
    }
}

require_once __DIR__ . '/views/header.php';

$ratingClass = strtolower(str_replace(' ', '', $showtime['rating']));
if (!in_array($ratingClass, ['p', 't16', 't18', 'k'])) $ratingClass = 'other';
?>

<div class="container my-5 py-4">
    <div class="row">
        <!-- Seat Map Column -->
        <div class="col-lg-8 mb-5">
            <h3 class="fw-bold mb-4 text-uppercase text-white">
                <i class="fa-solid fa-chair text-warning me-2"></i>Chọn Ghế Ngồi
            </h3>
            
            <div class="seat-map-container">
                <!-- Cinema Screen Header -->
                <div class="screen text-uppercase">MÀN HÌNH CHÍNH</div>
                
                <!-- Seat Rows -->
                <div class="seats-area">
                    <?php
                    $rows = ['A', 'B', 'C', 'D', 'E', 'F', 'G'];
                    foreach ($rows as $row):
                    ?>
                        <div class="seat-row">
                            <span class="text-white-50 fw-bold me-3 align-self-center" style="width: 20px;"><?php echo $row; ?></span>
                            <?php 
                            for ($num = 1; $num <= 10; $num++):
                                $seatCode = $row . $num;
                                $is_vip = in_array($row, ['E', 'F', 'G']);
                                $seat_price = $base_price + ($is_vip ? 20000 : 0);
                                $is_booked = in_array($seatCode, $bookedSeats);
                                
                                $class = 'seat';
                                if ($is_vip) $class .= ' vip';
                                if ($is_booked) $class .= ' booked';
                            ?>
                                <div class="<?php echo $class; ?>" 
                                     data-seat="<?php echo $seatCode; ?>" 
                                     data-price="<?php echo $seat_price; ?>"
                                     title="<?php echo $seatCode; ?> - <?php echo number_format($seat_price, 0, ',', '.'); ?> đ">
                                    <?php echo $num; ?>
                                </div>
                            <?php endfor; ?>
                            <span class="text-white-50 fw-bold ms-3 align-self-center" style="width: 20px;"><?php echo $row; ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>

                <!-- Seat Legend -->
                <div class="seat-legend">
                    <div class="legend-item">
                        <div class="seat"></div>
                        <span>Ghế Thường</span>
                    </div>
                    <div class="legend-item">
                        <div class="seat vip"></div>
                        <span>Ghế VIP (+20.000 đ)</span>
                    </div>
                    <div class="legend-item">
                        <div class="seat selected"></div>
                        <span>Đang Chọn</span>
                    </div>
                    <div class="legend-item">
                        <div class="seat booked"></div>
                        <span>Đã Bán</span>
                    </div>
                </div>
            </div>

            <!-- Đặt Bắp Nước Section -->
            <div class="admin-card text-white mt-4 p-4">
                <h4 class="fw-bold mb-4 text-warning"><i class="fa-solid fa-ice-cream me-2"></i>Chọn Bắp Nước (Concessions)</h4>
                <div class="row g-3">
                    <?php if (!empty($all_concessions)): ?>
                        <?php foreach ($all_concessions as $item): ?>
                            <div class="col-md-4 mb-3">
                                <div class="card bg-dark border-secondary h-100 p-3 text-center">
                                    <div class="mb-3 d-flex align-items-center justify-content-center" style="height: 80px;">
                                        <?php if (!empty($item['image']) && file_exists('assets/images/' . $item['image'])): ?>
                                            <img src="assets/images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="img-fluid rounded" style="max-height: 80px; object-fit: contain;">
                                        <?php else: ?>
                                            <?php if ($item['icon_type'] === 'solo'): ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="80" height="80" class="mx-auto d-block">
                                                    <path d="M30,30 L35,80 L65,80 L70,30 Z" fill="#b91c1c" />
                                                    <path d="M30,30 Q50,40 70,30 L67,40 Q50,30 33,40 Z" fill="#f59e0b" />
                                                    <circle cx="35" cy="20" r="10" fill="#fef08a" />
                                                    <circle cx="50" cy="15" r="12" fill="#fef08a" />
                                                    <circle cx="65" cy="20" r="10" fill="#fef08a" />
                                                    <circle cx="45" cy="25" r="8" fill="#fef08a" />
                                                    <circle cx="55" cy="25" r="8" fill="#fef08a" />
                                                    <polygon points="50,45 53,52 60,52 55,56 57,63 50,59 43,63 45,56 40,52 47,52" fill="#facc15" />
                                                </svg>
                                            <?php elseif ($item['icon_type'] === 'twin'): ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="80" height="80" class="mx-auto d-block">
                                                    <path d="M25,30 L30,80 L55,80 L60,30 Z" fill="#1e3a8a" />
                                                    <circle cx="30" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="42" cy="15" r="10" fill="#fef08a" />
                                                    <circle cx="55" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="38" cy="24" r="6" fill="#fef08a" />
                                                    <circle cx="48" cy="24" r="6" fill="#fef08a" />
                                                    <path d="M62,40 L66,80 L82,80 L86,40 Z" fill="#b91c1c" />
                                                    <line x1="74" y1="40" x2="65" y2="15" stroke="#fff" stroke-width="4" stroke-linecap="round" />
                                                    <polygon points="42,45 44,50 49,50 45,53 47,58 42,55 37,58 39,53 35,50 40,50" fill="#facc15" />
                                                </svg>
                                            <?php else: ?>
                                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="80" height="80" class="mx-auto d-block">
                                                    <path d="M20,30 L25,80 L50,80 L55,30 Z" fill="#7c3aed" />
                                                    <circle cx="25" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="37" cy="15" r="10" fill="#fef08a" />
                                                    <circle cx="50" cy="20" r="8" fill="#fef08a" />
                                                    <path d="M50,30 L55,80 L75,80 L80,30 Z" fill="#047857" />
                                                    <circle cx="55" cy="20" r="8" fill="#fef08a" />
                                                    <circle cx="65" cy="15" r="10" fill="#fef08a" />
                                                    <circle cx="75" cy="20" r="8" fill="#fef08a" />
                                                    <line x1="72" y1="30" x2="85" y2="10" stroke="#fff" stroke-width="3" stroke-linecap="round" />
                                                    <polygon points="37,45 39,50 44,50 40,53 42,58 37,55 32,58 34,53 30,50 35,50" fill="#facc15" />
                                                    <polygon points="65,45 67,50 72,50 68,53 70,58 65,55 60,58 62,53 58,50 63,50" fill="#facc15" />
                                                </svg>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                    <h5 class="fw-bold"><?php echo htmlspecialchars($item['name']); ?></h5>
                                    <p class="text-white-50" style="font-size: 13px; min-height: 38px;"><?php echo htmlspecialchars($item['description']); ?></p>
                                    <div class="fw-extrabold text-warning fs-5 mb-3"><?php echo number_format($item['price'], 0, ',', '.'); ?> đ</div>
                                    <div class="d-flex justify-content-center align-items-center gap-2">
                                        <button type="button" class="btn btn-sm btn-outline-light rounded-circle px-2 py-1 concession-minus" data-target="<?php echo $item['id']; ?>">-</button>
                                        <span class="fw-bold px-2" id="concession-<?php echo $item['id']; ?>-qty-display" style="font-size: 16px;">0</span>
                                        <button type="button" class="btn btn-sm btn-outline-light rounded-circle px-2 py-1 concession-plus" data-target="<?php echo $item['id']; ?>">+</button>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-12 text-center text-white-50 py-3">
                            <p>Rạp hiện tại không có combo bắp nước đi kèm.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Sidebar Invoice / Movie Info Column -->
        <div class="col-lg-4">
            <div class="ticket-summary-card text-white">
                <div class="text-center mb-4">
                    <h4 class="fw-bold text-uppercase border-bottom border-secondary pb-3 text-warning">Thông Tin Vé</h4>
                </div>
                
                <div class="mb-3 d-flex align-items-start gap-3">
                    <div class="rounded overflow-hidden border border-secondary" style="width: 70px;">
                        <img src="<?php echo getMoviePosterUrl($showtime['movie_image'], $showtime['movie_title']); ?>" alt="" class="w-100">
                    </div>
                    <div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($showtime['movie_title']); ?></h5>
                        <span class="rating-badge position-static <?php echo $ratingClass; ?> py-0 px-2 d-inline-block" style="font-size: 10px;">2D | <?php echo $showtime['rating']; ?></span>
                        <div class="text-white-50 mt-1" style="font-size: 13px;"><?php echo $showtime['duration']; ?> phút</div>
                    </div>
                </div>

                <div class="border-top border-secondary py-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-white-50">Rạp chiếu:</span>
                        <span class="fw-semibold"><?php echo htmlspecialchars($showtime['cinema_name']); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-white-50">Ngày chiếu:</span>
                        <span class="fw-semibold"><?php echo date('d/m/Y', strtotime($showtime['show_date'])); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-white-50">Suất chiếu:</span>
                        <span class="fw-semibold text-warning"><?php echo date('H:i', strtotime($showtime['show_time'])); ?></span>
                    </div>
                </div>

                <div class="border-top border-secondary py-3">
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-white-50">Ghế đã chọn:</span>
                        <span id="selected-seat-names" class="fw-bold text-warning">Chưa chọn</span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span class="text-white-50">Số lượng:</span>
                        <span id="seat-count" class="fw-semibold">0</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="text-white-50">Bắp nước:</span>
                        <span id="selected-concessions-display" class="fw-bold text-warning">0 đ</span>
                    </div>
                </div>

                <div class="border-top border-secondary py-3 mb-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <span class="fs-5 fw-bold text-white">Tổng cộng:</span>
                        <span id="total-price-display" class="fs-4 fw-extrabold text-warning">0 đ</span>
                    </div>
                </div>

                <!-- Form submission -->
                <form id="booking-form" action="booking.php?showtime_id=<?php echo $showtimeId; ?>" method="POST">
                    <input type="hidden" name="selected_seats" id="selected_seats" value="">
                    <?php foreach ($all_concessions as $item): ?>
                        <input type="hidden" name="concession_qty_<?php echo $item['id']; ?>" id="form-concession-<?php echo $item['id']; ?>-qty" value="0">
                    <?php endforeach; ?>

                    <!-- Payment Method Selector -->
                    <div class="border-top border-secondary py-3 mb-3">
                        <span class="text-white-50 d-block mb-3" style="font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Phương Thức Thanh Toán</span>
                        
                        <div class="form-check mb-3 p-3 rounded bg-dark border border-secondary" style="cursor: pointer; transition: all 0.2s ease;">
                            <input class="form-check-input ms-0 me-3" type="radio" name="payment_method" id="payment_local" value="local" checked style="cursor: pointer;">
                            <label class="form-check-label text-white fw-semibold" for="payment_local" style="cursor: pointer; font-size: 14px;">
                                <i class="fa-solid fa-circle-check text-success me-2"></i>Thanh toán giả lập (Ghi nhận ngay)
                            </label>
                            <small class="d-block text-white-50 mt-1 ms-4" style="font-size: 12px;">Thích hợp để thử nghiệm nhanh mà không cần thẻ ngân hàng.</small>
                        </div>
                        
                        <div class="form-check p-3 rounded bg-dark border border-secondary" style="cursor: pointer; transition: all 0.2s ease;">
                            <input class="form-check-input ms-0 me-3" type="radio" name="payment_method" id="payment_vnpay" value="vnpay" style="cursor: pointer;">
                            <label class="form-check-label text-white fw-semibold" for="payment_vnpay" style="cursor: pointer; font-size: 14px;">
                                <i class="fa-solid fa-credit-card text-warning me-2"></i>Cổng thanh toán VNPAY (Sandbox)
                            </label>
                            <small class="d-block text-white-50 mt-1 ms-4" style="font-size: 12px;">Kết nối trực tiếp đến cổng thanh toán test của VNPAY.</small>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-yellow w-100 text-uppercase py-3 fw-bold fs-6">
                        <i class="fa-solid fa-credit-card me-2"></i>Xác Nhận Đặt Vé
                    </button>
                </form>
                
                <div class="text-center mt-3">
                    <a href="movie-detail.php?id=<?php echo $showtime['movie_id']; ?>" class="text-white-50 text-decoration-none" style="font-size: 13px;">
                        <i class="fa-solid fa-circle-chevron-left me-1"></i>Thay đổi suất chiếu
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
window.concessionPrices = {
    <?php foreach ($all_concessions as $item): ?>
        "concession_<?php echo $item['id']; ?>": <?php echo floatval($item['price']); ?>,
    <?php endforeach; ?>
};
</script>

<?php
require_once __DIR__ . '/views/footer.php';
?>
