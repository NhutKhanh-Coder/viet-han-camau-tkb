<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require_once __DIR__ . '/PHPMailer/Exception.php';
require_once __DIR__ . '/PHPMailer/PHPMailer.php';
require_once __DIR__ . '/PHPMailer/SMTP.php';

class EmailService {
    private $config;

    public function __construct() {
        $this->config = require __DIR__ . '/../config/mail.php';
    }

    /**
     * Send HTML ticket purchase confirmation receipt
     * 
     * @param string $userEmail
     * @param array $bookingDetails
     * @return bool
     */
    public function sendTicketConfirmation($userEmail, $bookingDetails) {
        // Don't send if default email template is left unchanged
        if ($this->config['smtp_username'] === 'your-email@gmail.com') {
            return false;
        }

        $mail = new PHPMailer(true);

        try {
            // SMTP Server configurations
            $mail->isSMTP();
            $mail->Host       = $this->config['smtp_host'];
            $mail->SMTPAuth   = $this->config['smtp_auth'];
            $mail->Username   = $this->config['smtp_username'];
            $mail->Password   = $this->config['smtp_password'];
            $mail->SMTPSecure = $this->config['smtp_secure'];
            $mail->Port       = $this->config['smtp_port'];
            $mail->CharSet    = 'UTF-8';

            // Recipients
            $mail->setFrom($this->config['from_email'], $this->config['from_name']);
            $mail->addAddress($userEmail);

            // Construct booking properties
            $bookingId = $bookingDetails['booking_id'];
            $movieTitle = htmlspecialchars($bookingDetails['movie_title']);
            $cinemaName = htmlspecialchars($bookingDetails['cinema_name']);
            $showDate = date('d/m/Y', strtotime($bookingDetails['show_date']));
            $showTime = date('H:i', strtotime($bookingDetails['show_time']));
            $seats = htmlspecialchars($bookingDetails['seats']);
            $concessions = !empty($bookingDetails['concessions']) ? htmlspecialchars($bookingDetails['concessions']) : 'Không có';
            $totalPrice = number_format($bookingDetails['total_price'], 0, ',', '.') . ' đ';

            // HTML Body layout - Premium Cinestar theme
            $htmlContent = "
            <html>
            <body style='font-family: Arial, sans-serif; background-color: #0f172a; color: #f8fafc; margin: 0; padding: 20px;'>
                <div style='max-width: 600px; margin: 0 auto; background-color: #1e293b; border-radius: 12px; overflow: hidden; border: 1px solid #334155; box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);'>
                    
                    <!-- Header -->
                    <div style='background: linear-gradient(135deg, #7c3aed, #b91c1c); padding: 30px; text-align: center; border-bottom: 3px solid #f59e0b;'>
                        <h1 style='margin: 0; color: #ffffff; font-size: 24px; text-transform: uppercase; letter-spacing: 2px;'>CINESTAR CINEMAS</h1>
                        <p style='margin: 5px 0 0 0; color: #fcd34d; font-size: 14px; font-weight: bold;'>XÁC NHẬN ĐẶT VÉ THÀNH CÔNG</p>
                    </div>

                    <!-- Main Body -->
                    <div style='padding: 30px;'>
                        <p style='font-size: 16px; line-height: 1.5; color: #cbd5e1; margin-top: 0;'>Chào bạn,</p>
                        <p style='font-size: 15px; line-height: 1.5; color: #cbd5e1;'>Cảm ơn bạn đã lựa chọn dịch vụ đặt vé trực tuyến tại <strong>Cinestar Cinemas Clone</strong>. Dưới đây là thông tin chi tiết về vé xem phim của bạn:</p>
                        
                        <!-- Ticket Information Box -->
                        <div style='background-color: #0f172a; border-radius: 8px; padding: 20px; border-left: 4px solid #f59e0b; margin: 25px 0;'>
                            <table style='width: 100%; border-collapse: collapse;'>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px; width: 35%;'>Mã hóa đơn:</td>
                                    <td style='padding: 8px 0; color: #ffffff; font-size: 14px; font-weight: bold;'>#{$bookingId}</td>
                                </tr>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px;'>Tên phim:</td>
                                    <td style='padding: 8px 0; color: #fcd34d; font-size: 14px; font-weight: bold;'>{$movieTitle}</td>
                                </tr>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px;'>Rạp chiếu:</td>
                                    <td style='padding: 8px 0; color: #ffffff; font-size: 14px;'>{$cinemaName}</td>
                                </tr>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px;'>Ngày chiếu:</td>
                                    <td style='padding: 8px 0; color: #ffffff; font-size: 14px;'>{$showDate}</td>
                                </tr>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px;'>Suất chiếu:</td>
                                    <td style='padding: 8px 0; color: #fcd34d; font-size: 14px; font-weight: bold;'>{$showTime}</td>
                                </tr>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px;'>Ghế ngồi:</td>
                                    <td style='padding: 8px 0; color: #38bdf8; font-size: 14px; font-weight: bold;'>{$seats}</td>
                                </tr>
                                <tr>
                                    <td style='padding: 8px 0; color: #94a3b8; font-size: 14px;'>Bắp nước:</td>
                                    <td style='padding: 8px 0; color: #ffffff; font-size: 14px;'>{$concessions}</td>
                                </tr>
                                <tr style='border-top: 1px solid #334155;'>
                                    <td style='padding: 12px 0 0 0; color: #ffffff; font-size: 16px; font-weight: bold;'>TỔNG CỘNG:</td>
                                    <td style='padding: 12px 0 0 0; color: #f59e0b; font-size: 18px; font-weight: 900;'>{$totalPrice}</td>
                                </tr>
                            </table>
                        </div>

                        <p style='font-size: 14px; color: #ef4444; font-weight: bold; background-color: rgba(239, 68, 68, 0.1); padding: 10px; border-radius: 6px; border: 1px solid rgba(239, 68, 68, 0.2); text-align: center; margin-bottom: 25px;'>
                            * Vui lòng cung cấp Mã hóa đơn này tại quầy vé để nhận vé giấy trước giờ chiếu ít nhất 15 phút.
                        </p>
                        
                        <p style='font-size: 14px; line-height: 1.5; color: #94a3b8; margin-bottom: 0;'>
                            Chúc bạn có những giây phút thư giãn tuyệt vời tại rạp!<br>
                            Ban quản trị rạp <strong>Cinestar Cinemas Clone</strong>.
                        </p>
                    </div>

                    <!-- Footer -->
                    <div style='background-color: #0f172a; padding: 20px; text-align: center; font-size: 12px; color: #64748b; border-top: 1px solid #334155;'>
                        <p style='margin: 0;'>Email này được gửi tự động từ hệ thống Cinestar Clone. Vui lòng không trả lời thư này.</p>
                        <p style='margin: 5px 0 0 0;'>&copy; 2026 Cinestar Clone Project. All rights reserved.</p>
                    </div>
                </div>
            </body>
            </html>
            ";

            $mail->isHTML(true);
            $mail->Subject = 'Xác nhận đặt vé xem phim thành công - Cinestar Clone';
            $mail->Body    = $htmlContent;

            $mail->send();
            return true;
        } catch (Exception $e) {
            error_log("PHPMailer Error: " . $mail->ErrorInfo);
            return false;
        }
    }
}
