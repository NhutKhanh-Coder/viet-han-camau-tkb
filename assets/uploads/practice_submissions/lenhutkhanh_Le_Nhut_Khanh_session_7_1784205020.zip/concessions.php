<?php
require_once __DIR__ . '/views/header.php';

// Fetch concession combos dynamically from database using OOP model
$items = $concessionModel->getAll();
?>

<!-- Hero Banner Concessions -->
<div class="movie-detail-banner" style="background-image: url('https://images.unsplash.com/photo-1513106580091-1d82408b8cd6?q=80&w=2076&auto=format&fit=crop'); min-height: 250px;">
    <div class="container movie-detail-content text-white text-center py-4">
        <h1 class="fw-extrabold text-uppercase text-white mb-2"><span class="text-warning">Combo</span> Bắp Nước</h1>
        <p class="text-white-50 fs-5 mx-auto" style="max-width: 700px;">Bắp thơm giòn tan, nước ngọt cực đã. Đặt mua kèm khi mua vé xem phim trực tuyến để nhận ưu đãi tiết kiệm tới 20% so với mua trực tiếp tại quầy!</p>
    </div>
</div>

<!-- Concessions Grid Section -->
<div class="container my-5 py-3">
    <div class="section-title-container mb-5">
        <h2 class="section-title text-white">Menu Combo Tiết Kiệm</h2>
    </div>

    <div class="row g-4 justify-content-center">
        <?php if (!empty($items)): ?>
            <?php foreach ($items as $item): ?>
                <!-- Combo Card -->
                <div class="col-lg-4 col-md-6 mb-4">
                    <div class="movie-card text-center text-white h-100 p-4" style="background-color: var(--bg-secondary); border: 1px solid rgba(255, 255, 255, 0.05); transition: all 0.3s ease;">
                        <div class="mb-4 d-flex align-items-center justify-content-center" style="height: 120px;">
                            <?php if (!empty($item['image']) && file_exists('assets/images/' . $item['image'])): ?>
                                <img src="assets/images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="img-fluid rounded" style="max-height: 120px; object-fit: contain;">
                            <?php else: ?>
                                <?php if ($item['icon_type'] === 'solo'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="120" height="120" class="mx-auto d-block">
                                        <path d="M30,30 L35,80 L65,80 L70,30 Z" fill="#b91c1c" />
                                        <path d="M30,30 Q50,40 70,30 L67,40 Q50,30 33,40 Z" fill="#f59e0b" />
                                        <circle cx="35" cy="20" r="10" fill="#fef08a" />
                                        <circle cx="50" cy="15" r="12" fill="#fef08a" />
                                        <circle cx="65" cy="20" r="10" fill="#fef08a" />
                                        <circle cx="45" cy="25" r="8" fill="#fef08a" />
                                        <circle cx="55" cy="25" r="8" fill="#fef08a" />
                                        <polygon points="50,45 53,52 60,52 55,56 57,63 50,59 43,63 45,56 40,52 47,52" fill="#facc15" />
                                    </svg>
                                <?php elseif ($item['icon_type'] === 'twin'): ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="120" height="120" class="mx-auto d-block">
                                        <path d="M25,30 L30,80 L55,80 L60,30 Z" fill="#1e3a8a" />
                                        <circle cx="30" cy="20" r="8" fill="#fef08a" />
                                        <circle cx="42" cy="15" r="10" fill="#fef08a" />
                                        <circle cx="55" cy="20" r="8" fill="#fef08a" />
                                        <circle cx="38" cy="24" r="6" fill="#fef08a" />
                                        <circle cx="48" cy="24" r="6" fill="#fef08a" />
                                        <path d="M62,40 L66,80 L82,80 L86,40 Z" fill="#b91c1c" />
                                        <line x1="74" y1="40" x2="65" y2="15" stroke="#fff" stroke-width="4" stroke-linecap="round" />
                                        <polygon points="42,45 44,50 49,50 45,53 47,58 42,55 37,58 39,53 35,50 40,50" fill="#facc15" />
                                    </svg>
                                <?php else: ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="120" height="120" class="mx-auto d-block">
                                        <path d="M20,30 L25,80 L50,80 L55,30 Z" fill="#7c3aed" />
                                        <circle cx="25" cy="20" r="8" fill="#fef08a" />
                                        <circle cx="37" cy="15" r="10" fill="#fef08a" />
                                        <circle cx="50" cy="20" r="8" fill="#fef08a" />
                                        <path d="M50,30 L55,80 L75,80 L80,30 Z" fill="#047857" />
                                        <circle cx="55" cy="20" r="8" fill="#fef08a" />
                                        <circle cx="65" cy="15" r="10" fill="#fef08a" />
                                        <circle cx="75" cy="20" r="8" fill="#fef08a" />
                                        <line x1="72" y1="30" x2="85" y2="10" stroke="#fff" stroke-width="3" stroke-linecap="round" />
                                        <polygon points="37,45 39,50 44,50 40,53 42,58 37,55 32,58 34,53 30,50 35,50" fill="#facc15" />
                                        <polygon points="65,45 67,50 72,50 68,53 70,58 65,55 60,58 62,53 58,50 63,50" fill="#facc15" />
                                    </svg>
                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                        <h3 class="fw-bold mb-2"><?php echo htmlspecialchars($item['name']); ?></h3>
                        <p class="text-white-50 px-2 mb-4" style="font-size: 14px; min-height: 45px;"><?php echo htmlspecialchars($item['description']); ?></p>
                        <div class="fw-extrabold text-warning fs-3 mb-4"><?php echo number_format($item['price'], 0, ',', '.'); ?> đ</div>
                        <a href="index.php#dat-ve-nhanh" class="btn btn-yellow text-uppercase fw-bold w-100 py-3"><i class="fa-solid fa-ticket me-1"></i>Đặt vé kèm Combo</a>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="col-12 text-center text-white-50 py-5">
                <i class="fa-solid fa-cookie-bite fs-1 mb-3 text-warning"></i>
                <p>Hiện tại rạp chưa mở bán gói combo bắp nước nào. Vui lòng quay lại sau!</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
require_once __DIR__ . '/views/footer.php';
?>
