<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/config/Database.php';
require_once __DIR__ . '/models/User.php';

$database = new Database();
$db = $database->getConnection();
$userModel = new User($db);

$is_logged_in = isset($_SESSION['user_id']);

// Redirect if already logged in
if ($is_logged_in) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $_SESSION['error'] = "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!";
    } else {
        $login_result = $userModel->login($username, $password);
        if ($login_result) {
            $_SESSION['user_id'] = $login_result['id'];
            $_SESSION['username'] = $login_result['username'];
            $_SESSION['role'] = $login_result['role'];
            $_SESSION['user_email'] = $login_result['email'];
            $_SESSION['success'] = "Đăng nhập thành công! Chào mừng quay trở lại.";
            
            // Redirect based on role or back to main
            if ($login_result['role'] === 'admin') {
                header('Location: admin/index.php');
            } else {
                header('Location: index.php');
            }
            exit;
        } else {
            $_SESSION['error'] = "Tên đăng nhập hoặc mật khẩu không chính xác!";
        }
    }
    header('Location: login.php');
    exit;
}

require_once __DIR__ . '/views/header.php';
?>

<div class="container my-5 py-4">
    <div class="row justify-content-center">
        <div class="col-lg-5 col-md-8">
            <div class="auth-card">
                <div class="text-center mb-4">
                    <h2 class="fw-extrabold text-uppercase"><span class="text-warning">Đăng</span> Nhập</h2>
                    <p class="text-white-50">Vui lòng đăng nhập để đặt vé phim trực tuyến</p>
                </div>
                
                <form action="login.php" method="POST">
                    <div class="mb-4">
                        <label for="username" class="form-label text-white-50">Tên đăng nhập</label>
                        <div class="input-group">
                            <span class="input-group-text bg-secondary border-0 text-white-50"><i class="fa-solid fa-user"></i></span>
                            <input type="text" class="form-control form-control-dark" id="username" name="username" required placeholder="Nhập tên đăng nhập...">
                        </div>
                    </div>
                    
                    <div class="mb-4">
                        <label for="password" class="form-label text-white-50">Mật khẩu</label>
                        <div class="input-group">
                            <span class="input-group-text bg-secondary border-0 text-white-50"><i class="fa-solid fa-lock"></i></span>
                            <input type="password" class="form-control form-control-dark" id="password" name="password" required placeholder="Nhập mật khẩu...">
                        </div>
                    </div>
                    
                    <div class="d-grid gap-2 mt-5">
                        <button type="submit" class="btn btn-yellow text-uppercase py-3 fw-bold">Đăng nhập</button>
                    </div>
                </form>
                
                <div class="text-center mt-4 text-white-50">
                    Chưa có tài khoản? <a href="register.php" class="text-warning fw-semibold text-decoration-none">Đăng ký thành viên</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once __DIR__ . '/views/footer.php';
?>
