<?php
$page_title = "Trang Chủ";
require_once 'header.php';

// Fetch categories for filter and grid
$sql_category = "SELECT * FROM category_name ORDER BY id ASC";
$result_category = $conn->query($sql_category);

// For the filter dropdown, we fetch categories again into an array
$filter_categories = [];
if ($result_category && $result_category->num_rows > 0) {
    while($row = $result_category->fetch_assoc()) {
        $filter_categories[] = $row;
    }
    // Reset pointer for the grid display
    $result_category->data_seek(0);
}

// Build query for products
$where_clauses = [];
$keyword = "";
$category_filter_id = 0;
$sort_option = "newest";

if (isset($_GET['search_keyword']) && !empty(trim($_GET['search_keyword']))) {
    $keyword = $conn->real_escape_string(trim($_GET['search_keyword']));
    $where_clauses[] = "p.product_name LIKE '%$keyword%'";
}

if (isset($_GET['filter_category_id']) && intval($_GET['filter_category_id']) > 0) {
    $category_filter_id = intval($_GET['filter_category_id']);
    $where_clauses[] = "p.category_id = $category_filter_id";
}

$where_sql = "";
if (count($where_clauses) > 0) {
    $where_sql = "WHERE " . implode(" AND ", $where_clauses);
}

// Sorting logic
$order_by = "ORDER BY p.id DESC";
if (isset($_GET['sort_by'])) {
    $sort_option = $_GET['sort_by'];
    if ($sort_option == "price_asc") {
        $order_by = "ORDER BY p.price ASC";
    } elseif ($sort_option == "price_desc") {
        $order_by = "ORDER BY p.price DESC";
    }
}

$sql_product = "SELECT p.*, c.category_name 
                FROM products p 
                LEFT JOIN category_name c ON p.category_id = c.id 
                $where_sql 
                $order_by"; 
$result_product = $conn->query($sql_product);
?>

<div class="container">
    
    <!-- Hero Slider / Banner Section -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="p-5 text-center bg-light rounded-4 shadow-sm" style="background: linear-gradient(135deg, #fff5f7 0%, #fff 100%); border: 1px solid var(--primary-light);">
                <h1 class="display-5 fw-bold text-danger mb-3">Thế Giới Hoa Tươi Premium</h1>
                <p class="col-lg-8 mx-auto lead text-secondary">
                    Nơi cung cấp những bó hoa tốt nghiệp rực rỡ, hoa chúc mừng khai trương sang trọng và đặc biệt là dòng hoa đất sét nghệ thuật độc bản.
                </p>
                <a href="#products-section" class="btn btn-danger btn-lg px-5 rounded-pill fw-semibold shadow-sm mt-3">Mua Sắm Ngay</a>
            </div>
        </div>
    </div>

    <!-- Categories Section -->
    <div id="categories-section" class="text-center mb-5">
        <h2 class="section-title">✿ Danh Mục Hoa ✿</h2>
        <p class="text-muted mb-4">Lựa chọn danh mục phù hợp với nhu cầu của bạn</p>
        
        <div class="row row-cols-2 row-cols-md-3 row-cols-lg-5 g-4 justify-content-center">
            <?php
            if (count($filter_categories) > 0) {
                foreach($filter_categories as $row_cat) {
                    $cat_name = $row_cat['category_name'];
                    
                    // Assign font-awesome icons to categories based on keywords
                    $icon = "fa-spa";
                    if (strpos($cat_name, 'cảm ơn') !== false) {
                        $icon = "fa-hand-holding-heart";
                    } elseif (strpos($cat_name, 'chúc mừng') !== false) {
                        $icon = "fa-gift";
                    } elseif (strpos($cat_name, 'cưới') !== false) {
                        $icon = "fa-ring";
                    } elseif (strpos($cat_name, 'Đất Sét') !== false) {
                        $icon = "fa-circle-nodes";
                    } elseif (strpos($cat_name, 'khai trương') !== false) {
                        $icon = "fa-store";
                    } elseif (strpos($cat_name, 'Sáp') !== false) {
                        $icon = "fa-soap";
                    } elseif (strpos($cat_name, 'sinh nhật') !== false) {
                        $icon = "fa-cake-candles";
                    } elseif (strpos($cat_name, 'tình yêu') !== false) {
                        $icon = "fa-heart";
                    } elseif (strpos($cat_name, 'tốt nghiệp') !== false) {
                        $icon = "fa-graduation-cap";
                    }
            ?>
                    <div class="col">
                        <div class="card h-100 border-0 shadow-sm category-card text-center py-4 px-3">
                            <div class="category-icon-wrapper mb-3 mx-auto">
                                <i class="fa-solid <?php echo $icon; ?>"></i>
                            </div>
                            <h5 class="fw-bold fs-6 text-dark mb-3"><?php echo htmlspecialchars($cat_name); ?></h5>
                            <a href="category.php?id=<?php echo $row_cat['id']; ?>" class="btn btn-outline-danger btn-sm rounded-pill px-3 py-1">Xem sản phẩm</a>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo "<div class='col-12'><p class='text-muted'>Chưa có danh mục nào.</p></div>";
            }
            ?>
        </div>
    </div>

    <!-- Products Section -->
    <div id="products-section" class="pt-4">
        <h2 class="section-title text-center d-block mx-auto mb-4">✿ Sản Phẩm Hoa Tươi ✿</h2>
        
        <!-- Filter and Sort Bar (Mockup Image 4) -->
        <div class="card border-0 shadow-sm rounded-4 mb-5" style="background-color: #ffffff;">
            <div class="card-body p-4">
                <form action="index.php" method="GET" class="row g-3 align-items-center">
                    <!-- Search Input -->
                    <div class="col-lg-4 col-md-12">
                        <div class="input-group">
                            <span class="input-group-text bg-white border-end-0 text-muted"><i class="fa-solid fa-magnifying-glass"></i></span>
                            <input type="text" name="search_keyword" class="form-control border-start-0" placeholder="Tìm sản phẩm..." value="<?php echo htmlspecialchars($keyword); ?>">
                        </div>
                    </div>
                    
                    <!-- Category Select -->
                    <div class="col-lg-3 col-md-6 col-6">
                        <select name="filter_category_id" class="form-select">
                            <option value="0">Tất cả danh mục</option>
                            <?php foreach($filter_categories as $f_cat): ?>
                                <option value="<?php echo $f_cat['id']; ?>" <?php echo $category_filter_id == $f_cat['id'] ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($f_cat['category_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <!-- Sort Select -->
                    <div class="col-lg-3 col-md-6 col-6">
                        <select name="sort_by" class="form-select">
                            <option value="newest" <?php echo $sort_option == 'newest' ? 'selected' : ''; ?>>Sắp xếp: Mới nhất</option>
                            <option value="price_asc" <?php echo $sort_option == 'price_asc' ? 'selected' : ''; ?>>Sắp xếp: Giá tăng dần</option>
                            <option value="price_desc" <?php echo $sort_option == 'price_desc' ? 'selected' : ''; ?>>Sắp xếp: Giá giảm dần</option>
                        </select>
                    </div>
                    
                    <!-- Submit Button -->
                    <div class="col-lg-2 col-md-12 d-grid">
                        <button type="submit" class="btn btn-danger rounded-3"><i class="fa-solid fa-filter me-1"></i> Lọc kết quả</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="row g-4">
            <?php
            if ($result_product && $result_product->num_rows > 0) {
                while($row_pro = $result_product->fetch_assoc()) {
                    $imagePath = !empty($row_pro['image']) ? "uploads/".$row_pro['image'] : "https://via.placeholder.com/300"; 
            ?>
                    <div class="col-lg-3 col-md-4 col-sm-6">
                        <div class="card h-100 border-0 shadow-sm product-card">
                            <!-- Image container -->
                            <div class="product-img-wrapper position-relative">
                                <img src="<?php echo $imagePath; ?>" class="card-img-top product-img" alt="<?php echo htmlspecialchars($row_pro['product_name']); ?>">
                                <span class="badge bg-danger position-absolute top-2 start-2 px-3 py-2 rounded-pill shadow-sm">
                                    <?php echo htmlspecialchars($row_pro['status']); ?>
                                </span>
                            </div>
                            
                            <!-- Body -->
                            <div class="card-body d-flex flex-column p-4">
                                <h5 class="card-title fw-bold text-dark mb-2"><?php echo htmlspecialchars($row_pro['product_name']); ?></h5>
                                <p class="card-text text-secondary small mb-3">
                                    <i class="fa-solid fa-tag me-1 text-danger"></i> Danh mục: <?php echo htmlspecialchars(isset($row_pro['category_name']) ? $row_pro['category_name'] : 'Hoa tươi'); ?>
                                </p>
                                <div class="mt-auto">
                                    <div class="d-flex align-items-center justify-content-between mb-3">
                                        <span class="product-price fs-4 fw-bold text-danger"><?php echo number_format($row_pro['price'], 0, ',', '.'); ?> đ</span>
                                    </div>
                                    <div class="row g-2">
                                        <div class="col-6">
                                            <a href="detail.php?id=<?php echo $row_pro['id']; ?>" class="btn btn-outline-dark btn-sm w-100 rounded-pill py-2 fw-semibold">
                                                Chi tiết
                                            </a>
                                        </div>
                                        <div class="col-6">
                                            <a href="add_cart.php?id=<?php echo $row_pro['id']; ?>" class="btn btn-danger btn-sm w-100 rounded-pill py-2 fw-semibold">
                                                Thêm giỏ
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo "
                <div class='col-12 text-center py-5'>
                    <div class='text-muted fs-4 mb-2'><i class='fa-regular fa-face-frown fs-1 text-danger mb-3 d-block'></i>Không tìm thấy sản phẩm nào!</div>
                    <p class='text-secondary'>Vui lòng thử tìm kiếm lại với từ khóa khác.</p>
                </div>";
            }
            ?>
        </div>
    </div>
</div>

<!-- Styles for Cards -->
<style>
    /* Category Card Hover Style */
    .category-card {
        transition: all 0.3s ease;
        border-radius: 16px;
        background-color: #fff;
    }
    
    .category-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 12px 25px rgba(216, 27, 96, 0.1) !important;
        border: 1px solid var(--primary-light) !important;
    }

    .category-icon-wrapper {
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background-color: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary-color);
        font-size: 1.6rem;
        transition: all 0.3s ease;
    }

    .category-card:hover .category-icon-wrapper {
        background-color: var(--primary-color);
        color: white;
        transform: rotate(15deg);
    }

    /* Product Card Hover Style */
    .product-card {
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .product-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08) !important;
    }

    .product-img-wrapper {
        overflow: hidden;
        height: 250px;
    }

    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .product-card:hover .product-img {
        transform: scale(1.08);
    }

    .top-2 {
        top: 15px !important;
    }
    .start-2 {
        left: 15px !important;
    }
</style>

<?php require_once 'footer.php'; ?>