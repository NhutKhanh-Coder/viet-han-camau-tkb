<?php
$page_title = "Danh mục hoa";
require_once 'header.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "
    <div class='container my-5 text-center'>
        <div class='alert alert-danger py-4 rounded-4'>Danh mục không tồn tại hoặc không hợp lệ!</div>
        <a href='index.php' class='btn btn-danger px-4 rounded-pill mt-3'>Quay lại trang chủ</a>
    </div>";
    require_once 'footer.php';
    exit();
}

$category_id = intval($_GET['id']);

// Fetch Category Details
$sql_cat = "SELECT * FROM category_name WHERE id = $category_id";
$res_cat = $conn->query($sql_cat);

if (!$res_cat || $res_cat->num_rows == 0) {
    echo "
    <div class='container my-5 text-center'>
        <div class='alert alert-danger py-4 rounded-4'>Không tìm thấy danh mục yêu cầu!</div>
        <a href='index.php' class='btn btn-danger px-4 rounded-pill mt-3'>Quay lại trang chủ</a>
    </div>";
    require_once 'footer.php';
    exit();
}

$category = $res_cat->fetch_assoc();

// Fetch products in this category
$sql_prod = "SELECT p.*, c.category_name 
             FROM products p 
             LEFT JOIN category_name c ON p.category_id = c.id 
             WHERE p.category_id = $category_id 
             ORDER BY p.id DESC";
$result_product = $conn->query($sql_prod);
?>

<div class="container">
    <!-- Category Header Banner -->
    <div class="row mb-5">
        <div class="col-12">
            <div class="p-5 text-center bg-light rounded-4 shadow-sm" style="background: linear-gradient(135deg, #fff5f7 0%, #fff 100%); border: 1px solid var(--primary-light);">
                <span class="fs-1 d-block mb-2">🌸</span>
                <h1 class="display-6 fw-bold text-danger mb-2"><?php echo htmlspecialchars($category['category_name']); ?></h1>
                <?php if (!empty($category['description'])): ?>
                    <p class="col-lg-8 mx-auto lead text-secondary small mb-0"><?php echo htmlspecialchars($category['description']); ?></p>
                <?php else: ?>
                    <p class="col-lg-8 mx-auto lead text-secondary small mb-0">Các mẫu thiết kế hoa tươi chất lượng cao thuộc danh mục <?php echo htmlspecialchars($category['category_name']); ?>.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Product list -->
    <div class="row g-4">
        <?php
        if ($result_product && $result_product->num_rows > 0) {
            while($row_pro = $result_product->fetch_assoc()) {
                $imagePath = !empty($row_pro['image']) ? "uploads/".$row_pro['image'] : "https://via.placeholder.com/300"; 
        ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card h-100 border-0 shadow-sm product-card">
                        <!-- Image container -->
                        <div class="product-img-wrapper position-relative">
                            <img src="<?php echo $imagePath; ?>" class="card-img-top product-img" alt="<?php echo htmlspecialchars($row_pro['product_name']); ?>">
                            <span class="badge bg-danger position-absolute top-2 start-2 px-3 py-2 rounded-pill shadow-sm">
                                <?php echo htmlspecialchars($row_pro['status']); ?>
                            </span>
                        </div>
                        
                        <!-- Body -->
                        <div class="card-body d-flex flex-column p-4">
                            <h5 class="card-title fw-bold text-dark mb-2"><?php echo htmlspecialchars($row_pro['product_name']); ?></h5>
                            <p class="card-text text-secondary small mb-3">
                                <i class="fa-solid fa-tag me-1 text-danger"></i> Danh mục: <?php echo htmlspecialchars($category['category_name']); ?>
                            </p>
                            <div class="mt-auto">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <span class="product-price fs-4 fw-bold text-danger"><?php echo number_format($row_pro['price'], 0, ',', '.'); ?> đ</span>
                                </div>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <a href="detail.php?id=<?php echo $row_pro['id']; ?>" class="btn btn-outline-dark btn-sm w-100 rounded-pill py-2 fw-semibold">
                                            Chi tiết
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <a href="add_cart.php?id=<?php echo $row_pro['id']; ?>" class="btn btn-danger btn-sm w-100 rounded-pill py-2 fw-semibold">
                                            Thêm giỏ
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "
            <div class='col-12 text-center py-5'>
                <div class='text-muted fs-4 mb-2'><i class='fa-regular fa-face-frown fs-1 text-danger mb-3 d-block'></i>Chưa có sản phẩm nào thuộc danh mục này!</div>
                <p class='text-secondary mb-4'>Vui lòng quay lại sau hoặc xem các danh mục khác.</p>
                <a href='index.php' class='btn btn-danger px-4 rounded-pill fw-semibold'>Quay lại trang chủ</a>
            </div>";
        }
        ?>
    </div>
</div>

<style>
    .product-card {
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .product-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08) !important;
    }

    .product-img-wrapper {
        overflow: hidden;
        height: 250px;
    }

    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .product-card:hover .product-img {
        transform: scale(1.08);
    }

    .top-2 {
        top: 15px !important;
    }
    .start-2 {
        left: 15px !important;
    }
</style>

<?php require_once 'footer.php'; ?>
