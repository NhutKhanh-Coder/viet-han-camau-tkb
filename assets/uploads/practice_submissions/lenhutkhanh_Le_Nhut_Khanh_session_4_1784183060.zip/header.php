<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

// Fetch settings
$website_name = 'Flower Shop';
$slogan = 'Trao gửi yêu thương qua từng cánh hoa';
$logo = 'logo.png';
$address = '';
$phone = '';
$email = '';
$facebook = '#';
$zalo = '#';
$youtube = '#';

$sql_set = "SELECT * FROM settings LIMIT 1";
$res_set = $conn->query($sql_set);
if ($res_set && $res_set->num_rows > 0) {
    $set = $res_set->fetch_assoc();
    $website_name = !empty($set['website_name']) ? $set['website_name'] : $website_name;
    $slogan = !empty($set['slogan']) ? $set['slogan'] : $slogan;
    $logo = !empty($set['logo']) ? $set['logo'] : $logo;
    $address = $set['address'];
    $phone = $set['phone'];
    $email = $set['email'];
    $facebook = $set['facebook'];
    $zalo = $set['zalo'];
    $youtube = $set['youtube'];
}

// Get cart count
$cart_count = 0;
if (isset($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $item) {
        $cart_count += $item['quantity'];
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo isset($page_title) ? $page_title . ' - ' . $website_name : $website_name . ' - Cửa Hàng Hoa Tươi'; ?></title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #d81b60;
            --primary-hover: #ad1457;
            --primary-light: #fce4ec;
            --text-dark: #2d3748;
            --text-muted: #718096;
            --bg-light: #fff5f7;
            --border-color: #f1f3f5;
        }

        body {
            font-family: 'Outfit', sans-serif;
            background-color: #fdfbfb;
            color: var(--text-dark);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        /* Header & Logo */
        .top-header {
            background-color: #ffffff;
            border-bottom: 1px solid var(--border-color);
            padding: 15px 0;
        }
        
        .logo-link {
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo-icon {
            font-size: 2rem;
            color: var(--primary-color);
            background: var(--primary-light);
            padding: 8px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(216, 27, 96, 0.1);
        }

        .logo-text {
            font-size: 1.6rem;
            font-weight: 800;
            color: var(--text-dark);
            letter-spacing: -0.5px;
            margin: 0;
            line-height: 1.2;
        }

        .logo-text span {
            color: var(--primary-color);
        }

        .slogan {
            font-size: 0.8rem;
            color: var(--text-muted);
            margin: 2px 0 0 0;
            font-style: italic;
        }

        /* Search Bar */
        .search-form {
            position: relative;
            max-width: 500px;
            width: 100%;
        }

        .search-input {
            border: 2px solid var(--border-color);
            border-radius: 30px;
            padding: 10px 25px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            box-shadow: 0 2px 6px rgba(0,0,0,0.02);
        }

        .search-input:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 0.25rem rgba(216, 27, 96, 0.15);
            outline: none;
        }

        .search-btn {
            position: absolute;
            right: 4px;
            top: 4px;
            bottom: 4px;
            border: none;
            background-color: var(--primary-color);
            color: white;
            border-radius: 30px;
            padding: 0 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .search-btn:hover {
            background-color: var(--primary-hover);
        }

        /* Navbar Custom */
        .navbar-custom {
            background-color: #ffffff;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.03);
            border-bottom: 1px solid var(--border-color);
            padding: 8px 0;
        }

        .nav-link-custom {
            font-weight: 600;
            color: var(--text-dark) !important;
            font-size: 0.95rem;
            padding: 8px 16px !important;
            border-radius: 8px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .nav-link-custom:hover, .nav-link-custom.active {
            color: var(--primary-color) !important;
            background-color: var(--primary-light);
        }

        .cart-btn-custom {
            position: relative;
        }

        .cart-badge {
            position: absolute;
            top: -4px;
            right: -2px;
            background-color: var(--primary-color);
            color: white;
            font-size: 0.7rem;
            font-weight: 700;
            border-radius: 50%;
            padding: 3px 6px;
            border: 2px solid white;
        }

        /* Dropdown profile */
        .user-dropdown-btn {
            background: none;
            border: 1px solid var(--border-color);
            padding: 6px 16px;
            border-radius: 30px;
            font-weight: 600;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .user-dropdown-btn:hover {
            border-color: var(--primary-color);
            background-color: var(--bg-light);
        }

        .dropdown-menu-custom {
            border: none;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.08);
            border-radius: 12px;
            padding: 8px;
            margin-top: 10px !important;
        }

        .dropdown-item-custom {
            border-radius: 8px;
            padding: 8px 16px;
            font-weight: 500;
            color: var(--text-dark);
            display: flex;
            align-items: center;
            gap: 10px;
            transition: all 0.2s ease;
        }

        .dropdown-item-custom:hover {
            background-color: var(--primary-light);
            color: var(--primary-color);
        }

        .dropdown-divider-custom {
            margin: 6px 0;
            border-top: 1px solid var(--border-color);
        }

        /* Utilities */
        .section-title {
            font-weight: 800;
            font-size: 1.8rem;
            color: var(--text-dark);
            position: relative;
            display: inline-block;
            margin-bottom: 30px;
        }

        .section-title::after {
            content: '';
            position: absolute;
            left: 50%;
            bottom: -8px;
            transform: translateX(-50%);
            width: 50px;
            height: 3px;
            background-color: var(--primary-color);
            border-radius: 2px;
        }
    </style>
</head>
<body>

<!-- Top Header Section -->
<div class="top-header">
    <div class="container">
        <div class="row align-items-center g-3">
            <!-- Logo -->
            <div class="col-md-4 col-12 text-center text-md-start">
                <a href="index.php" class="logo-link">
                    <div class="logo-icon">
                        <i class="fa-solid fa-spa"></i>
                    </div>
                    <div>
                        <h1 class="logo-text">FLOWER<span>SHOP</span></h1>
                        <p class="slogan"><?php echo htmlspecialchars($slogan); ?></p>
                    </div>
                </a>
            </div>
            
            <!-- Search -->
            <div class="col-md-5 col-12 d-flex justify-content-center">
                <form action="search.php" method="GET" class="search-form">
                    <input type="text" name="keyword" class="form-control search-input" placeholder="Nhập tên hoa cần tìm..." required value="<?php echo isset($_GET['keyword']) ? htmlspecialchars($_GET['keyword']) : ''; ?>">
                    <button class="search-btn" type="submit">
                        <i class="fa-solid fa-magnifying-glass me-1"></i> Tìm kiếm
                    </button>
                </form>
            </div>
            
            <!-- Auth -->
            <div class="col-md-3 col-12 d-flex justify-content-center justify-content-md-end align-items-center gap-3">
                <?php if(isset($_SESSION['fullname'])): ?>
                    <div class="dropdown">
                        <button class="user-dropdown-btn dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fa-solid fa-circle-user text-danger fs-5"></i>
                            <span><?php echo htmlspecialchars($_SESSION['fullname']); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-custom">
                            <li><a class="dropdown-item dropdown-item-custom" href="profile.php"><i class="fa-solid fa-address-card"></i> Thông tin cá nhân</a></li>
                            <li><a class="dropdown-item dropdown-item-custom" href="change-password.php"><i class="fa-solid fa-key"></i> Đổi mật khẩu</a></li>
                            <li><hr class="dropdown-divider dropdown-divider-custom"></li>
                            <li><a class="dropdown-item dropdown-item-custom text-danger" href="logout.php"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="btn btn-outline-danger px-4 rounded-pill fw-semibold">Đăng nhập</a>
                    <a href="register.php" class="btn btn-danger px-4 rounded-pill fw-semibold">Đăng ký</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Navigation Bar -->
<nav class="navbar navbar-expand-lg navbar-custom sticky-top">
    <div class="container">
        <button class="navbar-toggler ms-auto" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link-custom <?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>" href="index.php">
                        <i class="fa-solid fa-house"></i> Trang chủ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-custom" href="index.php#products-section">
                        <i class="fa-solid fa-seedling"></i> Sản phẩm
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-custom" href="index.php#categories-section">
                        <i class="fa-solid fa-tags"></i> Danh mục
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-custom" href="#">
                        <i class="fa-solid fa-star"></i> Đánh giá
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-custom" href="#">
                        <i class="fa-solid fa-newspaper"></i> Tin tức
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-custom" href="#">
                        <i class="fa-solid fa-envelope"></i> Liên hệ
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link-custom cart-btn-custom <?php echo basename($_SERVER['PHP_SELF']) == 'cart.php' ? 'active' : ''; ?>" href="cart.php">
                        <i class="fa-solid fa-cart-shopping"></i> Giỏ hàng
                        <?php if ($cart_count > 0): ?>
                            <span class="cart-badge"><?php echo $cart_count; ?></span>
                        <?php endif; ?>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Page Content Starts Here -->
<main class="py-5 flex-grow-1">
