<?php
session_start();
require_once 'db.php';

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = intval($_GET['id']);

    $sql = "SELECT id, product_name, price, image FROM products WHERE id = $id";
    $result = $conn->query($sql);

    if ($result && $result->num_rows > 0) {
        $product = $result->fetch_assoc();

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = array();
        }

        if (isset($_SESSION['cart'][$id])) {
            $_SESSION['cart'][$id]['quantity'] += 1;
            $qty = $_SESSION['cart'][$id]['quantity'];
        } else {
            $_SESSION['cart'][$id] = array(
                'name' => $product['product_name'],
                'price' => $product['price'],
                'image' => $product['image'],
                'quantity' => 1
            );
            $qty = 1;
        }

        // Sync to database if user is logged in
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $check_cart = "SELECT id, quantity FROM carts WHERE user_id = $user_id AND product_id = $id";
            $res_check = $conn->query($check_cart);
            if ($res_check && $res_check->num_rows > 0) {
                $cart_item = $res_check->fetch_assoc();
                $new_qty = $cart_item['quantity'] + 1;
                $conn->query("UPDATE carts SET quantity = $new_qty WHERE id = " . $cart_item['id']);
            } else {
                $conn->query("INSERT INTO carts (user_id, product_id, quantity) VALUES ($user_id, $id, 1)");
            }
        }

        if (isset($_GET['buy_now']) && $_GET['buy_now'] == 1) {
            header("Location: checkout.php");
        } else {
            header("Location: cart.php");
        }
        exit();
    } else {
        echo "<script>alert('Sản phẩm không tồn tại!'); window.location.href='index.php';</script>";
    }
} else {
    header("Location: index.php");
}
?>