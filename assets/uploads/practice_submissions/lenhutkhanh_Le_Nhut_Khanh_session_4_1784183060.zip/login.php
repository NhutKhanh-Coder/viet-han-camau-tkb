<?php
session_start();
require_once 'db.php';

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_or_user = $conn->real_escape_string(trim($_POST['email_or_user']));
    $password = $_POST['password'];

    if (empty($email_or_user) || empty($password)) {
        $error = "Vui lòng nhập đầy đủ thông tin đăng nhập.";
    } else {
        $sql = "SELECT * FROM users WHERE email = '$email_or_user' OR username = '$email_or_user'";
        $result = $conn->query($sql);

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();
            
            if ($user['status'] == 0) {
                $error = "Tài khoản của bạn đã bị khóa!";
            } else if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['fullname'] = $user['fullname'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                // DB to Session Cart Sync
                $user_id = $user['id'];
                $sql_cart = "SELECT c.*, p.product_name, p.price, p.image 
                             FROM carts c 
                             JOIN products p ON c.product_id = p.id 
                             WHERE c.user_id = $user_id";
                $res_cart = $conn->query($sql_cart);
                
                if ($res_cart && $res_cart->num_rows > 0) {
                    if (!isset($_SESSION['cart'])) {
                        $_SESSION['cart'] = array();
                    }
                    while ($c_item = $res_cart->fetch_assoc()) {
                        $_SESSION['cart'][$c_item['product_id']] = array(
                            'name' => $c_item['product_name'],
                            'price' => $c_item['price'],
                            'image' => $c_item['image'],
                            'quantity' => intval($c_item['quantity'])
                        );
                    }
                }

                header("Location: index.php");
                exit();
            } else {
                $error = "Mật khẩu không chính xác!";
            }
        } else {
            $error = "Tên đăng nhập hoặc email không tồn tại!";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Nhập - Flower Shop</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { 
            background: linear-gradient(135deg, #fce4ec 0%, #f3e5f5 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Outfit', sans-serif;
        }
        .login-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(216, 27, 96, 0.1);
            padding: 40px;
            max-width: 450px;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.5);
        }
        .logo-title {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo-title h2 {
            font-weight: 800;
            color: #2d3748;
            margin-top: 10px;
            font-size: 1.8rem;
        }
        .logo-title h2 span {
            color: #d81b60;
        }
        .form-label {
            font-weight: 600;
            font-size: 0.9rem;
            color: #4a5568;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 1px solid #e2e8f0;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }
        .form-control:focus {
            border-color: #d81b60;
            box-shadow: 0 0 0 0.25rem rgba(216, 27, 96, 0.15);
        }
        .btn-login {
            background-color: #d81b60;
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s ease;
            margin-top: 15px;
            box-shadow: 0 4px 12px rgba(216, 27, 96, 0.2);
        }
        .btn-login:hover {
            background-color: #ad1457;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(216, 27, 96, 0.3);
        }
        .register-link {
            text-align: center;
            margin-top: 25px;
            font-size: 0.95rem;
        }
        .register-link a {
            color: #d81b60;
            text-decoration: none;
            font-weight: 700;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="login-card">
    <div class="logo-title">
        <div class="text-danger fs-1"><i class="fa-solid fa-spa"></i></div>
        <h2>Đăng <span>Nhập</span></h2>
        <p class="text-secondary small">Đăng nhập tài khoản thành viên để đặt mua hoa tươi</p>
    </div>
    
    <?php if($error != ""): ?>
        <div class="alert alert-danger alert-dismissible fade show rounded-3" role="alert">
            <i class="fa-solid fa-triangle-exclamation me-2"></i> <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="login.php">
        <div class="mb-3">
            <label for="email_or_user" class="form-label">Tên đăng nhập hoặc Email</label>
            <input type="text" class="form-control" id="email_or_user" name="email_or_user" placeholder="Nhập tên đăng nhập hoặc email" required value="<?php echo isset($_POST['email_or_user']) ? htmlspecialchars($_POST['email_or_user']) : ''; ?>">
        </div>

        <div class="mb-4">
            <label for="password" class="form-label">Mật khẩu</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Nhập mật khẩu của bạn" required>
        </div>

        <button type="submit" class="btn btn-login w-100 shadow-sm">Đăng Nhập</button>
    </form>

    <div class="register-link">
        <p>Chưa có tài khoản thành viên? <a href="register.php">Đăng ký ngay</a></p>
    </div>
</div>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>