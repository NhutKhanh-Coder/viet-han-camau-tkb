<?php
$host = "localhost";
$username = "root";
$password = "";

// Connect to MySQL
$conn = new mysqli($host, $username, $password);
if ($conn->connect_error) {
    die("Kết nối MySQL thất bại: " . $conn->connect_error);
}

// Create database if not exists
$conn->query("CREATE DATABASE IF NOT EXISTS `flower_shop` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$conn->select_db("flower_shop");
$conn->set_charset("utf8mb4");

$conn->query("SET FOREIGN_KEY_CHECKS = 0;");

// Drop existing tables for a clean slate
$tables = ['reviews', 'order_details', 'orders', 'carts', 'products', 'category_name', 'contacts', 'news', 'settings', 'users'];
foreach ($tables as $tbl) {
    $conn->query("DROP TABLE IF EXISTS `$tbl` CASCADE");
}
echo "Đã xóa các bảng cũ.\n";

// 1. Users
$conn->query("CREATE TABLE users (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) NOT NULL,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(10) NOT NULL,
    gender ENUM('Nam', 'Nữ', 'Khác') DEFAULT 'Khác',
    birthday DATE DEFAULT NULL,
    address TEXT DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    status TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng users.\n";

// 2. Category_name
$conn->query("CREATE TABLE category_name (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL,
    description TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng category_name.\n";

// 3. Products
$conn->query("CREATE TABLE products (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    category_id INT(11) NOT NULL,
    product_name VARCHAR(255) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    quantity INT(11) DEFAULT 100,
    image VARCHAR(255) DEFAULT NULL,
    image2 VARCHAR(255) DEFAULT NULL,
    image3 VARCHAR(255) DEFAULT NULL,
    description TEXT DEFAULT NULL,
    flower_meaning TEXT DEFAULT NULL,
    status ENUM('Còn hàng', 'Hết hàng') DEFAULT 'Còn hàng',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES category_name(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng products.\n";

// 4. Carts
$conn->query("CREATE TABLE carts (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    product_id INT(11) NOT NULL,
    quantity INT(11) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng carts.\n";

// 5. Contacts
$conn->query("CREATE TABLE contacts (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(100) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(10) DEFAULT NULL,
    message TEXT DEFAULT NULL,
    admin_reply TEXT DEFAULT NULL,
    status ENUM('Chưa trả lời', 'Đã trả lời') DEFAULT 'Chưa trả lời',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng contacts.\n";

// 6. News
$conn->query("CREATE TABLE news (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) DEFAULT NULL,
    thumbnail VARCHAR(255) DEFAULT NULL,
    content LONGTEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng news.\n";

// 7. Orders
$conn->query("CREATE TABLE orders (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    fullname VARCHAR(100) DEFAULT NULL,
    phone VARCHAR(10) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    note TEXT DEFAULT NULL,
    payment_method ENUM('COD', 'BANK') DEFAULT 'COD',
    total_amount DECIMAL(12,2) DEFAULT NULL,
    order_status ENUM('Chờ xác nhận', 'Đang giao', 'Hoàn thành', 'Đã hủy') DEFAULT 'Chờ xác nhận',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng orders.\n";

// 8. Order_details
$conn->query("CREATE TABLE order_details (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    order_id INT(11) NOT NULL,
    product_id INT(11) NOT NULL,
    quantity INT(11) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng order_details.\n";

// 9. Reviews
$conn->query("CREATE TABLE reviews (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    product_id INT(11) NOT NULL,
    rating INT(11) DEFAULT 5,
    comment TEXT DEFAULT NULL,
    status TINYINT(1) DEFAULT 1,
    review_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng reviews.\n";

// 10. Settings
$conn->query("CREATE TABLE settings (
    id INT(11) AUTO_INCREMENT PRIMARY KEY,
    website_name VARCHAR(255) DEFAULT NULL,
    slogan VARCHAR(255) DEFAULT NULL,
    logo VARCHAR(255) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    phone VARCHAR(20) DEFAULT NULL,
    email VARCHAR(100) DEFAULT NULL,
    facebook VARCHAR(255) DEFAULT NULL,
    zalo VARCHAR(255) DEFAULT NULL,
    youtube VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;");
echo "Đã tạo bảng settings.\n";

$conn->query("SET FOREIGN_KEY_CHECKS = 1;");

// --- SEED DATA ---

// Users
$admin_pwd = password_hash('admin123', PASSWORD_DEFAULT);
$user_pwd = password_hash('user123', PASSWORD_DEFAULT);
$cuong_pwd = password_hash('Cuong123@', PASSWORD_DEFAULT); // strong password matching requirements

$conn->query("INSERT INTO users (fullname, username, email, phone, gender, password, role) VALUES 
    ('Administrator', 'admin', 'admin@flowershop.vn', '0987654321', 'Khác', '$admin_pwd', 'admin'),
    ('Lê Khánh', 'lekhanh', 'lekhanh@flowershop.vn', '0901234567', 'Nam', '$user_pwd', 'customer'),
    ('Pham Duy Cường', 'phamduycuong', 'phamduycuong@camauvkc.edu.vn', '0123456789', 'Nam', '$cuong_pwd', 'customer')
");
echo "Đã chèn dữ liệu users mẫu.\n";

// Categories
$categories = [
    'Hoa cảm ơn',
    'Hoa chúc mừng',
    'Hoa cưới',
    'Hoa Đất Sét',
    'Hoa khai trương',
    'Hoa Sáp',
    'Hoa sinh nhật',
    'Hoa tình yêu',
    'Hoa tốt nghiệp'
];
foreach ($categories as $cat) {
    $conn->query("INSERT INTO category_name (category_name) VALUES ('" . $conn->real_escape_string($cat) . "')");
}
echo "Đã chèn dữ liệu category_name.\n";

// Settings
$conn->query("INSERT INTO settings (website_name, slogan, logo, address, phone, email, facebook, zalo, youtube) VALUES (
    'Flower Shop',
    'Lựa chọn danh mục phù hợp với nhu cầu của bạn',
    'logo.png',
    '182 Hùng Vương, Phường 9, Quận 5, TP. Hồ Chí Minh',
    '0901234567',
    'contact@flowershop.vn',
    'https://facebook.com/flowershop',
    'https://zalo.me/flowershop',
    'https://youtube.com/flowershop'
)");
echo "Đã chèn dữ liệu settings.\n";

// Products (Get IDs of categories)
$res_cat = $conn->query("SELECT id, category_name FROM category_name");
$cat_ids = [];
while ($row = $res_cat->fetch_assoc()) {
    $cat_ids[$row['category_name']] = $row['id'];
}

$id_tot_nghiep = $cat_ids['Hoa tốt nghiệp'];
$id_dat_set = $cat_ids['Hoa Đất Sét'];
$id_cam_on = $cat_ids['Hoa cảm ơn'];
$id_chuc_mung = $cat_ids['Hoa chúc mừng'];
$id_cuoi = $cat_ids['Hoa cưới'];
$id_tinh_yeu = $cat_ids['Hoa tình yêu'];

// Seed products
// 1. Hoa chúc mừng tốt nghiệp
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_tot_nghiep,
    'Hoa chúc mừng tốt nghiệp',
    500000.00,
    20,
    'hoa_tot_nghiep_1.jpg',
    'Bó hoa hướng dương chúc mừng lễ tốt nghiệp rực rỡ, thích hợp tặng cử nhân trong ngày ra trường.',
    'Chúc bạn gặt hái nhiều thành công và tỏa sáng trên con đường tương lai.'
)");

// 2. Hoa gấu bông kết hợp hoa
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_tot_nghiep,
    'Hoa gấu bông kết hợp hoa',
    750000.00,
    15,
    'hoa_tot_nghiep_2.jpg',
    'Bó hoa tốt nghiệp kèm chú gấu cử nhân đáng yêu, món quà lưu niệm ý nghĩa cho ngày lễ tốt nghiệp.',
    'Kỷ niệm đẹp thời học sinh và chúc tương lai rộng mở.'
)");

// 3. Hoa cẩm tú cầu tốt nghiệp
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_tot_nghiep,
    'Hoa cẩm tú cầu tốt nghiệp',
    650000.00,
    10,
    'hoa_tot_nghiep_3.jpg',
    'Bó hoa cẩm tú cầu xanh kết hợp với hoa baby trắng tinh tế, tạo nên vẻ đẹp sang trọng thanh lịch.',
    'Thể hiện lòng biết ơn chân thành và sự chân thành.'
)");

// 4. Hoa tulip vàng
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_tot_nghiep,
    'Hoa tulip vàng',
    550000.00,
    18,
    'hoa_tot_nghiep_4.jpg',
    'Bó hoa tulip vàng rạng ngời như ánh nắng, mang lại niềm vui tươi tắn.',
    'Tượng trưng cho suy nghĩ tươi sáng và sự tự tin.'
)");

// 5. Hoa hướng dương tốt nghiệp
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_tot_nghiep,
    'Hoa hướng dương tốt nghiệp',
    450000.00,
    25,
    'hoa_tot_nghiep_5.jpg',
    'Bó hoa hướng dương kết hợp nơ và giấy gói cao cấp, biểu tượng của niềm tin vững chãi.',
    'Luôn vươn tới tầm cao mới và luôn hướng tới ánh sáng.'
)");

// 6. Hoa Đất Sét Gấu Bông (multiple images)
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, image2, image3, description, flower_meaning) VALUES (
    $id_dat_set,
    'Hoa Đất Sét Gấu Bông',
    475.00,
    15,
    'hoa_dat_set_1.jpg',
    'hoa_dat_set_2.jpg',
    'hoa_dat_set_3.jpg',
    'Bó hoa đất sét nhân tạo được nặn bằng tay vô cùng tinh xảo cùng chú gấu bông nhỏ xinh xắn. Thích hợp để bàn học, bàn làm việc làm kỷ niệm lâu bền.',
    'Tình cảm gắn kết bền chặt, vĩnh cửu theo thời gian.'
)");

// 7. Hoa cảm ơn (Cẩm chướng)
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_cam_on,
    'Bó hoa cẩm chướng hồng',
    350000.00,
    30,
    'hoa_cam_on_1.jpg',
    'Bó hoa cẩm chướng hồng dịu dàng, bày tỏ lòng kính trọng sâu sắc.',
    'Lòng biết ơn chân thành đối với đấng sinh thành hoặc thầy cô.'
)");

// 8. Hoa tình yêu (Hồng nhung)
$conn->query("INSERT INTO products (category_id, product_name, price, quantity, image, description, flower_meaning) VALUES (
    $id_tinh_yeu,
    'Bó hoa hồng đỏ 99 bông',
    1500000.00,
    12,
    'hoa_tinh_yeu_1.jpg',
    'Bó hoa hồng nhung đỏ 99 bông cỡ lớn, biểu trưng của tình yêu nồng thắm.',
    'Tình yêu vĩnh cửu, không bao giờ phai nhạt.'
)");

echo "Đã chèn dữ liệu products mẫu.\n";

echo "MIGRATION HOÀN THÀNH THÀNH CÔNG!\n";
?>
