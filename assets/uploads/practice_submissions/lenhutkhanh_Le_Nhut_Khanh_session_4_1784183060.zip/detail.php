<?php
$page_title = "Chi tiết sản phẩm";
require_once 'header.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "
    <div class='container my-5 text-center'>
        <div class='alert alert-danger py-4 rounded-4'>Sản phẩm không tồn tại hoặc đã bị xóa!</div>
        <a href='index.php' class='btn btn-danger px-4 rounded-pill mt-3'>Quay lại trang chủ</a>
    </div>";
    require_once 'footer.php';
    exit();
}

$product_id = intval($_GET['id']);

$sql = "SELECT p.*, c.category_name 
        FROM products p 
        LEFT JOIN category_name c ON p.category_id = c.id 
        WHERE p.id = $product_id";
$result = $conn->query($sql);

if (!$result || $result->num_rows == 0) {
    echo "
    <div class='container my-5 text-center'>
        <div class='alert alert-danger py-4 rounded-4'>Không tìm thấy sản phẩm!</div>
        <a href='index.php' class='btn btn-danger px-4 rounded-pill mt-3'>Quay lại trang chủ</a>
    </div>";
    require_once 'footer.php';
    exit();
}

$product = $result->fetch_assoc();

// Review Submission Handler
$review_message = "";
$review_message_type = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_review'])) {
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $rating = intval($_POST['rating']);
        $comment = $conn->real_escape_string(trim($_POST['comment']));
        
        if (empty($comment)) {
            $review_message = "Vui lòng nhập bình luận nhận xét.";
            $review_message_type = "danger";
        } else {
            $sql_insert_review = "INSERT INTO reviews (user_id, product_id, rating, comment, status) 
                                  VALUES ($user_id, $product_id, $rating, '$comment', 1)";
            if ($conn->query($sql_insert_review)) {
                $review_message = "Cảm ơn bạn đã gửi đánh giá sản phẩm thành công!";
                $review_message_type = "success";
            } else {
                $review_message = "Lỗi: Không thể lưu đánh giá của bạn.";
                $review_message_type = "danger";
            }
        }
    } else {
        $review_message = "Bạn cần đăng nhập để gửi đánh giá.";
        $review_message_type = "warning";
    }
}
?>

<div class="container">
    <!-- Breadcrumb -->
    <nav aria-label="breadcrumb" class="mb-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="index.php" class="text-danger text-decoration-none">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="category.php?id=<?php echo $product['category_id']; ?>" class="text-danger text-decoration-none"><?php echo htmlspecialchars($product['category_name']); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo htmlspecialchars($product['product_name']); ?></li>
        </ol>
    </nav>

    <!-- Product Info Details (Image 5 style) -->
    <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5 mb-5">
        <div class="row g-5">
            <!-- Product Images -->
            <div class="col-lg-5 col-12">
                <?php 
                    $img_main = (!empty($product['image'])) ? "uploads/".$product['image'] : "https://via.placeholder.com/500";
                ?>
                <div class="product-gallery">
                    <div class="main-img-container mb-3 border rounded-4 overflow-hidden shadow-sm" style="height: 400px;">
                        <img src="<?php echo $img_main; ?>" alt="Main Image" class="w-100 h-100 img-fluid" id="mainImage" style="object-fit: cover;">
                    </div>
                    
                    <!-- Thumbnails row -->
                    <div class="row g-2 thumbnail-container justify-content-center">
                        <div class="col-3">
                            <img src="<?php echo $img_main; ?>" class="img-thumbnail rounded-3 w-100 active-thumb" style="height: 70px; object-fit: cover; cursor: pointer;" onclick="changeMainImage(this)">
                        </div>
                        <?php if(!empty($product['image2'])): ?>
                            <div class="col-3">
                                <img src="uploads/<?php echo $product['image2']; ?>" class="img-thumbnail rounded-3 w-100" style="height: 70px; object-fit: cover; cursor: pointer;" onclick="changeMainImage(this)">
                            </div>
                        <?php endif; ?>
                        <?php if(!empty($product['image3'])): ?>
                            <div class="col-3">
                                <img src="uploads/<?php echo $product['image3']; ?>" class="img-thumbnail rounded-3 w-100" style="height: 70px; object-fit: cover; cursor: pointer;" onclick="changeMainImage(this)">
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Product specifications and details -->
            <div class="col-lg-7 col-12 d-flex flex-column justify-content-between">
                <div>
                    <!-- Product Title -->
                    <h1 class="fw-bold text-dark mb-3"><?php echo htmlspecialchars($product['product_name']); ?></h1>
                    
                    <!-- Price -->
                    <h2 class="text-danger fw-extrabold mb-4"><?php echo number_format($product['price'], 0, ',', '.'); ?> đ</h2>

                    <!-- Spec Sheet -->
                    <div class="spec-sheet border-top pt-3 mb-4">
                        <div class="row mb-2">
                            <div class="col-sm-4 text-secondary">Danh mục:</div>
                            <div class="col-sm-8 fw-semibold text-danger">
                                <a href="category.php?id=<?php echo $product['category_id']; ?>" class="text-danger text-decoration-none">
                                    <?php echo htmlspecialchars(isset($product['category_name']) ? $product['category_name'] : 'Hoa tươi'); ?>
                                </a>
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 text-secondary">Số lượng:</div>
                            <div class="col-sm-8 fw-semibold"><?php echo intval($product['quantity']); ?></div>
                        </div>
                        <div class="row mb-2">
                            <div class="col-sm-4 text-secondary">Tình trạng:</div>
                            <div class="col-sm-8">
                                <span class="badge bg-<?php echo ($product['status'] == 'Còn hàng' && $product['quantity'] > 0) ? 'success' : 'danger'; ?> px-3 py-1.5 rounded-pill shadow-sm">
                                    <?php echo htmlspecialchars($product['status']); ?>
                                </span>
                            </div>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="mt-4 border-top pt-3">
                        <h5 class="fw-bold text-dark"><i class="fa-solid fa-rectangle-list text-danger me-2"></i> Mô tả sản phẩm</h5>
                        <p class="text-secondary" style="line-height: 1.6;"><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
                    </div>

                    <!-- Meaning -->
                    <?php if (!empty($product['flower_meaning'])): ?>
                        <div class="mt-4 border-top pt-3 mb-4">
                            <h5 class="fw-bold text-dark"><i class="fa-solid fa-seedling text-danger me-2"></i> Ý nghĩa loài hoa</h5>
                            <p class="text-secondary" style="line-height: 1.6; font-style: italic;"><?php echo nl2br(htmlspecialchars($product['flower_meaning'])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Buy Action Button container -->
                <div class="d-flex flex-wrap gap-3 mt-4">
                    <a href="add_cart.php?id=<?php echo $product['id']; ?>" class="btn btn-danger btn-lg px-5 py-3 rounded-pill fw-bold shadow-sm flex-grow-1 flex-md-grow-0 d-flex align-items-center justify-content-center gap-2">
                        <i class="fa-solid fa-cart-plus"></i> Thêm vào giỏ hàng
                    </a>
                    <!-- Buy Now Button (Simulate direct check out or redirect to checkout directly) -->
                    <a href="add_cart.php?id=<?php echo $product['id']; ?>&buy_now=1" class="btn btn-outline-danger btn-lg px-5 py-3 rounded-pill fw-bold flex-grow-1 flex-md-grow-0 d-flex align-items-center justify-content-center gap-2">
                        Mua ngay
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Product Reviews (Image 5 style) -->
    <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
        <h3 class="fw-bold text-dark mb-4 border-bottom pb-3">Đánh giá sản phẩm</h3>

        <?php if($review_message != ""): ?>
            <div class="alert alert-<?php echo $review_message_type; ?> rounded-3 mb-4">
                <?php echo $review_message; ?>
            </div>
        <?php endif; ?>

        <!-- Submit Review Form (Image 5 style) -->
        <div class="card border-0 bg-light p-4 rounded-4 mb-5">
            <?php if (isset($_SESSION['user_id'])): ?>
                <h5 class="fw-bold mb-3">Gửi đánh giá của bạn</h5>
                <form action="detail.php?id=<?php echo $product_id; ?>" method="POST">
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label d-block">Số sao</label>
                            <select name="rating" class="form-select border-0 shadow-sm py-2 px-3">
                                <option value="5">⭐⭐⭐⭐⭐ Rất tốt (5 Sao)</option>
                                <option value="4">⭐⭐⭐⭐ Tốt (4 Sao)</option>
                                <option value="3">⭐⭐⭐ Bình thường (3 Sao)</option>
                                <option value="2">⭐⭐ Tạm (2 Sao)</option>
                                <option value="1">⭐ Không tốt (1 Sao)</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Nhận xét</label>
                        <textarea name="comment" rows="3" class="form-control border-0 shadow-sm" placeholder="Nhập bình luận của bạn về sản phẩm..." required></textarea>
                    </div>
                    
                    <button type="submit" name="submit_review" class="btn btn-danger px-4 rounded-pill fw-bold py-2 shadow-sm">
                        Gửi đánh giá
                    </button>
                </form>
            <?php else: ?>
                <div class="text-center py-2 text-secondary">
                    💬 Vui lòng <a href="login.php" class="text-danger fw-bold text-decoration-none">đăng nhập</a> để bình luận và gửi đánh giá sản phẩm.
                </div>
            <?php endif; ?>
        </div>

        <!-- Reviews List -->
        <h5 class="fw-bold mb-4">Nhận xét từ khách hàng</h5>
        <div class="reviews-list">
            <?php
            $sql_reviews = "SELECT r.*, u.fullname FROM reviews r 
                            JOIN users u ON r.user_id = u.id 
                            WHERE r.product_id = $product_id AND r.status = 1 
                            ORDER BY r.id DESC";
            $result_reviews = $conn->query($sql_reviews);

            if ($result_reviews && $result_reviews->num_rows > 0) {
                while($review = $result_reviews->fetch_assoc()) {
                    $stars = str_repeat('⭐', $review['rating']);
                    $date = date("d/m/Y H:i", strtotime($review['review_date']));
            ?>
                    <div class="d-flex border-bottom pb-4 mb-4">
                        <div class="flex-shrink-0">
                            <div class="bg-danger text-white rounded-circle d-flex align-items-center justify-content-center font-bold" style="width: 45px; height: 45px; font-weight: 700;">
                                <?php echo strtoupper(substr($review['fullname'], 0, 1)); ?>
                            </div>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <div class="d-flex align-items-center justify-content-between mb-1">
                                <h6 class="fw-bold text-dark mb-0"><?php echo htmlspecialchars($review['fullname']); ?></h6>
                                <span class="text-secondary small"><?php echo $date; ?></span>
                            </div>
                            <div class="mb-2" style="font-size: 0.85rem; color: #ffc107;"><?php echo $stars; ?></div>
                            <p class="text-secondary small mb-0"><?php echo nl2br(htmlspecialchars($review['comment'])); ?></p>
                        </div>
                    </div>
            <?php
                }
            } else {
                echo '<p class="text-muted text-center py-4"><em>Chưa có nhận xét nào cho sản phẩm này. Hãy là người đầu tiên đánh giá!</em></p>';
            }
            ?>
        </div>
    </div>
</div>

<script>
function changeMainImage(element) {
    // Set main image source
    document.getElementById('mainImage').src = element.src;
    
    // Clear active class from all thumbs
    var thumbs = document.querySelectorAll('.thumbnail-container img');
    thumbs.forEach(function(img) {
        img.classList.remove('active-thumb');
        img.style.borderColor = '#dee2e6';
    });
    
    // Set active class
    element.classList.add('active-thumb');
    element.style.borderColor = '#d81b60';
}
</script>

<style>
    .active-thumb {
        border-color: #d81b60 !important;
        border-width: 2px !important;
    }
</style>

<?php require_once 'footer.php'; ?>