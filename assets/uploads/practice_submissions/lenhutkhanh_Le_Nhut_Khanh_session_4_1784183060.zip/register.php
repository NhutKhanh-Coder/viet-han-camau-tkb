<?php
session_start();
require_once 'db.php';

$message = "";
$message_type = ""; // 'success' or 'danger'

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fullname = $conn->real_escape_string(trim($_POST['fullname']));
    $username = $conn->real_escape_string(trim($_POST['username']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $gender = $conn->real_escape_string($_POST['gender']);
    $birthday = $conn->real_escape_string(trim($_POST['birthday']));
    $address = $conn->real_escape_string(trim($_POST['address']));
    $password = $_POST['password'];

    // Strong password check: at least 8 chars, letter, number, uppercase, special character
    $strong_password_regex = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/";

    if (empty($fullname) || empty($username) || empty($email) || empty($phone) || empty($password)) {
        $message = "Vui lòng nhập đầy đủ các thông tin bắt buộc (*).";
        $message_type = "danger";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Địa chỉ email không hợp lệ.";
        $message_type = "danger";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $message = "Số điện thoại phải bao gồm đúng 10 chữ số.";
        $message_type = "danger";
    } elseif (!preg_match($strong_password_regex, $password)) {
        $message = "Mật khẩu chưa đủ mạnh! Yêu cầu ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường, số và ký tự đặc biệt.";
        $message_type = "danger";
    } else {
        // Check if username already exists
        $check_user = "SELECT id FROM users WHERE username = '$username'";
        $res_user = $conn->query($check_user);
        
        // Check if email already exists
        $check_email = "SELECT id FROM users WHERE email = '$email'";
        $res_email = $conn->query($check_email);

        if ($res_user && $res_user->num_rows > 0) {
            $message = "Tên đăng nhập này đã được sử dụng!";
            $message_type = "danger";
        } elseif ($res_email && $res_email->num_rows > 0) {
            $message = "Email này đã được sử dụng!";
            $message_type = "danger";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Format optional values
            $birthday_val = !empty($birthday) ? "'$birthday'" : "NULL";
            $address_val = !empty($address) ? "'$address'" : "NULL";
            
            $sql = "INSERT INTO users (fullname, username, email, phone, gender, birthday, address, password, role) 
                    VALUES ('$fullname', '$username', '$email', '$phone', '$gender', $birthday_val, $address_val, '$hashed_password', 'customer')";
            
            if ($conn->query($sql) === TRUE) {
                $message = "<strong>Đăng ký tài khoản thành công!</strong> <a href='login.php' class='alert-link'>Đăng nhập ngay</a>";
                $message_type = "success";
            } else {
                $message = "Lỗi hệ thống: " . $conn->error;
                $message_type = "danger";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng Ký Tài Khoản - Flower Shop</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        body { 
            background: linear-gradient(135deg, #fce4ec 0%, #f3e5f5 100%);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            font-family: 'Outfit', sans-serif;
            padding: 40px 20px;
        }
        
        .register-card {
            background: rgba(255, 255, 255, 0.9);
            backdrop-filter: blur(10px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(216, 27, 96, 0.1);
            padding: 40px;
            max-width: 600px;
            width: 100%;
            border: 1px solid rgba(255, 255, 255, 0.5);
        }

        .logo-title {
            text-align: center;
            margin-bottom: 30px;
        }

        .logo-title h2 {
            font-weight: 800;
            color: #2d3748;
            margin-top: 10px;
            font-size: 1.8rem;
        }

        .logo-title h2 span {
            color: #d81b60;
        }

        .form-label {
            font-weight: 600;
            font-size: 0.9rem;
            color: #4a5568;
        }

        .form-control, .form-select {
            border-radius: 10px;
            padding: 10px 15px;
            border: 1px solid #e2e8f0;
            font-size: 0.95rem;
            transition: all 0.3s ease;
        }

        .form-control:focus, .form-select:focus {
            border-color: #d81b60;
            box-shadow: 0 0 0 0.25rem rgba(216, 27, 96, 0.15);
        }

        .btn-register {
            background-color: #d81b60;
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: 700;
            font-size: 1rem;
            transition: all 0.3s ease;
            margin-top: 10px;
            box-shadow: 0 4px 12px rgba(216, 27, 96, 0.2);
        }

        .btn-register:hover {
            background-color: #ad1457;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(216, 27, 96, 0.3);
        }

        .password-hint {
            font-size: 0.78rem;
            color: #718096;
            margin-top: 5px;
            line-height: 1.4;
        }

        .login-link {
            text-align: center;
            margin-top: 25px;
            font-size: 0.95rem;
        }

        .login-link a {
            color: #d81b60;
            text-decoration: none;
            font-weight: 700;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="register-card">
    <div class="logo-title">
        <div class="text-danger fs-1"><i class="fa-solid fa-spa"></i></div>
        <h2>Đăng Ký <span>Tài Khoản</span></h2>
        <p class="text-secondary small">Tạo tài khoản thành viên để bắt đầu đặt hoa và gửi đánh giá sản phẩm</p>
    </div>
    
    <?php if($message != ""): ?>
        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show rounded-3" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php endif; ?>

    <form method="POST" action="register.php">
        <div class="row g-3">
            <!-- Họ tên -->
            <div class="col-md-6">
                <label for="fullname" class="form-label">Họ và Tên <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Nguyễn Văn A" required value="<?php echo isset($_POST['fullname']) ? htmlspecialchars($_POST['fullname']) : ''; ?>">
            </div>

            <!-- Tên đăng nhập -->
            <div class="col-md-6">
                <label for="username" class="form-label">Tên đăng nhập <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="username" name="username" placeholder="nguyenvana" required value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>">
            </div>

            <!-- Email -->
            <div class="col-md-6">
                <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                <input type="email" class="form-control" id="email" name="email" placeholder="email@gmail.com" required value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
            </div>

            <!-- Điện thoại -->
            <div class="col-md-6">
                <label for="phone" class="form-label">Số điện thoại <span class="text-danger">*</span></label>
                <input type="tel" class="form-control" id="phone" name="phone" placeholder="0901234567" required pattern="[0-9]{10}" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>">
            </div>

            <!-- Giới tính -->
            <div class="col-md-6">
                <label for="gender" class="form-label">Giới tính</label>
                <select id="gender" name="gender" class="form-select">
                    <option value="Nam" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Nam') ? 'selected' : ''; ?>>Nam</option>
                    <option value="Nữ" <?php echo (isset($_POST['gender']) && $_POST['gender'] == 'Nữ') ? 'selected' : ''; ?>>Nữ</option>
                    <option value="Khác" <?php echo (!isset($_POST['gender']) || $_POST['gender'] == 'Khác') ? 'selected' : ''; ?>>Khác</option>
                </select>
            </div>

            <!-- Ngày sinh -->
            <div class="col-md-6">
                <label for="birthday" class="form-label">Ngày sinh</label>
                <input type="date" class="form-control" id="birthday" name="birthday" value="<?php echo isset($_POST['birthday']) ? htmlspecialchars($_POST['birthday']) : ''; ?>">
            </div>

            <!-- Địa chỉ -->
            <div class="col-12">
                <label for="address" class="form-label">Địa chỉ</label>
                <textarea class="form-control" id="address" name="address" rows="2" placeholder="Nhập địa chỉ nhận hàng cụ thể..."><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
            </div>

            <!-- Mật khẩu -->
            <div class="col-12">
                <label for="password" class="form-label">Mật khẩu <span class="text-danger">*</span></label>
                <input type="password" class="form-control" id="password" name="password" placeholder="••••••••" required>
                <div class="password-hint">
                    <i class="fa-solid fa-circle-info text-danger"></i> Yêu cầu mật khẩu mạnh: ít nhất 8 ký tự, gồm chữ hoa, chữ thường, số và ký tự đặc biệt.
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-register w-100 shadow-sm">Đăng Ký Thành Viên</button>
    </form>

    <div class="login-link">
        <p>Đã có tài khoản thành viên? <a href="login.php">Đăng nhập ngay</a></p>
    </div>
</div>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>