<?php
$page_title = "Kết quả tìm kiếm";
require_once 'header.php';

$keyword = "";
if (isset($_GET['keyword'])) {
    $keyword = trim($_GET['keyword']);
}

$keyword_db = $conn->real_escape_string($keyword);
$sql = "SELECT p.*, c.category_name 
        FROM products p 
        LEFT JOIN category_name c ON p.category_id = c.id 
        WHERE p.product_name LIKE '%$keyword_db%'";
$result = $conn->query($sql);
?>

<div class="container">
    <div class="row mb-4">
        <div class="col-12 text-center py-4 bg-light rounded-4 border mb-5">
            <h2 class="fw-bold mb-2"><i class="fa-solid fa-magnifying-glass text-danger me-2"></i> Kết Quả Tìm Kiếm</h2>
            <p class="text-muted mb-0">Tìm thấy <strong><?php echo $result ? $result->num_rows : 0; ?></strong> kết quả cho từ khóa "<strong><?php echo htmlspecialchars($keyword); ?></strong>"</p>
        </div>
    </div>

    <div class="row g-4">
        <?php
        if ($result && $result->num_rows > 0) {
            while($row_pro = $result->fetch_assoc()) {
                $imagePath = !empty($row_pro['image']) ? "uploads/".$row_pro['image'] : "https://via.placeholder.com/300"; 
        ?>
                <div class="col-lg-3 col-md-4 col-sm-6">
                    <div class="card h-100 border-0 shadow-sm product-card">
                        <!-- Image container -->
                        <div class="product-img-wrapper position-relative">
                            <img src="<?php echo $imagePath; ?>" class="card-img-top product-img" alt="<?php echo htmlspecialchars($row_pro['product_name']); ?>">
                            <span class="badge bg-danger position-absolute top-2 start-2 px-3 py-2 rounded-pill shadow-sm">
                                <?php echo htmlspecialchars($row_pro['status']); ?>
                            </span>
                        </div>
                        
                        <!-- Body -->
                        <div class="card-body d-flex flex-column p-4">
                            <h5 class="card-title fw-bold text-dark mb-2"><?php echo htmlspecialchars($row_pro['product_name']); ?></h5>
                            <p class="card-text text-secondary small mb-3">
                                <i class="fa-solid fa-tag me-1 text-danger"></i> Danh mục: <?php echo htmlspecialchars(isset($row_pro['category_name']) ? $row_pro['category_name'] : 'Hoa tươi'); ?>
                            </p>
                            <div class="mt-auto">
                                <div class="d-flex align-items-center justify-content-between mb-3">
                                    <span class="product-price fs-4 fw-bold text-danger"><?php echo number_format($row_pro['price'], 0, ',', '.'); ?> đ</span>
                                </div>
                                <div class="row g-2">
                                    <div class="col-6">
                                        <a href="detail.php?id=<?php echo $row_pro['id']; ?>" class="btn btn-outline-dark btn-sm w-100 rounded-pill py-2 fw-semibold">
                                            Chi tiết
                                        </a>
                                    </div>
                                    <div class="col-6">
                                        <a href="add_cart.php?id=<?php echo $row_pro['id']; ?>" class="btn btn-danger btn-sm w-100 rounded-pill py-2 fw-semibold">
                                            Thêm giỏ
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        <?php
            }
        } else {
            echo "
            <div class='col-12 text-center py-5'>
                <div class='text-muted fs-4 mb-2'><i class='fa-regular fa-face-frown fs-1 text-danger mb-3 d-block'></i>Không tìm thấy sản phẩm nào!</div>
                <p class='text-secondary mb-4'>Thử tìm kiếm với từ khóa khác hoặc quay lại trang chủ.</p>
                <a href='index.php' class='btn btn-danger px-4 rounded-pill fw-semibold'>Quay lại trang chủ</a>
            </div>";
        }
        ?>
    </div>
</div>

<style>
    .product-card {
        border-radius: 16px;
        overflow: hidden;
        transition: all 0.3s ease;
    }

    .product-card:hover {
        transform: translateY(-8px);
        box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08) !important;
    }

    .product-img-wrapper {
        overflow: hidden;
        height: 250px;
    }

    .product-img {
        width: 100%;
        height: 100%;
        object-fit: cover;
        transition: transform 0.5s ease;
    }

    .product-card:hover .product-img {
        transform: scale(1.08);
    }

    .top-2 {
        top: 15px !important;
    }
    .start-2 {
        left: 15px !important;
    }
</style>

<?php require_once 'footer.php'; ?>