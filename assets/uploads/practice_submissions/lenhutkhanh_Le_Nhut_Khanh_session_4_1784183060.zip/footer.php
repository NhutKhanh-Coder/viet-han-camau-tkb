</main>

<!-- Footer Section -->
<footer class="bg-dark text-white pt-5 pb-4 mt-auto">
    <div class="container">
        <div class="row g-4">
            <!-- Col 1: Shop Intro -->
            <div class="col-lg-4 col-md-6 col-12">
                <h5 class="text-uppercase fw-bold text-danger mb-4">🌸 <?php echo htmlspecialchars($website_name); ?></h5>
                <p class="text-secondary small"><?php echo htmlspecialchars($slogan); ?></p>
                <p class="text-secondary small">Cửa hàng hoa tươi chuyên cung cấp các loại hoa tốt nghiệp, hoa chúc mừng, hoa đất sét thủ công và các phụ kiện quà tặng cao cấp khác. Giao hàng tận nơi nhanh chóng, chất lượng hàng đầu.</p>
            </div>
            
            <!-- Col 2: Categories -->
            <div class="col-lg-2 col-md-6 col-12">
                <h5 class="text-uppercase fw-bold mb-4">Danh mục</h5>
                <ul class="list-unstyled text-secondary small">
                    <li class="mb-2"><a href="index.php#categories-section" class="text-decoration-none text-secondary">Hoa tốt nghiệp</a></li>
                    <li class="mb-2"><a href="index.php#categories-section" class="text-decoration-none text-secondary">Hoa Đất Sét</a></li>
                    <li class="mb-2"><a href="index.php#categories-section" class="text-decoration-none text-secondary">Hoa sinh nhật</a></li>
                    <li class="mb-2"><a href="index.php#categories-section" class="text-decoration-none text-secondary">Hoa tình yêu</a></li>
                </ul>
            </div>
            
            <!-- Col 3: Quick Links -->
            <div class="col-lg-2 col-md-6 col-12">
                <h5 class="text-uppercase fw-bold mb-4">Hỗ trợ</h5>
                <ul class="list-unstyled text-secondary small">
                    <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Hướng dẫn mua hàng</a></li>
                    <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Chính sách giao hàng</a></li>
                    <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Chính sách đổi trả</a></li>
                    <li class="mb-2"><a href="#" class="text-decoration-none text-secondary">Liên hệ hỗ trợ</a></li>
                </ul>
            </div>
            
            <!-- Col 4: Contact -->
            <div class="col-lg-4 col-md-6 col-12">
                <h5 class="text-uppercase fw-bold mb-4">Liên hệ</h5>
                <p class="text-secondary small mb-2"><i class="fa-solid fa-location-dot text-danger me-2"></i> <?php echo !empty($address) ? htmlspecialchars($address) : '182 Hùng Vương, Phường 9, Quận 5, TP. Hồ Chí Minh'; ?></p>
                <p class="text-secondary small mb-2"><i class="fa-solid fa-phone text-danger me-2"></i> <?php echo !empty($phone) ? htmlspecialchars($phone) : '0901234567'; ?></p>
                <p class="text-secondary small mb-2"><i class="fa-solid fa-envelope text-danger me-2"></i> <?php echo !empty($email) ? htmlspecialchars($email) : 'contact@flowershop.vn'; ?></p>
                <div class="mt-3">
                    <a href="<?php echo htmlspecialchars($facebook); ?>" class="text-white me-3 fs-5" target="_blank"><i class="fa-brands fa-facebook hover-danger"></i></a>
                    <a href="<?php echo htmlspecialchars($zalo); ?>" class="text-white me-3 fs-5" target="_blank"><i class="fa-solid fa-message hover-danger"></i></a>
                    <a href="<?php echo htmlspecialchars($youtube); ?>" class="text-white fs-5" target="_blank"><i class="fa-brands fa-youtube hover-danger"></i></a>
                </div>
            </div>
        </div>
        
        <hr class="border-secondary my-4">
        
        <div class="row align-items-center">
            <div class="col-md-7 col-12 text-center text-md-start">
                <p class="small text-secondary mb-0">&copy; <?php echo date('Y'); ?> <strong><?php echo htmlspecialchars($website_name); ?></strong>. Thiết kế và phát triển phục vụ thực hành môn Lập trình Web Nâng Cao.</p>
            </div>
            <div class="col-md-5 col-12 text-center text-md-end mt-2 mt-md-0">
                <span class="text-secondary small">Thanh toán an toàn qua BANK & COD</span>
            </div>
        </div>
    </div>
</footer>

<style>
    .hover-danger:hover {
        color: var(--primary-color) !important;
        transition: color 0.3s ease;
    }
</style>

<!-- Bootstrap Bundle JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
