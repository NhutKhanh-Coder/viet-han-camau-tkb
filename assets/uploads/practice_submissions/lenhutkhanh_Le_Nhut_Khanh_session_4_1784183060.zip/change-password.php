<?php
$page_title = "Đổi mật khẩu";
require_once 'header.php';

// Force login check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";
$message_type = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_pwd'])) {
    $old_pwd = $_POST['old_password'];
    $new_pwd = $_POST['new_password'];
    $confirm_pwd = $_POST['confirm_password'];

    $strong_password_regex = "/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$/";

    // Fetch user details to verify password
    $sql_user = "SELECT password FROM users WHERE id = $user_id";
    $res_user = $conn->query($sql_user);
    $user = $res_user->fetch_assoc();

    if (empty($old_pwd) || empty($new_pwd) || empty($confirm_pwd)) {
        $message = "Vui lòng nhập đầy đủ các trường mật khẩu.";
        $message_type = "danger";
    } elseif (!password_verify($old_pwd, $user['password'])) {
        $message = "Mật khẩu cũ không chính xác!";
        $message_type = "danger";
    } elseif (!preg_match($strong_password_regex, $new_pwd)) {
        $message = "Mật khẩu mới chưa đủ mạnh! Yêu cầu ít nhất 8 ký tự, bao gồm chữ hoa, chữ thường, số và ký tự đặc biệt.";
        $message_type = "danger";
    } elseif ($new_pwd !== $confirm_pwd) {
        $message = "Xác nhận mật khẩu mới không khớp!";
        $message_type = "danger";
    } else {
        $new_hashed_pwd = password_hash($new_pwd, PASSWORD_DEFAULT);
        $sql_update = "UPDATE users SET password = '$new_hashed_pwd' WHERE id = $user_id";
        
        if ($conn->query($sql_update) === TRUE) {
            $message = "Đổi mật khẩu thành công!";
            $message_type = "success";
        } else {
            $message = "Có lỗi xảy ra: " . $conn->error;
            $message_type = "danger";
        }
    }
}
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-6 col-md-8">
            <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
                <h2 class="fw-bold mb-4 text-center text-dark">
                    <i class="fa-solid fa-key text-danger me-2"></i> Đổi Mật Khẩu
                </h2>
                
                <?php if($message != ""): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show rounded-3 mb-4" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="change-password.php" method="POST">
                    <!-- Mật khẩu cũ -->
                    <div class="mb-3">
                        <label for="old_password" class="form-label">Mật khẩu cũ <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="old_password" name="old_password" required placeholder="Nhập mật khẩu hiện tại">
                    </div>
                    
                    <!-- Mật khẩu mới -->
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Mật khẩu mới <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="new_password" name="new_password" required placeholder="Nhập mật khẩu mới">
                        <div class="password-hint text-muted small mt-1">
                            <i class="fa-solid fa-circle-info text-danger"></i> Ít nhất 8 ký tự, gồm chữ hoa, chữ thường, số và ký tự đặc biệt.
                        </div>
                    </div>
                    
                    <!-- Xác nhận mật khẩu mới -->
                    <div class="mb-4">
                        <label for="confirm_password" class="form-label">Xác nhận mật khẩu mới <span class="text-danger">*</span></label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required placeholder="Nhập lại mật khẩu mới">
                    </div>

                    <div class="d-flex flex-wrap gap-2">
                        <button type="submit" name="change_pwd" class="btn btn-danger px-4 py-2.5 rounded-pill fw-bold shadow-sm flex-grow-1">
                             Đổi mật khẩu
                        </button>
                        <a href="profile.php" class="btn btn-outline-dark px-4 py-2.5 rounded-pill fw-semibold flex-grow-1 text-center">
                            Quay lại thông tin cá nhân
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
