<?php
$page_title = "Thông tin cá nhân";
require_once 'header.php';

// Force login check
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";
$message_type = "";

// Handle Profile Update
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_profile'])) {
    $fullname = $conn->real_escape_string(trim($_POST['fullname']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $gender = $conn->real_escape_string($_POST['gender']);
    $birthday = $conn->real_escape_string(trim($_POST['birthday']));
    $address = $conn->real_escape_string(trim($_POST['address']));

    if (empty($fullname) || empty($email) || empty($phone)) {
        $message = "Vui lòng nhập đầy đủ các thông tin bắt buộc (*).";
        $message_type = "danger";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Địa chỉ email không hợp lệ.";
        $message_type = "danger";
    } elseif (!preg_match('/^[0-9]{10}$/', $phone)) {
        $message = "Số điện thoại phải bao gồm đúng 10 chữ số.";
        $message_type = "danger";
    } else {
        // Check if email already used by another user
        $check_email = "SELECT id FROM users WHERE email = '$email' AND id != $user_id";
        $res_email = $conn->query($check_email);
        
        if ($res_email && $res_email->num_rows > 0) {
            $message = "Địa chỉ email này đã được sử dụng bởi một tài khoản khác.";
            $message_type = "danger";
        } else {
            $birthday_val = !empty($birthday) ? "'$birthday'" : "NULL";
            $address_val = !empty($address) ? "'$address'" : "NULL";
            
            $sql_update = "UPDATE users SET 
                            fullname = '$fullname', 
                            email = '$email', 
                            phone = '$phone', 
                            gender = '$gender', 
                            birthday = $birthday_val, 
                            address = $address_val 
                           WHERE id = $user_id";
            
            if ($conn->query($sql_update) === TRUE) {
                $_SESSION['fullname'] = $fullname; // Update session fullname
                $message = "Cập nhật thông tin tài khoản thành công!";
                $message_type = "success";
            } else {
                $message = "Có lỗi xảy ra: " . $conn->error;
                $message_type = "danger";
            }
        }
    }
}

// Fetch current user details
$sql_user = "SELECT * FROM users WHERE id = $user_id";
$res_user = $conn->query($sql_user);
if (!$res_user || $res_user->num_rows == 0) {
    header("Location: logout.php");
    exit();
}
$user = $res_user->fetch_assoc();
?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
                <h2 class="fw-bold mb-4 text-center text-dark">
                    <i class="fa-solid fa-address-card text-danger me-2"></i> Thông Tin Tài Khoản
                </h2>
                
                <?php if($message != ""): ?>
                    <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show rounded-3 mb-4" role="alert">
                        <?php echo $message; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                <?php endif; ?>

                <form action="profile.php" method="POST">
                    <div class="row g-4">
                        <!-- Tên đăng nhập (disabled) -->
                        <div class="col-md-6">
                            <label class="form-label" for="username">Tên đăng nhập (Không thể thay đổi)</label>
                            <input type="text" id="username" class="form-control bg-light" value="<?php echo htmlspecialchars($user['username']); ?>" disabled>
                        </div>
                        
                        <!-- Họ và tên -->
                        <div class="col-md-6">
                            <label class="form-label" for="fullname">Họ và tên <span class="text-danger">*</span></label>
                            <input type="text" name="fullname" id="fullname" class="form-control" value="<?php echo htmlspecialchars($user['fullname']); ?>" required>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6">
                            <label class="form-label" for="email">Địa chỉ Email <span class="text-danger">*</span></label>
                            <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>
                        
                        <!-- Điện thoại -->
                        <div class="col-md-6">
                            <label class="form-label" for="phone">Số điện thoại <span class="text-danger">*</span></label>
                            <input type="tel" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone']); ?>" required pattern="[0-9]{10}">
                        </div>

                        <!-- Giới tính -->
                        <div class="col-md-6">
                            <label class="form-label" for="gender">Giới tính</label>
                            <select name="gender" id="gender" class="form-select">
                                <option value="Khác" <?php echo $user['gender'] === 'Khác' ? 'selected' : ''; ?>>Khác</option>
                                <option value="Nam" <?php echo $user['gender'] === 'Nam' ? 'selected' : ''; ?>>Nam</option>
                                <option value="Nữ" <?php echo $user['gender'] === 'Nữ' ? 'selected' : ''; ?>>Nữ</option>
                            </select>
                        </div>
                        
                        <!-- Ngày sinh -->
                        <div class="col-md-6">
                            <label class="form-label" for="birthday">Ngày sinh</label>
                            <input type="date" name="birthday" id="birthday" class="form-control" value="<?php echo !empty($user['birthday']) ? htmlspecialchars($user['birthday']) : ''; ?>">
                        </div>

                        <!-- Địa chỉ -->
                        <div class="col-12">
                            <label class="form-label" for="address">Địa chỉ nhận hàng</label>
                            <textarea name="address" id="address" class="form-control" rows="3" placeholder="Nhập địa chỉ cụ thể..."><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                        </div>
                    </div>

                    <div class="d-flex flex-wrap gap-3 mt-5">
                        <button type="submit" name="update_profile" class="btn btn-danger px-5 py-2.5 rounded-pill fw-bold shadow-sm flex-grow-1 flex-md-grow-0">
                            <i class="fa-solid fa-floppy-disk me-2"></i> Lưu Thay Đổi
                        </button>
                        <a href="change-password.php" class="btn btn-outline-dark px-4 py-2.5 rounded-pill fw-semibold flex-grow-1 flex-md-grow-0">
                            <i class="fa-solid fa-key me-2"></i> Đổi mật khẩu
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php require_once 'footer.php'; ?>
