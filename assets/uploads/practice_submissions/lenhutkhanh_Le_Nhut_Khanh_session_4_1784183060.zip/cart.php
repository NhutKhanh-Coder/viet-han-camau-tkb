<?php
$page_title = "Giỏ Hàng";
require_once 'header.php';

// Handle delete action
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = intval($_GET['id']);
    if (isset($_SESSION['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
    }
    // DB sync
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $conn->query("DELETE FROM carts WHERE user_id = $user_id AND product_id = $id");
    }
    header("Location: cart.php");
    exit();
}

// Handle update action
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_cart'])) {
    if (isset($_POST['quantity'])) {
        foreach ($_POST['quantity'] as $id => $qty) {
            $qty = intval($qty);
            $id = intval($id);
            if ($qty <= 0) {
                unset($_SESSION['cart'][$id]);
                if (isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                    $conn->query("DELETE FROM carts WHERE user_id = $user_id AND product_id = $id");
                }
            } else {
                $_SESSION['cart'][$id]['quantity'] = $qty;
                if (isset($_SESSION['user_id'])) {
                    $user_id = $_SESSION['user_id'];
                    $conn->query("UPDATE carts SET quantity = $qty WHERE user_id = $user_id AND product_id = $id");
                }
            }
        }
    }
    header("Location: cart.php");
    exit();
}
?>

<div class="container">
    <div class="row g-4">
        <!-- Main Cart Area -->
        <div class="col-lg-8">
            <div class="card border-0 shadow-sm rounded-4 p-4 mb-4">
                <h2 class="fw-bold mb-4 d-flex align-items-center gap-3">
                    <i class="fa-solid fa-cart-shopping text-danger"></i> Giỏ Hàng Của Bạn
                </h2>
                
                <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
                    <form action="cart.php" method="POST">
                        <div class="table-responsive">
                            <table class="table align-middle">
                                <thead>
                                    <tr class="text-secondary small text-uppercase">
                                        <th style="width: 100px;">Ảnh</th>
                                        <th>Sản Phẩm</th>
                                        <th>Đơn Giá</th>
                                        <th style="width: 120px;">Số Lượng</th>
                                        <th>Thành Tiền</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $total_order_price = 0;
                                    foreach ($_SESSION['cart'] as $id => $item) {
                                        $img_src = (!empty($item['image'])) ? "uploads/" . $item['image'] : "https://via.placeholder.com/100";
                                        $thanh_tien = $item['price'] * $item['quantity'];
                                        $total_order_price += $thanh_tien;
                                    ?>
                                        <tr>
                                            <td>
                                                <img src="<?php echo $img_src; ?>" class="rounded-3 border" style="width: 70px; height: 70px; object-fit: cover;" alt="">
                                            </td>
                                            <td>
                                                <strong class="text-dark d-block"><?php echo htmlspecialchars($item['name']); ?></strong>
                                            </td>
                                            <td>
                                                <span class="fw-semibold text-secondary"><?php echo number_format($item['price'], 0, ',', '.'); ?> đ</span>
                                            </td>
                                            <td>
                                                <input type="number" name="quantity[<?php echo $id; ?>]" value="<?php echo $item['quantity']; ?>" class="form-control text-center" min="1" required style="border-radius: 8px;">
                                            </td>
                                            <td>
                                                <strong class="text-danger"><?php echo number_format($thanh_tien, 0, ',', '.'); ?> đ</strong>
                                            </td>
                                            <td class="text-end">
                                                <a href="cart.php?action=delete&id=<?php echo $id; ?>" class="btn btn-outline-danger btn-sm border-0 rounded-circle" style="width: 32px; height: 32px; padding: 0; display: inline-flex; align-items: center; justify-content: center;" title="Xóa">
                                                    <i class="fa-solid fa-trash-can"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                </tbody>
                            </table>
                        </div>

                        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mt-4 pt-3 border-top">
                            <a href="index.php" class="btn btn-light rounded-pill px-4 fw-semibold text-secondary">
                                <i class="fa-solid fa-arrow-left me-2"></i> Tiếp tục mua sắm
                            </a>
                            <button type="submit" name="update_cart" class="btn btn-outline-danger rounded-pill px-4 fw-semibold">
                                <i class="fa-solid fa-arrows-rotate me-2"></i> Cập nhật giỏ hàng
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fa-solid fa-basket-shopping text-danger mb-3" style="font-size: 4rem; opacity: 0.3;"></i>
                        <h4 class="fw-bold">Giỏ hàng đang trống</h4>
                        <p class="text-muted mb-4">Hãy chọn mua các sản phẩm hoa đẹp nhất cho người thân yêu của bạn!</p>
                        <a href="index.php" class="btn btn-danger px-5 py-2.5 rounded-pill fw-semibold shadow-sm">
                            Mua sắm ngay
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sidebar / Order summary -->
        <?php if (isset($_SESSION['cart']) && count($_SESSION['cart']) > 0): ?>
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm rounded-4 p-4 mb-4" style="background: linear-gradient(135deg, #fff 0%, #fffbfb 100%);">
                    <h4 class="fw-bold mb-4 text-dark border-bottom pb-2">Tóm Tắt Đơn Hàng</h4>
                    
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-secondary">Tạm tính:</span>
                        <strong class="text-dark"><?php echo number_format($total_order_price, 0, ',', '.'); ?> đ</strong>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <span class="text-secondary">Phí vận chuyển:</span>
                        <span class="text-success fw-bold">Miễn phí</span>
                    </div>
                    
                    <hr class="my-4">
                    
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <span class="text-dark fw-bold fs-5">Tổng tiền:</span>
                        <span class="text-danger fw-extrabold fs-3"><?php echo number_format($total_order_price, 0, ',', '.'); ?> đ</span>
                    </div>
                    
                    <div class="d-grid gap-2">
                        <a href="checkout.php" class="btn btn-danger btn-lg py-3 rounded-pill fw-bold shadow-sm d-flex align-items-center justify-content-center gap-2">
                            Tiến hành đặt hàng <i class="fa-solid fa-circle-arrow-right"></i>
                        </a>
                    </div>
                </div>

                <div class="card border-0 shadow-sm rounded-4 p-4">
                    <h5 class="fw-bold mb-3"><i class="fa-solid fa-shield-halved text-danger me-2"></i> Cam Kết Của Cửa Hàng</h5>
                    <ul class="list-unstyled text-secondary small mb-0">
                        <li class="mb-2"><i class="fa-solid fa-check text-success me-2"></i> Cam kết hoa tươi mới 100% trong ngày.</li>
                        <li class="mb-2"><i class="fa-solid fa-check text-success me-2"></i> Chụp ảnh thật sản phẩm gửi khách trước khi đi giao.</li>
                        <li class="mb-2"><i class="fa-solid fa-check text-success me-2"></i> Giao hoa nhanh trong vòng 60 - 90 phút.</li>
                        <li class="mb-2"><i class="fa-solid fa-check text-success me-2"></i> Hỗ trợ thanh toán tiện lợi (COD, Chuyển khoản).</li>
                    </ul>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once 'footer.php'; ?>